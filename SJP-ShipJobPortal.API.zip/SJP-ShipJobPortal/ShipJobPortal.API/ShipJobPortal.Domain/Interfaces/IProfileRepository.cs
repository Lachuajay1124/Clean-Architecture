﻿using ShipJobPortal.Domain.Entities;

namespace ShipJobPortal.Domain.Interfaces;

public interface IProfileRepository
{
    Task<ReturnResult> CreateUserProfileAsync(UserProfileModel userProfile);
    Task<ReturnResult> AddUserFilesAsync(UserFilesModel Userfiles);
    Task<ReturnResult> UpdateSeaExperiance( List<SeaExperianceViewPatchModel> experiance);
    Task<ReturnResult> UpdateCertificatesAsync(List<CertificatesViewPatchModel> certificate);
    Task<ReturnResult<UserProfileViewModel>> GetSeafarerProfileAsync(int userId);
    Task<ReturnResult<string>> ReferFriendAsync(ReferAFriendModel model);
    Task<ReturnResult> UserVideoResume(VideoResumeFilesModel model);
    Task<ReturnResult<CompanyViewModel>> fn_GetcompanyProfileAsync(int companyId);
    Task<ReturnResult<VideoResumeFilesModel>> GetVideoResumeAsync(int userId);

    Task<ReturnResult<UserFilesModel>> GetUserFiles(int userId);


}