﻿namespace ShipJobPortal.Domain.Interfaces;

public interface IDbExceptionLogger
{
    Task LogExceptionAsync(string methodName, string message, string stackTrace);
}
