﻿using ShipJobPortal.Domain.Entities;

namespace ShipJobPortal.Domain.Interfaces;

public interface IMatchingRepository
{
    Task<ReturnResult<MatchingCandidateViewModel>> GetMatchingCandidatesAsync(GetMatchingCandidateForJobModel request);

}
