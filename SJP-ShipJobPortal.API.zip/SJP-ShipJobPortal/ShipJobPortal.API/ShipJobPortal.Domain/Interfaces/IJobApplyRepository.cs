﻿using ShipJobPortal.Domain.Entities;

namespace ShipJobPortal.Domain.Interfaces;

public interface IJobApplyRepository
{
    Task<ReturnResult<AppliedCandidatesListModel>> GetAppliedCandidatesAsync(GetAppliedCandidateRequestModel requestModel);
    Task<ReturnResult<string>> ApplyJobAsync(JobApplyPostModel model);
    Task<ReturnResult<AppliedJobsListModel>> GetAppliedJobsAsync(GetAppliedJobsForCandidateModel request);
    Task<ReturnResult<string>> WishlistJobAsync(JobWishlistModel model);
    Task<ReturnResult<SavedJobsListModel>> GetSavedJobsAsync(GetSavedJobsForCandidateModel request);
    Task<ReturnResult<string>> JobActionOnCandidateAsync(JobActionOnCandidateModel model);
}
