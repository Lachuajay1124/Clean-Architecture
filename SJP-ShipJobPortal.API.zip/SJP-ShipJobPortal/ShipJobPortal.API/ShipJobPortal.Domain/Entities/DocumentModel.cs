﻿namespace ShipJobPortal.Domain.Entities;

public class LookupItemModel 
{
    public int? itemId {  get; set; }
    public string? itemCode {  get; set; }
    public string? itemHardCode {  get; set; }
    public string? itemName { get; set; }
    public string? recordType { get; set; }
    public int? sortOrder {  get; set; }
}

public class DocumentSaveModel
{
    public int? Id { get; set; }
    public string? Code { get; set; }
    public string? Name { get; set; }
    public int CompanyId {  get; set; }
    public int? SectionId { get; set; }
    public int? CategoryId { get; set; }
    public int? TypeId { get; set; }
    public int? SortOrder { get; set; }
    public int? IndustryId { get; set; }
    public bool? HaveExpiry { get; set; }
}
