﻿using System.Text.Json.Serialization;

namespace ShipJobPortal.Domain.Entities;

public class JobPostModel
{
    public int JobId { get; set; }
    public int CompanyId { get; set; }//
    public string? CompanyDescription { get; set; }//
    public string? Disclaimer { get; set; }//
    public int UserId { get; set; }//
    public string? JobTitle { get; set; }//
    public int? NoVacancy { get; set; }//
    public int NationalityId { get; set; }//
    public string? pleaseNote { get; set; }//
    public DateTime OpenDate { get; set; }//
    public DateTime? CloseDate { get; set; }//
    public string? whatToExpect { get; set; }//
    public string? PublishedDate { get; set; }//
    public bool? publishToLinkedIn { get; set; }//
    public int vesselTypeId { get; set; }//
    public int PositionId { get; set; }//
    public int LocationId { get; set; }//
    public List<RequiredDocumentModel>? documents { get; set; }
    public List<RequiredExperianceModel>? requirements { get; set; }
    [JsonIgnore]
    public string Status { get; set; }
}

public class RequiredDocumentModel
{
    public int documentId { get; set; }
    public bool isMandatory { get; set; }
}

public class RequiredExperianceModel
{
    public int positionId { get; set; }
    public int vesselTypeId { get; set; }
    public int? expYears { get; set; }
    public int? expMonths { get; set; }
    public int? noTours { get; set; }
}
public class JobViewFilteredModel
{
    public PaginationModel Pagination { get; set; }
    public List<JobViewModel> JobsList { get; set; }
}

public class PaginationModel
{
    public string? TotalItems { get; set; }
    public string? TotalPages { get; set; }
    public string? CurrentPage { get; set; }
    public string? ItemsPerPage { get; set; }
}

public class JobViewModel
{
    public int JobId { get; set; }
    public int CompanyId { get; set; }
    public int UserId { get; set; }
    public string? JobTitle { get; set; }
    public string? Company { get; set; }
    public int NoVacancy { get; set; }
    public int NationalityId { get; set; }
    public string? Nationality { get; set; }
    public string? CompanyDescription { get; set; }
    public string? OpenDate { get; set; }
    public string? CloseDate { get; set; }
    public string? PublishedDate { get; set; }
    public int? PositionId { get; set; }
    public string? Position { get; set; }
    public int? DurationId { get; set; }
    public string? Duration { get; set; }
    public int? VesselTypeId { get; set; }
    public string? vesselType { get; set; }
    public int? LocationId { get; set; }
    public string? LocationName { get; set; }
    public string? IsSaved { get; set; }
    public string? appliedcount { get; set; }
    public string? IsApplied { get; set; }
    public string? viewcount { get; set; }
    public string? pleaseNote { get; set; }
    public string? Disclaimer { get; set; }
    public string? whatToExpect { get; set; }
    public List< RequiredDocumentsViewModel> RequiredDocuments { get; set; }
    public List<RequiredExperienceViewModel> RequiredExperience { get; set; }

    [JsonIgnore]
    public string? Status { get; set; }
}

public class JobViewCountModel
{
    public int userid { get; set; }
    public int jobid { get; set; }
}

public class RequiredDocumentsViewModel
{
    public int documentId { get; set; }
    public string? documentName {  get; set; }
    public bool isMandatory { get; set; }
}

public class RequiredExperienceViewModel
{
    public int positionId { get; set; }
    public string? positionName {  get; set; }
    public int vesselTypeId { get; set; }
    public string? vesselTypeName { get; set; } 
    public int? expYears { get; set; }
    public int? expMonths { get; set; }
    public string? expType { get; set; }
    public int? noTours { get; set; }
}
