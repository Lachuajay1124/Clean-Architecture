﻿namespace ShipJobPortal.Domain.Entities;

public class ShiphireApplicantModel
{
    public int ApplicantId { get; set; }
}
