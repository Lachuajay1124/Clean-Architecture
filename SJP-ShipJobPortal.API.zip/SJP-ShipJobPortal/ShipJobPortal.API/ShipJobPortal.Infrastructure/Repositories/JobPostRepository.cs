﻿using System.Data;
using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ShipJobPortal.Domain.Constants;
using ShipJobPortal.Domain.Entities;
using ShipJobPortal.Domain.Interfaces;
using ShipJobPortal.Infrastructure.DataAccessLayer;
using Newtonsoft.Json.Linq;
using ShipJobPortal.Infrastructure.DataHelpers;

namespace ShipJobPortal.Infrastructure.Repositories;

public class JobPostRepository : IJobPostRepository
{
    private readonly IDataAccess_Improved _dbHelper;
    private readonly IConfiguration _configuration;
    private readonly ILogger<JobPostRepository> _logger;
    private readonly string _dbKey;

    public JobPostRepository(IConfiguration configuration, IDataAccess_Improved dbHelper, ILogger<JobPostRepository> logger)
    {
        _configuration = configuration;
        _dbHelper = dbHelper;
        _logger = logger;

        _dbKey = string.IsNullOrWhiteSpace(_configuration["ConnectionStrings:DefaultConnection"])
            ? throw new Exception("DefaultConnection is missing in ConnectionStrings.")
            : "DefaultConnection";
    }


    public async Task<ReturnResult> CreateorUpdateJobAsync(JobPostModel job)
    {
        try
        {
            var p = new DynamicParameters();

            p.Add("@Mode", job.JobId > 0
                ? _configuration["StoredProcedureModes:Update"]
                : _configuration["StoredProcedureModes:Insert"]);

            p.Add("@VacancyId", job.JobId);      
            p.Add("@CompanyId", job.CompanyId);
            p.Add("@CompanyDescription", job.CompanyDescription);
            p.Add("@Disclaimer", job.Disclaimer);          
            p.Add("@UserId", job.UserId);

            p.Add("@JobTitle", job.JobTitle);
            p.Add("@NoVacancy", job.NoVacancy);        
            p.Add("@NationalityId", job.NationalityId);        

            p.Add("@PleaseNote", job.pleaseNote);              
            p.Add("@OpenDate", job.OpenDate);
            p.Add("@CloseDate", job.CloseDate);

            p.Add("@WhatToExpect", job.whatToExpect);        

            DateTime? publishedDate = null;
            if (!string.IsNullOrWhiteSpace(job.PublishedDate) &&
                DateTime.TryParse(job.PublishedDate, out var pd))
                publishedDate = pd.Date;
            p.Add("@PublishedDate", publishedDate);

            // publishToLinkedIn -> BIT -> SP derives PublishTo ('LinkedIn'/'Portal')
            p.Add("@PublishToLinkedIn", job.publishToLinkedIn);

            p.Add("@VesselTypeId", job.vesselTypeId);
            p.Add("@PositionId", job.PositionId);
            p.Add("@LocationId", job.LocationId);

            // === TVPs ===
            var tvpReqDocs = TvpHelper.ToRequiredDocumentsTable(job.documents);
            p.Add("@RequiredDocuments", tvpReqDocs.AsTableValuedParameter("dbo.RequiredDocumentTVP"));

            var tvpReqExp = TvpHelper.ToRequiredExperianceTable(job.requirements);
            p.Add("@RequiredExperiences", tvpReqExp.AsTableValuedParameter("dbo.RequiredExperienceTVP"));

            p.Add("@ReturnStatus", dbType: DbType.String, size: 5000, direction: ParameterDirection.Output);
            p.Add("@ErrorCode", dbType: DbType.String, size: 5000, direction: ParameterDirection.Output);

            await _dbHelper.ExecuteScalarAsync("usp_JobPosting_Create", p, _dbKey);

            return new ReturnResult
            {
                ReturnStatus = p.Get<string>("@ReturnStatus"),
                ErrorCode = p.Get<string>("@ErrorCode")
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error occurred while creating/updating the job vacancy");
            throw;
        }
    }


    public async Task<ReturnResult<JobViewFilteredModel>> GetAllJobsFilteredAsync(JobFilterRequest model)
    {
        try
        {
            var p = new DynamicParameters();
            p.Add("@VacancyId", model.VacancyId);
            p.Add("@UserId", model.UserId);
            p.Add("@companyId", model.CompanyId);
            p.Add("@positionId", model.PositionId);
            p.Add("@vesselTypeId", model.VesselTypeId);
            p.Add("@locationId", model.LocationId);
            p.Add("@durationId", model.DurationId);
            p.Add("@searchKey", model.SearchKey);
            p.Add("@PageNumber", model.PageNumber);
            p.Add("@PageSize", model.PageSize);
            p.Add("@CandidateId", model.CandidateId);

            var dbResult = await _dbHelper.QueryMultipleAsync("usp_Job_details_test1", p, _dbKey);

            if (dbResult == null || dbResult.Data.Count < 2)
                return new ReturnResult<JobViewFilteredModel>("error", ErrorCodes.InternalServerError, null);

            // ---- Result set 1: jobs ----
            // Deserialize to JObjects so we can read DocsJson/ExpsJson per row
            var jobRows = JsonConvert.DeserializeObject<List<JObject>>(
                JsonConvert.SerializeObject(dbResult.Data[0])) ?? new List<JObject>();

            var jobs = new List<JobViewModel>();

            foreach (var row in jobRows)
            {
                var job = row.ToObject<JobViewModel>() ?? new JobViewModel();
                job.RequiredDocuments = new List<RequiredDocumentsViewModel>();
                job.RequiredExperience = new List<RequiredExperienceViewModel>();

                var docsJson = row["DocsJson"]?.ToString();
                if (!string.IsNullOrWhiteSpace(docsJson) && docsJson != "null")
                {
                    var arr = JArray.Parse(docsJson);
                    foreach (var token in arr)
                    {
                        job.RequiredDocuments.Add(new RequiredDocumentsViewModel
                        {
                            documentId = token["DocumentId"]?.ToObject<int>() ?? 0,
                            documentName = token["Name"]?.ToString(),
                            // SQL gives 'Y'/'N'
                            isMandatory = string.Equals(token["Mandatory"]?.ToString(), "Y", StringComparison.OrdinalIgnoreCase)
                        });
                    }
                }

                // --- ExpsJson -> List<RequiredExperienceViewModel> ---
                var expsJson = row["ExpsJson"]?.ToString();
                if (!string.IsNullOrWhiteSpace(expsJson) && expsJson != "null")
                {
                    var arr = JArray.Parse(expsJson);
                    foreach (var token in arr)
                    {
                        job.RequiredExperience.Add(new RequiredExperienceViewModel
                        {
                            positionId = token["PositionId"]?.ToObject<int>() ?? 0,
                            positionName = token["PositionName"]?.ToString(),
                            vesselTypeId = token["VesselTypeId"]?.ToObject<int>() ?? 0,
                            vesselTypeName = token["VesselTypeName"]?.ToString(),
                            expYears = token["ExpYear"]?.ToObject<int?>(),
                            expMonths = token["ExpMonth"]?.ToObject<int?>(),
                            expType = token["ExpType"]?.ToString(),
                            noTours = token["NoTours"]?.ToObject<int?>()
                        });
                    }
                }

                jobs.Add(job);
            }

            // ---- Result set 2: pagination ----
            var paginationRaw = dbResult.Data[1].FirstOrDefault();
            var pagination = paginationRaw != null
                ? JsonConvert.DeserializeObject<PaginationModel>(JsonConvert.SerializeObject(paginationRaw))
                : new PaginationModel();

            var resultModel = new JobViewFilteredModel
            {
                JobsList = jobs,
                Pagination = pagination
            };

            return new ReturnResult<JobViewFilteredModel>(
                returnStatus: dbResult.ReturnStatus ?? "success",
                errorCode: dbResult.ErrorCode ?? ErrorCodes.Success,
                data: resultModel
            );
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in GetAllJobsFilteredAsync");
            throw;
        }
    }

    public async Task<ReturnResult<string>> JobViewCountAsync(JobViewCountModel model)
    {
        var result = new ReturnResult<string>();

        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@UserId", model.userid);
            parameters.Add("@JobId", model.jobid);


            await _dbHelper.ExecuteScalarAsync("usp_Insert_JobViewHistory", parameters, _dbKey);

            result.ReturnStatus = parameters.Get<string>("@ReturnStatus");
            result.ErrorCode = parameters.Get<string>("@ErrorCode");
            result.Data = result.ReturnStatus;

            return result;
        }
        catch (Exception ex)
        {
            throw;
        }
    }
    public async Task<ReturnResult> DeleteJobAsync(int vacancyId)
    {
        try
        {
            JobPostModel job = new();
            var parameters = new DynamicParameters();
            parameters.Add("@VacancyId", vacancyId);
            parameters.Add("@Mode", _configuration["StoredProcedureModes:Delete"]);
            parameters.Add("@CompanyId", job.CompanyId);
            parameters.Add("@JobTitle", job.JobTitle);
            parameters.Add("@NoVacancy", job.NoVacancy);
            parameters.Add("@NationalityId", job.NationalityId);
         
            await _dbHelper.ExecuteScalarAsync("usp_JobPosting_Create", parameters, _dbKey);

            return new ReturnResult
            {
                ReturnStatus = parameters.Get<string>("@ReturnStatus"),
                ErrorCode = parameters.Get<string>("@ErrorCode")
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error occurred while deleting the job vacancy");
            throw;
        }
    }

}

