﻿using System.Data;
using ShipJobPortal.Application.Validators;
using ShipJobPortal.Domain.Entities;

namespace ShipJobPortal.Infrastructure.DataHelpers;

public class TvpHelper
{
    public static DataTable ToDocumentsTable(List<DocumentsAndCertications> documents)
    {
        try
        {
            var dt = new DataTable();
            dt.Columns.Add("certificateORdocumentExpiryDate", typeof(DateTime));
            dt.Columns.Add("certificateORdocumentIssueDate", typeof(DateTime));
            dt.Columns.Add("certificateORdocumentIssuingCountry", typeof(string));
            dt.Columns.Add("certificateORdocumentName", typeof(string));
            dt.Columns.Add("certificateORdocumentNumber", typeof(string));

            foreach (var d in documents)
            {
                dt.Rows.Add(Convert.ToDateTime(d.Certificateordocumentexpirydate), Convert.ToDateTime(d.Certificateordocumentissuedate),
                    d.Certificateordocumentissuingcountry, d.Certificateordocumentname, d.Certificateordocumentnumber);
            }
            return dt;
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    public static DataTable ToExperienceTable(List<PreviousSeaExperiance> experiences)
    {
        try
        {
            var dt = new DataTable();
            dt.Columns.Add("CompanyName", typeof(string));
            dt.Columns.Add("Duration", typeof(string));
            dt.Columns.Add("DWT", typeof(string));
            dt.Columns.Add("EngineType", typeof(string));
            dt.Columns.Add("FromDate", typeof(DateTime));
            dt.Columns.Add("GT", typeof(string));
            dt.Columns.Add("IAS", typeof(string));
            dt.Columns.Add("KW", typeof(string));
            dt.Columns.Add("Position", typeof(string));
            dt.Columns.Add("ToDate", typeof(DateTime));
            dt.Columns.Add("VesselName", typeof(string));
            dt.Columns.Add("VesselType", typeof(string));

            foreach (var e in experiences)
            {
                dt.Rows.Add(e.Companyname, e.Duration, e.Dwt, e.Enginetype, Convert.ToDateTime(e.Fromdate), e.Gt,
                     e.Ias, e.Kw, e.Position, Convert.ToDateTime(e.Todate), e.Vesselname, e.Vesseltype);
            }
            return dt;
        }
        catch (Exception ex)
        {
            throw;
        }
    }


    public static DataTable ToRequiredDocumentsTable(List<RequiredDocumentModel> documents)
    {
        var dt = new DataTable();
        dt.Columns.Add("DocumentId", typeof(int));
        dt.Columns.Add("Mandatory", typeof(string));

        foreach (var d in documents)
        {
            string mandatory = d.isMandatory ? "Y" : "N";
            dt.Rows.Add(Convert.ToInt32(d.documentId), mandatory);
        }

        return dt;
    }

    public static DataTable ToRequiredExperianceTable(List<RequiredExperianceModel> experiances)
    {
        var dt = new DataTable();
        dt.Columns.Add("PositionId", typeof(int));
        dt.Columns.Add("VesselTypeId", typeof(int));
        dt.Columns.Add("ExpYear", typeof(int));
        dt.Columns.Add("ExpMonth", typeof(int));
        dt.Columns.Add("ExpType", typeof(string));
        dt.Columns.Add("NoTours", typeof(int));

        dt.Columns["ExpType"].MaxLength = 3;

        foreach (var e in experiances ?? Enumerable.Empty<RequiredExperianceModel>())
        {
            int positionId = ToIntOrZero(e?.positionId);
            int expYear = ToIntOrZero(e?.expYears);
            int expMonth = ToIntOrZero(e?.expMonths);
            int noTours = ToIntOrZero(e?.noTours);

            // vesselTypeId can be int?, string, etc. Parse safely.
            int? vesselTypeId = ToNullableInt(e?.vesselTypeId);

            // 🔑 Derive EXP/EXV: null/empty/-1 => EXP, else EXV
            string expType = (!vesselTypeId.HasValue || vesselTypeId.Value == -1) ? "EXP" : "EXV";

            int vesselForRow = vesselTypeId ?? -1;

            dt.Rows.Add(positionId, vesselForRow, expYear, expMonth, expType, noTours);
        }

        return dt;
    }

    public static DataTable ToCertificatesTvp(List<CertificatesViewPatchModel> certificates)
    {
        var dt = new DataTable();

        dt.Columns.Add("Id", typeof(int));                                 
        dt.Columns.Add("UserId", typeof(int));                              
        dt.Columns.Add("CertificateOrDocumentExpiryDate", typeof(DateTime));
        dt.Columns.Add("CertificateOrDocumentIssueDate", typeof(DateTime)); 
        dt.Columns.Add("CertificateOrDocumentIssuingCountry", typeof(string));
        dt.Columns.Add("CertificateOrDocumentName", typeof(string));
        dt.Columns.Add("CertificateOrDocumentNumber", typeof(string));

        foreach (var c in certificates ?? Enumerable.Empty<CertificatesViewPatchModel>())
        {
            if (c == null) continue;

            var idObj = c.certificateId.HasValue ? (object)c.certificateId.Value : DBNull.Value;
            var userIdObj = c.userId.HasValue ? (object)c.userId.Value : DBNull.Value;

            var exp = ParseDate(c.ExpiryDate);
            var iss = ParseDate(c.IssuedDate);

            dt.Rows.Add(
                idObj,
                userIdObj,
                exp.HasValue ? (object)exp.Value : DBNull.Value,
                iss.HasValue ? (object)iss.Value : DBNull.Value,
                Clean(c.IssuedCountry),
                Clean(c.CertificateName),
                Clean(c.DocumentNumber)
            );
        }

        return dt;

        static string Clean(string s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

        // If you prefer, swap to your DateConverter here
        static DateTime? ParseDate(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return null;
            return DateTime.TryParse(s, out var dt) ? dt.Date : (DateTime?)null;
        }
    }


    public static DataTable ToPreviousSeaExperienceTvp(List<SeaExperianceViewPatchModel> items)
    {
        var dt = new DataTable();

        dt.Columns.Add("ExperienceId", typeof(int));
        dt.Columns.Add("UserId", typeof(int));
        dt.Columns.Add("Company", typeof(string));
        dt.Columns.Add("Duration", typeof(string));
        dt.Columns.Add("DWT", typeof(string));
        dt.Columns.Add("EngineType", typeof(string));
        dt.Columns.Add("FromDate", typeof(DateTime));
        dt.Columns.Add("GT", typeof(string));
        dt.Columns.Add("IAS", typeof(string));
        dt.Columns.Add("KW", typeof(string));
        dt.Columns.Add("Position", typeof(string));
        dt.Columns.Add("ToDate", typeof(DateTime));
        dt.Columns.Add("VesselName", typeof(string));
        dt.Columns.Add("VesselType", typeof(string));

        foreach (var x in items ?? Enumerable.Empty<SeaExperianceViewPatchModel>())
        {
            if (x == null) continue;

            var expId = x.ExperianceId.HasValue ? (object)x.ExperianceId.Value : DBNull.Value;
            var userId = x.userId.HasValue ? (object)x.userId.Value : DBNull.Value;

            var fromDt = ToDate(x.FromDate);
            var toDt = ToDate(x.ToDate);

            dt.Rows.Add(
                expId,
                userId,
                Clean(x.CompanyName),
                Clean(x.Duration),
                Clean(x.DWT),
                Clean(x.EngineType),
                fromDt.HasValue ? (object)fromDt.Value : DBNull.Value,
                Clean(x.GT),
                Clean(x.IAS),
                Clean(x.KW),
                Clean(x.Position),
                toDt.HasValue ? (object)toDt.Value : DBNull.Value,
                Clean(x.VesselName),
                Clean(x.VesselType)
            );
        }

        return dt;

        static string Clean(string s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

        static DateTime? ToDate(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return null;

            // Prefer your existing converter (kept resilient to bad formats)
            var d = DateConverter.ConvertToNullableDate(s);
            if (d.HasValue) return d.Value.Date;

            // Fallback if needed
            return DateTime.TryParse(s, out var parsed) ? parsed.Date : (DateTime?)null;
        }
    }


    private static int ToIntOrZero(object value)
    {
        if (value == null) return 0;
        if (value is int i) return i;
        if (value is long l) return (int)l;
        var s = value.ToString()?.Trim();
        return int.TryParse(s, out var v) ? v : 0;
    }

    private static int? ToNullableInt(object value)
    {
        if (value == null) return null;
        if (value is int i) return i;
        if (value is long l) return (int)l;
        var s = value.ToString()?.Trim();
        if (string.IsNullOrEmpty(s)) return null;
        return int.TryParse(s, out var v) ? v : (int?)null;
    }
}