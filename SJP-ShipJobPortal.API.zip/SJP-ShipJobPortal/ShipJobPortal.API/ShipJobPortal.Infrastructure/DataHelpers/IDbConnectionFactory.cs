﻿using System.Data;

namespace ShipJobPortal.Infrastructure.DataHelpers
{
    public interface IDbConnectionFactory
    {
        IDbConnection CreateConnection();
        IDbConnection CreateConnection(string connectionName);
    }
}
