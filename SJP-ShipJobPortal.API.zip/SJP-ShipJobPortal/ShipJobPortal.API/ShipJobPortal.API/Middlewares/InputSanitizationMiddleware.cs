﻿using System.Text;
using System.Text.RegularExpressions;

namespace ShipJobPortal.API.Middlewares
{
    public class InputSanitizationMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<InputSanitizationMiddleware> _logger;
        public InputSanitizationMiddleware(RequestDelegate next,
        ILogger<InputSanitizationMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }
        public async Task InvokeAsync(HttpContext context)
        {
            // Only sanitize POST/PUT requests with JSON content
            if (ShouldSanitize(context))
            {
                await SanitizeRequestBody(context);
            }
            await _next(context);
        }
        private bool ShouldSanitize(HttpContext context)
        {
            return (context.Request.Method == "POST" || context.Request.Method == "PUT") &&
            context.Request.HasJsonContentType();
        }
        private async Task SanitizeRequestBody(HttpContext context)
        {
            try
            {
                context.Request.EnableBuffering();
                using var reader = new StreamReader(context.Request.Body, leaveOpen: true);
                var body = await reader.ReadToEndAsync();
                if (!string.IsNullOrEmpty(body))
                {
                    var sanitizedBody = SanitizeJsonInput(body);
                    var bytes = Encoding.UTF8.GetBytes(sanitizedBody);
                    context.Request.Body = new MemoryStream(bytes);
                }
                context.Request.Body.Position = 0;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to sanitize request body");
                // Continue with original request if sanitization fails
                context.Request.Body.Position = 0;
            }
        }
        private string SanitizeJsonInput(string json)
        {
            if (string.IsNullOrWhiteSpace(json))
                return json;
            // Remove potential XSS patterns
            json = RemoveScriptTags(json);
            json = RemoveJavaScriptUrls(json);
            json = RemoveDataUrls(json);
            json = RemoveSqlInjectionPatterns(json);
            return json;
        }
        private string RemoveScriptTags(string input)
        {
            return Regex.Replace(input, @"<script[^>]*>.*?</script>", "",
            RegexOptions.IgnoreCase | RegexOptions.Singleline);
        }
        private string RemoveJavaScriptUrls(string input)
        {
            return Regex.Replace(input, @"javascript\s*:", "", RegexOptions.IgnoreCase);
        }
        private string RemoveDataUrls(string input)
        {
            return Regex.Replace(input, @"data\s*:", "", RegexOptions.IgnoreCase);
        }
        private string RemoveSqlInjectionPatterns(string input)
        {
            var patterns = new[]
            {
@"\b(union|select|insert|update|delete|drop|create|alter|exec|execute)\b",
@"[';]--",
@"/\*.*?\*/"
};
            foreach (var pattern in patterns)
            {
                input = Regex.Replace(input, pattern, "", RegexOptions.IgnoreCase);
            }
            return input;
        }
    }

    public static class InputSanitizationExtensions
    {
        public static IApplicationBuilder UseInputSanitization(this IApplicationBuilder app)
            => app.UseMiddleware<InputSanitizationMiddleware>();
    }

}