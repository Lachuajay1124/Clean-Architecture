﻿using Microsoft.AspNetCore.Mvc;
using ShipJobPortal.Application.DTOs;
using ShipJobPortal.Application.IServices;
using ShipJobPortal.Domain.Constants;
using ShipJobPortal.Domain.Interfaces;
using ShipJobPortal.API.Helpers;
using Microsoft.AspNetCore.Authorization;

namespace ShipJobPortal.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DocumentController : ControllerBase
    {

        private readonly IDocumentService _DocumentService;
        private readonly ILogger<DocumentController> _logger;
        private readonly IDbExceptionLogger _dbExceptionLogger;

        public DocumentController(IDocumentService documentService, ILogger<DocumentController> logger, IDbExceptionLogger dbExceptionLogger)
        {
            _DocumentService = documentService;
            _logger = logger;
            _dbExceptionLogger = dbExceptionLogger;
        }

        /// <summary>
        /// to save look up item
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [Authorize(Roles = "Admin")]
        [HttpPost("LookupSave")]
        public async Task<IActionResult> LookupItemSave([FromBody] LookupItemDto model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new ApiResponse<string>(
                    false,
                    null,
                    "Invalid request data.",
                    ErrorCodes.BadRequest
                ));
            }

            try
            {
                var response = await _DocumentService.LookUpItemAddAsync(model);
                return this.ToActionResult(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in Lookup Item endpoint.");
                await _dbExceptionLogger.LogExceptionAsync("lookup Item", ex.Message, ex.StackTrace);
                throw;
            }
        }

        /// <summary>
        /// to save document
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [Authorize(Roles ="Admin")]
        [HttpPost("SaveDocument")]
        public async Task<IActionResult> SaveDocument([FromBody] DocumentSaveDto model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new ApiResponse<string>(
                    false,
                    null,
                    "Invalid request data.",
                    ErrorCodes.BadRequest
                ));
            }

            try
            {
                var response = await _DocumentService.DocumentInsertUpdateAsync(model);
                return this.ToActionResult(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in Document save.");
                await _dbExceptionLogger.LogExceptionAsync("DocumentSaveupdate", ex.Message, ex.StackTrace);
                throw;
            }
        }

    }
}

