﻿namespace ShipJobPortal.Application.DTOs;

public class GetCountryListDto
{
    public int? ID { get; set; }
    public string? Code { get; set; }
    public string? CountryName { get; set; }
}

public class GetStateListDto
{
    public int? ID { get; set; }
    public string? StateName { get; set; }
}

public class GetCityListDto
{
    public int? ID { get; set; }
    public string? CityName { get; set; }
}

public class VesselTypeDto
{
    public int? TypeID { get; set; }
    public string? VesselCode { get; set; }
    public string? Vesseltype { get; set; }
}

public class ContractDurationDto
{
    public int? DurationId { get; set; }
    public string? Value { get; set; }
    public string? ContractMonths { get; set; }
}

public class PositionDto
{
    public int? ID { get; set; }
    public string? Name { get; set; }

}

public class MobileCountryCodeDto
{
    public int Id { get; set; }
    public string? CountryCode { get; set; }
    public string? DialCode { get; set; }
    public string? CountryName { get; set; }
    public string? FlagEmoji { get; set; }
    public string? DisplayText { get; set; }
}


public class DocumentListDto
{
    public int DocumentId { get; set; }
    public string? DocumentName { get; set; }
}


public class DocumentSectionDto
{
    public int SectionId { get; set; }
    public string? SectionName { get; set; }
}

public class DocumentCategoryDto
{
    public int CategoryId { get; set; }
    public string? CategoryName { get; set; }
}

public class DocumentTypeDto
{
    public int TypeId { get; set; }
    public string? TypeName { get; set; }
}

public class IndustryDto
{
    public int IndustryId { get; set; }
    public string? IndustryName { get; set; }
}
