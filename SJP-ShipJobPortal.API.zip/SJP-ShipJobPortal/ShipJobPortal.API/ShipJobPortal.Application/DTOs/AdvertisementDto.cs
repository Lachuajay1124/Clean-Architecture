﻿namespace ShipJobPortal.Application.DTOs;

public class AdvertisementDto
{
}
