﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ShipJobPortal.Application.DTOs;
using ShipJobPortal.Application.IServices;
using ShipJobPortal.Application.Validators;
using ShipJobPortal.Domain.Constants;
using ShipJobPortal.Domain.Entities;
using ShipJobPortal.Domain.Interfaces;
using static ShipJobPortal.Application.Services.ProfileService;

namespace ShipJobPortal.Application.Services;

public class ProfileService : IProfileService
{
    private readonly IProfileRepository _profileRepository;
    private readonly string _resumeApiUrl;
    private readonly ILogger<ProfileService> _logger;
    private readonly IMapper _mapper;

    public ProfileService(IProfileRepository profileRepository, IConfiguration configuration, ILogger<ProfileService> logger, IMapper mapper)
    {
        _profileRepository = profileRepository;
        _resumeApiUrl = configuration.GetValue<string>("ResumeApi");
        _logger = logger;
        _mapper = mapper;
    }

    public async Task<ApiResponse<string>> UploadAndProcessResumeAsync(VideoResumeFileDto file)
    {
        try
        {
            byte[] resumeBytes;

            using (var memoryStream = new MemoryStream())
            {
                await file.resumefile.CopyToAsync(memoryStream);
                resumeBytes = memoryStream.ToArray();
            }

            var entity = new VideoResumeFilesModel
            {
                Userid = file.userId,
                VideoResumeFile = resumeBytes
            };

            var result = await _profileRepository.UserVideoResume(entity);

            if (result.ReturnStatus == "success")
            {
                return new ApiResponse<string>(true, null, "User video resume uploaded successfully", ErrorCodes.Success);
            }

            return new ApiResponse<string>(false, null, "Failed to upload video resume", ErrorCodes.NotFound);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error uploading video resume");
            throw;
        }
    }



    private async Task<string> ConvertFileToBase64Async(IFormFile file)
    {
        using var memoryStream = new MemoryStream();
        await file.CopyToAsync(memoryStream);
        return Convert.ToBase64String(memoryStream.ToArray());
    }

    public async Task<ApiResponse<string>> CreateUserProfileAsync(UserProfileDto dto)
    {
        try
        {
            if (dto == null)
                return new ApiResponse<string>(false, null, "Invalid user profile input", ErrorCodes.BadRequest);
            var entity = _mapper.Map<UserProfileModel>(dto);

            // ✅ Convert Applicant date fields
            if (entity.applicant != null)
            {
                entity.applicant.Dateofavailability = DateConverter.ConvertToNullableDate(dto.Applicant?.Dateofavailability?.ToString()).ToString();
                entity.applicant.Dateofbirth = DateConverter.ConvertToNullableDate(dto.Applicant?.Dateofbirth?.ToString()).ToString();
            }

            // ✅ Convert each document's issue and expiry date
            if (entity.Documents != null && dto.Documents != null)
            {
                for (int i = 0; i < entity.Documents.Count; i++)
                {
                    entity.Documents[i].Certificateordocumentexpirydate =
                        DateConverter.ConvertToNullableDate(dto.Documents[i].Certificateordocumentexpirydate).ToString();
                    entity.Documents[i].Certificateordocumentissuedate =
                        DateConverter.ConvertToNullableDate(dto.Documents[i].Certificateordocumentissuedate).ToString();
                }
            }

            // ✅ Convert each sea experience's from/to date
            if (entity.Sea_experience != null && dto.Sea_experience != null)
            {
                for (int i = 0; i < entity.Sea_experience.Count; i++)
                {
                    entity.Sea_experience[i].Fromdate =
                        DateConverter.ConvertToNullableDate(dto.Sea_experience[i].Fromdate).ToString();
                    entity.Sea_experience[i].Todate =
                        DateConverter.ConvertToNullableDate(dto.Sea_experience[i].Todate).ToString();
                }
            }

            var result = await _profileRepository.CreateUserProfileAsync(entity);

            if (result.ReturnStatus == "success")
            {
                return new ApiResponse<string>(true, null, "User profile created successfully", ErrorCodes.Success);
            }

            return new ApiResponse<string>(false, null, "Failed to create user profile", ErrorCodes.Conflict);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error occurred in CreateUserProfileAsync");
            throw;
        }
    }


    public async Task<ApiResponse<string>> UserSaveFileAsync(UserResumeandImageDto dto)
    {
        try
        {
            if (dto == null)
                return new ApiResponse<string>(false, null, "Invalid user file input", ErrorCodes.BadRequest);

            // 🔁 Convert base64 to byte[] here
            byte[]? imageBytes = null;

            if (!string.IsNullOrWhiteSpace(dto.ImageFile))
            {
                try
                {
                    imageBytes = Convert.FromBase64String(dto.ImageFile);
                }
                catch (FormatException)
                {
                    return new ApiResponse<string>(false, null, "Invalid base64 image format", ErrorCodes.Conflict);
                }
            }
            byte[]? resumeBytes = null;

            if (!string.IsNullOrWhiteSpace(dto.ResumeFile))
            {
                try
                {
                    resumeBytes = Convert.FromBase64String(dto.ResumeFile);
                }
                catch (FormatException)
                {
                    return new ApiResponse<string>(false, null, "Invalid base64 image format", ErrorCodes.Conflict);
                }
            }

            // 🔧 Map to UserFilesModel with converted byte[]
            var entity = new UserFilesModel
            {
                Userid = dto.UserId,
                ResumeFile = resumeBytes,
                ImageFile = imageBytes,
                ImageUrl = dto.ImageUrl
            };

            var result = await _profileRepository.AddUserFilesAsync(entity);

            if (result.ReturnStatus == "success")
            {
                return new ApiResponse<string>(true, null, "User files updated successfully", ErrorCodes.Success);
            }

            return new ApiResponse<string>(false, null, "Failed to update user files", ErrorCodes.NotFound);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in UserSaveFileAsync");
            throw;
        }
    }

    public async Task<ApiResponse<UserProfileViewDto>> GetSeafarerProfileAsync(int userId)
    {
        try
        {
            var result = await _profileRepository.GetSeafarerProfileAsync(userId);

            if (result.ReturnStatus == "success" && result.ErrorCode == ErrorCodes.Success)
            {
                var dto = _mapper.Map<UserProfileViewDto>(result.Data);
                return new ApiResponse<UserProfileViewDto>(true, dto, "Profile retrieved successfully", ErrorCodes.Success);
            }

            return new ApiResponse<UserProfileViewDto>(false, null, ErrorCodes.NotFound, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in GetSeafarerProfileAsync");
            throw;
        }
    }

    public async Task<ApiResponse<string>> ReferFriendAsync(ReferAFriendDto dto)
    {
        try
        {
            if (dto == null || string.IsNullOrWhiteSpace(dto.FriendEmail))
                return new ApiResponse<string>(false, null, "Invalid input", ErrorCodes.BadRequest);

            var model = _mapper.Map<ReferAFriendModel>(dto);
            var result = await _profileRepository.ReferFriendAsync(model);

            if (result.ReturnStatus == "success")
            {
                //here email becuase db insertion is success
                return new ApiResponse<string>(true, null, "Referral successful", ErrorCodes.Success);
            }

            if (result.ReturnStatus == "already refered by someone")
                return new ApiResponse<string>(false, null, result.ReturnStatus, ErrorCodes.InvalidCredentials);

            return new ApiResponse<string>(false, null, "Referral failed", ErrorCodes.Conflict);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in ReferFriendAsync");
            throw;
        }
    }


    public async Task<ApiResponse<string>> UpdateUserExperianceAsync(List<SeaExperianceViewPatchDto> dtos)
    {
        try
        {
            if (dtos == null || dtos.Count == 0)
                return new ApiResponse<string>(false, null, "No experience items to update.", ErrorCodes.BadRequest);

            var models = new List<SeaExperianceViewPatchModel>(dtos.Count);
            var failures = new List<string>();

            for (int i = 0; i < dtos.Count; i++)
            {
                var d = dtos[i];
                var label = $"Item #{i + 1}{(d?.ExperianceId is int id ? $" (Id={id})" : string.Empty)}";

                if (d == null)
                {
                    failures.Add($"{label}: payload is null.");
                    continue;
                }

                // Determine insert vs update
                bool isInsert = !(d.ExperianceId.HasValue && d.ExperianceId.Value > 0);
                if (isInsert && !(d.userId.HasValue && d.userId.Value > 0))
                {
                    failures.Add($"{label}: userId is required for insert.");
                    continue;
                }

                // Map + sanitize (only fields you actually persist)
                var m = new SeaExperianceViewPatchModel
                {
                    userId = d.userId,
                    ExperianceId = d.ExperianceId,
                    CompanyName = Clean(d.CompanyName),
                    Duration = Clean(d.Duration),
                    DWT = Clean(d.DWT),
                    EngineType = Clean(d.EngineType),
                    FromDate = ConvertDateString(d.FromDate), // normalized "yyyy-MM-dd" or null
                    GT = Clean(d.GT),
                    IAS = Clean(d.IAS),
                    KW = Clean(d.KW),
                    Position = Clean(d.Position),
                    ToDate = ConvertDateString(d.ToDate),
                    VesselName = Clean(d.VesselName),
                    VesselType = Clean(d.VesselType),

                    // Optional extras (kept consistent even if not persisted by TVP)
                    Rank = Clean(d.Rank),
                    Period = Clean(d.Period),
                    Route = Clean(d.Route)
                };

                // Skip complete no-ops
                if (AllContentFieldsNull(m))
                {
                    failures.Add($"{label}: no updatable fields provided.");
                    continue;
                }

                models.Add(m);
            }

            if (models.Count == 0)
            {
                var msg = failures.Count > 0
                    ? $"No valid experience items to process. {string.Join("; ", failures.Take(10))}{(failures.Count > 10 ? " ..." : "")}"
                    : "No valid experience items to process.";
                return new ApiResponse<string>(false, null, msg, ErrorCodes.BadRequest);
            }

            // Call the TVP-based repository (one round-trip)
            var result = await _profileRepository.UpdateSeaExperiance(models);

            if (string.Equals(result.ReturnStatus, "success", StringComparison.OrdinalIgnoreCase))
            {
                var msg = failures.Count == 0
                    ? $"Processed {models.Count}/{dtos.Count} experience item(s) successfully."
                    : $"Processed {models.Count}/{dtos.Count}. Skipped/failed: {string.Join("; ", failures.Take(5))}{(failures.Count > 5 ? " ..." : "")}";
                return new ApiResponse<string>(true, null, msg, ErrorCodes.Success);
            }

            // no_change / error
            {
                var msg = $"Update failed ({result.ReturnStatus ?? "unknown"}). {string.Join("; ", failures.Take(10))}{(failures.Count > 10 ? " ..." : "")}";
                return new ApiResponse<string>(false, null, msg, result.ErrorCode ?? ErrorCodes.BadRequest);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error occurred in UpdateUserExperianceAsync");
            throw;
        }

        // --- helpers ---
        static string Clean(string s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

        static string ConvertDateString(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return null;
            var dt = DateConverter.ConvertToNullableDate(input);
            return dt?.ToString("yyyy-MM-dd"); // TVP helper will parse this back to DateTime
        }

        static bool AllContentFieldsNull(SeaExperianceViewPatchModel m) =>
            m.CompanyName == null &&
            m.Duration == null &&
            m.DWT == null &&
            m.EngineType == null &&
            m.FromDate == null &&
            m.GT == null &&
            m.IAS == null &&
            m.KW == null &&
            m.Position == null &&
            m.ToDate == null &&
            m.VesselName == null &&
            m.VesselType == null;
    }


    public async Task<ApiResponse<string>> UpdateUserDocumentCertificateAsync(List<CertificatesViewPatchDto> dtos)
    {
        try
        {
            if (dtos == null || dtos.Count == 0)
                return new ApiResponse<string>(false, null, "No certificates to update.", ErrorCodes.BadRequest);

            var models = new List<CertificatesViewPatchModel>(dtos.Count);
            var failures = new List<string>();
            int successCandidates = 0;

            for (int i = 0; i < dtos.Count; i++)
            {
                var d = dtos[i];
                var itemLabel = $"Item #{i + 1}{(d?.certificateId is int cid ? $" (Id={cid})" : string.Empty)}";

                if (d == null)
                {
                    failures.Add($"{itemLabel}: payload is null.");
                    continue;
                }

                // Insert vs Update validation:
                // - INSERT (certificateId <= 0 or null) requires userId > 0
                // - UPDATE (certificateId > 0) is fine; userId not required
                bool isInsert = !(d.certificateId.HasValue && d.certificateId.Value > 0);
                if (isInsert)
                {
                    if (!(d.userId.HasValue && d.userId.Value > 0))
                    {
                        failures.Add($"{itemLabel}: userId is required for insert.");
                        continue;
                    }
                }

                // Map + sanitize (only real fields)
                var m = new CertificatesViewPatchModel
                {
                    userId = d.userId,                         // needed for insert rows
                    certificateId = d.certificateId,
                    CertificateName = Clean(d.CertificateName),
                    IssuedCountry = Clean(d.IssuedCountry),
                    Status = Clean(d.Status),
                    DocumentNumber = Clean(d.DocumentNumber),
                    IssuedDate = Clean(d.IssuedDate),              // keep strings; TVP helper parses to DateTime?
                    ExpiryDate = Clean(d.ExpiryDate)
                };

                // Optional: guard that at least one field besides Id/userId is provided
                if (AllContentFieldsNull(m))
                {
                    failures.Add($"{itemLabel}: no updatable fields provided.");
                    continue;
                }

                models.Add(m);
                successCandidates++;
            }

            if (models.Count == 0)
            {
                var msg = failures.Count > 0
                    ? $"No valid certificates to process. {string.Join("; ", failures.Take(10))}{(failures.Count > 10 ? " ..." : "")}"
                    : "No valid certificates to process.";
                return new ApiResponse<string>(false, null, msg, ErrorCodes.BadRequest);
            }

            var result = await _profileRepository.UpdateCertificatesAsync(models);

            // Return aggregate response
            if (string.Equals(result.ReturnStatus, "success", StringComparison.OrdinalIgnoreCase))
            {
                var msg = failures.Count == 0
                    ? $"Processed {successCandidates}/{dtos.Count} certificate record(s) successfully."
                    : $"Processed {successCandidates}/{dtos.Count} certificate record(s). Skipped/failed: {string.Join("; ", failures.Take(5))}{(failures.Count > 5 ? " ..." : "")}";
                return new ApiResponse<string>(true, null, msg, ErrorCodes.Success);
            }

            // no_change / error cases
            {
                var msg = $"Update failed ({result.ReturnStatus ?? "unknown"}). {string.Join("; ", failures.Take(10))}{(failures.Count > 10 ? " ..." : "")}";
                return new ApiResponse<string>(false, null, msg, result.ErrorCode ?? ErrorCodes.BadRequest);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error occurred in UpdateUserDocumentCertificateAsync");
            throw;
        }

        // --- helpers ---
        static string Clean(string s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

        static bool AllContentFieldsNull(CertificatesViewPatchModel m) =>
            m.CertificateName == null
            && m.IssuedCountry == null
            && m.Status == null
            && m.DocumentNumber == null
            && m.IssuedDate == null
            && m.ExpiryDate == null;
    }

    public async Task<ApiResponse<CompanyViewDto>> GetcompanyProfileAsync(int companyId)
    {
        try
        {
            var result = await _profileRepository.fn_GetcompanyProfileAsync(companyId);

            if (result.ReturnStatus == "success" && result.ErrorCode == ErrorCodes.Success)
            {
                var dto = _mapper.Map<CompanyViewDto>(result.Data);
                return new ApiResponse<CompanyViewDto>(true, dto, "Company Profile retrieved successfully", ErrorCodes.Success);
            }

            return new ApiResponse<CompanyViewDto>(false, null, result.ErrorCode, ErrorCodes.NotFound);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in GetcompanyProfileAsync");
            throw;
        }
    }


    public async Task<ApiResponse<string>> GetVideoResumeBase64Async(int userId)
    {
        try
        {
            var res = await _profileRepository.GetVideoResumeAsync(userId); // ReturnResult<VideoResumeFilesModel>
            var bytes = res.Data?.VideoResumeFile;

            if (res.ReturnStatus != "success" || bytes == null || bytes.Length == 0)
                return new ApiResponse<string>(false, null, "No video resume found", ErrorCodes.NotFound);

            var base64 = Convert.ToBase64String(bytes);
            var dataUrl = $"data:video/webm;base64,{base64}";
            return new ApiResponse<string>(true, dataUrl, "OK", ErrorCodes.Success);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred in GetVideoResumeBase64Async");
            throw;
        }
    }

    public async Task<ApiResponse<UserFilesDto>> GetUserFilesAsync(int userId)
    {

        try
        {
            var result = await _profileRepository.GetUserFiles(userId); // your method from the question

            var status = result?.ReturnStatus ?? "error";
            var code = result?.ErrorCode ?? ErrorCodes.InternalServerError;

            // Success
            if (status.Equals("success", StringComparison.OrdinalIgnoreCase) &&
                (code == ErrorCodes.Success || code == "ERR200"))
            {
                var data = _mapper.Map<UserFilesDto>(result.Data);
                if (result!.Data is not null)
                    return new ApiResponse<UserFilesDto>(true, data, "Fetched user files.", ErrorCodes.Success);

                // edge case: success but no data
                return new ApiResponse<UserFilesDto>(false, null, "User files not found.", ErrorCodes.NoContent);
            }

            // Not found
            if (status.Equals("not_found", StringComparison.OrdinalIgnoreCase) || result?.Data is null)
                return new ApiResponse<UserFilesDto>(false, null, "bad request.", ErrorCodes.BadRequest);

            // Any other failure from repo
            return new ApiResponse<UserFilesDto>(false, null, "Failed to fetch user files.", ErrorCodes.Conflict);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in GetUserFilesAsync for UserId={UserId}", userId);
            throw;
        }
    }
}



