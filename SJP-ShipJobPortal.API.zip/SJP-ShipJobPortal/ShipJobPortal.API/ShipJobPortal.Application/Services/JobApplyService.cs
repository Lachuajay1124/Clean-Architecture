﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using ShipJobPortal.Application.DTOs;
using ShipJobPortal.Application.IServices;
using ShipJobPortal.Domain.Constants;
using ShipJobPortal.Domain.Entities;
using ShipJobPortal.Domain.Interfaces;

namespace ShipJobPortal.Application.Services;

public class JobApplyService : IJobApplyService
{
    private readonly IJobApplyRepository _ApplyRepository;
    private readonly IMapper _mapper;
    private readonly ILogger<JobApplyService> _logger;

    public JobApplyService(IJobApplyRepository applyRepository, IMapper mapper, ILogger<JobApplyService> logger)
    {
        _ApplyRepository = applyRepository;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ApiResponse<AppliedCandidatesListDto>> GetAppliedCandidatesAsync(GetAppliedCandidateRequestDto request)
    {
        try
        {
            var requestModel = _mapper.Map<GetAppliedCandidateRequestModel>(request);

            var result = await _ApplyRepository.GetAppliedCandidatesAsync(requestModel);

            if (string.Equals(result.ReturnStatus?.Trim(), "success", StringComparison.OrdinalIgnoreCase) && result.Data != null)
            {
                var dto = new AppliedCandidatesListDto
                {
                    pagination = _mapper.Map<PaginationDto>(result.Data.pagination),
                    CandidatesList = result.Data.CandidatesList != null
                        ? _mapper.Map<List<JobApplyDto>>(result.Data.CandidatesList)
                        : new List<JobApplyDto>()
                };

                var hasAny = dto.CandidatesList != null && dto.CandidatesList.Count > 0;
                if (hasAny)
                {
                    return new ApiResponse<AppliedCandidatesListDto>(true, dto, "Candidates fetched successfully.", ErrorCodes.Success);
                }
                return new ApiResponse<AppliedCandidatesListDto>(false, null, "No candidates found.", ErrorCodes.NotFound);
            }

            return new ApiResponse<AppliedCandidatesListDto>(false, null, "Failed to fetch applied candidates.", result.ErrorCode ?? ErrorCodes.InternalServerError);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error occurred in GetAppliedCandidatesAsync");
            throw;
        }
    }

    public async Task<ApiResponse<string>> ApplyJobAsync(JobApplyPostDto model)
    {
        try
        {
            var mappedModel = _mapper.Map<JobApplyPostModel>(model);

            var result = await _ApplyRepository.ApplyJobAsync(mappedModel);

            if (string.Equals(result.ReturnStatus?.Trim(), "success", StringComparison.OrdinalIgnoreCase) && result.ErrorCode == "ERR200")
            {
                return new ApiResponse<string>
                (
                    true,
                    result.Data,
                    "Job application submitted successfully",
                    ErrorCodes.Success
                );
            }
            else if (result.ErrorCode == "ERR_DUPLICATE_APPLICATION")
            {
                return new ApiResponse<string>
                (
                    false,
                    null,
                    "You have already applied for this job.",
                    result.ErrorCode
                );
            }
            else
            {
                return new ApiResponse<string>
                (
                    false,
                    null,
                    "Failed to submit job application.",
                    result.ErrorCode
                );
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in ApplyJobAsync service method");
            throw;
        }
    }

    public async Task<ApiResponse<AppliedJobsListDto>> GetAppliedJobsAsync(GetAppliedJobsForCandidateDto request)
    {
        try
        {
            var requestBody = _mapper.Map<GetAppliedJobsForCandidateModel>(request);
            var result = await _ApplyRepository.GetAppliedJobsAsync(requestBody);

            if (string.Equals(result.ReturnStatus?.Trim(), "success", StringComparison.OrdinalIgnoreCase) && result.Data != null)
            {
                var dto = new AppliedJobsListDto
                {
                    pagination = _mapper.Map<PaginationDto>(result.Data.pagination),
                    JobsList = result.Data.JobsList != null
                        ? _mapper.Map<List<AppliedJobDto>>(result.Data.JobsList)
                        : new List<AppliedJobDto>()
                };

                var hasAny = dto.JobsList != null && dto.JobsList.Count > 0;
                if (hasAny)
                {
                    return new ApiResponse<AppliedJobsListDto>(true, dto, "Applied jobs fetched successfully.", ErrorCodes.Success);
                }

                return new ApiResponse<AppliedJobsListDto>(false, null, "No jobs found.", ErrorCodes.NotFound);
            }

            return new ApiResponse<AppliedJobsListDto>(false, null, "Failed to fetch applied jobs.", result.ErrorCode ?? ErrorCodes.InternalServerError);

        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error occurred in GetAppliedJobsAsync");
            throw;
        }
    }


    public async Task<ApiResponse<string>> SaveJobAsync(JobWishListDto model)
    {
        try
        {
            var mappedModel = _mapper.Map<JobWishlistModel>(model);

            var result = await _ApplyRepository.WishlistJobAsync(mappedModel);

            if (string.Equals(result.ReturnStatus?.Trim(), "success", StringComparison.OrdinalIgnoreCase) && result.ErrorCode == "ERR200")
            {
                return new ApiResponse<string>
                (
                    true,
                    result.Data,
                    model.Mode.ToLower() == "save"
                        ? "Job added to favorites successfully!"
                        : "Job removed from favorites successfully!",
                    ErrorCodes.Success
                );
            }
            else
            {
                return new ApiResponse<string>
                (
                    false,
                    null,
                    "Failed to save job application.",
                    result.ErrorCode
                );
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in SaveJobAsync service method");
            throw;
        }
    }


    public async Task<ApiResponse<SavedJobsListDto>> GetSavedJobsAsync(GetSavedJobsForCandidateDto request)
    {
        try
        {
            var requestBody = _mapper.Map<GetSavedJobsForCandidateModel>(request);
            var result = await _ApplyRepository.GetSavedJobsAsync(requestBody);

            if (string.Equals(result.ReturnStatus?.Trim(), "success", StringComparison.OrdinalIgnoreCase) && result.Data != null)
            {
                var dto = new SavedJobsListDto
                {
                    pagination = _mapper.Map<PaginationDto>(result.Data.pagination),
                    JobsList = result.Data.JobsList != null
                        ? _mapper.Map<List<SavedJobsDto>>(result.Data.JobsList)
                        : new List<SavedJobsDto>()
                };

                var hasAny = dto.JobsList != null && dto.JobsList.Count > 0;
                if (hasAny)
                {
                    return new ApiResponse<SavedJobsListDto>(true, dto, "Saved jobs fetched successfully.", ErrorCodes.Success);
                }

                return new ApiResponse<SavedJobsListDto>(false, null, "No saved jobs found.", ErrorCodes.NotFound);
            }

            return new ApiResponse<SavedJobsListDto>(false, null, "Failed to fetch saved jobs.", result.ErrorCode ?? ErrorCodes.InternalServerError);

        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error occurred in GetSavedJobsAsync");
            throw;
        }
    }

    public async Task<ApiResponse<string>> UpdateJobApplicationStatusAsync(JobActiononCandidateDto model)
    {
        try
        {
            var mappedModel = _mapper.Map<JobActionOnCandidateModel>(model);
            var result = await _ApplyRepository.JobActionOnCandidateAsync(mappedModel);

            if (string.Equals(result.ReturnStatus?.Trim(), "success", StringComparison.OrdinalIgnoreCase) && result.ErrorCode == "ERR200")
            {
                return new ApiResponse<string>
                (
                    true,
                    result.Data,
                    model.jobAction == "shortlisted"
                        ? "candidate shortlisted successfully!"
                        : "candidate rejected successfully!",
                    ErrorCodes.Success
                );
            }
            else
            {
                return new ApiResponse<string>
                (
                    false,
                    null,
                    "Failed to job action on application.",
                    result.ErrorCode
                );
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in UpdateJobApplicationStatusAsync service method");
            throw;
        }
    }


}
