﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using ShipJobPortal.Application.DTOs;
using ShipJobPortal.Application.IServices;
using ShipJobPortal.Domain.Constants;
using ShipJobPortal.Domain.Entities;
using ShipJobPortal.Domain.Interfaces;

namespace ShipJobPortal.Application.Services
{
    public class DocumentService:IDocumentService
    {

        private readonly IDocumentRepository _DocumentRepository;
        private readonly IMapper _mapper;
        private readonly ILogger<DocumentService> _logger;

        public DocumentService(IDocumentRepository documentRepository, IMapper mapper, ILogger<DocumentService> logger)
        {
            _DocumentRepository = documentRepository;
            _mapper = mapper;
            _logger = logger; 
        }

        public async Task<ApiResponse<string>> LookUpItemAddAsync(LookupItemDto model)
        {
            try
            {
                var mappedModel = _mapper.Map<LookupItemModel>(model);
                var result = await _DocumentRepository.fn_InsertLookupItem(mappedModel);

                var status = result?.ReturnStatus?.Trim();
                var code = result?.ErrorCode?.Trim();

                if (string.Equals(status, "success", StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(code, "ERR200", StringComparison.OrdinalIgnoreCase))
                {
                    return new ApiResponse<string>(
                        true,
                        result?.Data,
                        "Item submitted successfully",
                        ErrorCodes.Success
                    );
                }
                else if (!string.IsNullOrEmpty(code))
                {
                    var friendly = MapSpErrorToMessage(code, model);
                    return new ApiResponse<string>(
                        false,
                        null,
                        friendly,         
                        code               
                    );
                }
                else
                {
                    return new ApiResponse<string>(
                        false,
                        null,
                        "Failed to submit item.",
                        "ERR_UNKNOWN"
                    );
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception in LookUpItemAddAsync");
                throw;
            }
        }


        public async Task<ApiResponse<string>> DocumentInsertUpdateAsync(DocumentSaveDto model)
        {
            try
            {
                var mappedModel = _mapper.Map<DocumentSaveModel>(model);
                var result = await _DocumentRepository.fn_InsertUpdateDocument(mappedModel);

                var status = result?.ReturnStatus?.Trim();
                var code = result?.ErrorCode?.Trim();

                if (string.Equals(status, "success", StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(code, "ERR200", StringComparison.OrdinalIgnoreCase))
                {
                    return new ApiResponse<string>(
                        true,
                        result?.Data,
                        "Document submitted successfully",
                        ErrorCodes.Success
                    );
                }

                else
                {
                    return new ApiResponse<string>(
                        false,
                        null,
                        "Failed to submit item.",
                        "ERR_UNKNOWN"
                    );
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception in LookUpItemAddAsync");
                throw;
            }
        }

        /// <summary>
        /// Maps stored-proc ErrorCode tokens to friendly messages.
        /// </summary>
        private static string MapSpErrorToMessage(string errorCode, LookupItemDto model)
        {
            switch (errorCode?.ToUpperInvariant())
            {
                case "ERR400_MODE_INVALID":
                    return "Invalid operation mode. Use INSERT to add or UPDATE to modify.";

                case "ERR400_MISSING_FIELDS":
                    return "Required fields are missing. Ensure itemCode, itemName, recordType, and sortOrder are provided.";

                case "ERR409_DUPLICATE_CODE_RECORDTYPE":
                    return $"An item with code '{model?.itemCode}' already exists for record type '{model?.recordType}'.";

                case "ERR404_NOT_FOUND":
                    return "The item you are trying to update was not found.";

                // If you implemented a client-side guard for sortOrder
                case "ERR400_SORTORDER_NOT_INT":
                    return "Sort order must be a valid number.";

                default:
                    // Covers ERR500_SQL_* and any future tokens
                    if (errorCode.StartsWith("ERR500_SQL_", StringComparison.OrdinalIgnoreCase))
                        return "A database error occurred while processing your request.";
                    return "Failed to submit item.";
            }
        }

    }
}
