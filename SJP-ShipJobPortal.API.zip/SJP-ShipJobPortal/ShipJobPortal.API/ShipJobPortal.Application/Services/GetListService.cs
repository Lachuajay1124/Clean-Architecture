﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using ShipJobPortal.Application.DTOs;
using ShipJobPortal.Application.IServices;
using ShipJobPortal.Domain.Constants;
using ShipJobPortal.Domain.Interfaces;

namespace ShipJobPortal.Application.Services
{
    public class GetListService : IGetListService
    {
        private readonly IGetListRepository _listRepository;
        private readonly IMapper _mapper;
        private readonly ILogger<GetListService> _logger;

        public GetListService(IGetListRepository listRepository, IMapper mapper, ILogger<GetListService> logger)
        {
            _listRepository = listRepository;
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<ApiResponse<IEnumerable<GetCountryListDto>>> GetAllCountryAsync()
        {
            try
            {
                var result = await _listRepository.GetAllCountriesAsync();
                if (string.Equals(result.ReturnStatus?.Trim(), "success", StringComparison.OrdinalIgnoreCase) && result.Data?.Any() == true)
                {
                    var dto = _mapper.Map<IEnumerable<GetCountryListDto>>(result.Data);
                    return new(true, dto, "Countries retrieved successfully.", ErrorCodes.Success);
                }
                return new(false, null, "No countries found.", ErrorCodes.NotFound);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetAllCountryAsync");
                throw;
            }
        }

        public async Task<ApiResponse<IEnumerable<GetStateListDto>>> GetAllStateAsync(int? countryId)
        {
            try
            {
                var cId = countryId ?? 0;
                var result = await _listRepository.GetAllStatesAsync(cId);
                if (string.Equals(result.ReturnStatus?.Trim(), "success", StringComparison.OrdinalIgnoreCase) && result.Data?.Any() == true)
                {
                    var dto = _mapper.Map<IEnumerable<GetStateListDto>>(result.Data);
                    return new(true, dto, "States retrieved successfully.", ErrorCodes.Success);
                }
                return new(false, null, "No states found.", ErrorCodes.NotFound);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetAllStateAsync");
                throw;
            }
        }

        public async Task<ApiResponse<IEnumerable<GetCityListDto>>> GetAllCityAsync(int? stateId)
        {
            try
            {
                var sId = stateId ?? 0;
                var result = await _listRepository.GetAllCitiesAsync(sId);
                if (string.Equals(result.ReturnStatus?.Trim(), "success", StringComparison.OrdinalIgnoreCase) && result.Data?.Any() == true)
                {
                    var dto = _mapper.Map<IEnumerable<GetCityListDto>>(result.Data);
                    return new(true, dto, "Cities retrieved successfully.", ErrorCodes.Success);
                }
                return new(false, null, "No cities found.", ErrorCodes.NotFound);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetAllCityAsync");
                throw;
            }
        }

        public async Task<ApiResponse<IEnumerable<VesselTypeDto>>> GetAllVesselTypeAsync()
        {
            try
            {
                var result = await _listRepository.GetAllVesselTypeAsync();
                if (string.Equals(result.ReturnStatus?.Trim(), "success", StringComparison.OrdinalIgnoreCase) && result.Data?.Any() == true)
                {
                    var dto = _mapper.Map<IEnumerable<VesselTypeDto>>(result.Data);
                    return new(true, dto, "Vessel types retrieved successfully.", ErrorCodes.Success);
                }
                return new(false, null, "No vessel types found.", ErrorCodes.NotFound);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetAllVesselTypeAsync");
                throw;
            }
        }

        public async Task<ApiResponse<IEnumerable<ContractDurationDto>>> GetAllContractDurationAsync()
        {
            try
            {
                var result = await _listRepository.GetAllContractDurationAsync();
                if (string.Equals(result.ReturnStatus?.Trim(), "success", StringComparison.OrdinalIgnoreCase) && result.Data?.Any() == true)
                {
                    var dto = _mapper.Map<IEnumerable<ContractDurationDto>>(result.Data);
                    return new(true, dto, "Contract duration fetched successfully.", ErrorCodes.Success);
                }
                return new(false, null, "No contract durations found.", ErrorCodes.NotFound);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetAllContractDurationAsync");
                throw;
            }
        }

        public async Task<ApiResponse<IEnumerable<PositionDto>>> GetAllPositionAsync(int? companyId)
        {
            try
            {
                var compId = companyId ?? 0;
                var result = await _listRepository.GetAllPositionAsync(compId);
                if (string.Equals(result.ReturnStatus?.Trim(), "success", StringComparison.OrdinalIgnoreCase) && result.Data?.Any() == true)
                {
                    var dto = _mapper.Map<IEnumerable<PositionDto>>(result.Data);
                    return new(true, dto, "Positions fetched successfully.", ErrorCodes.Success);
                }
                return new(false, null, "No positions found.", ErrorCodes.NotFound);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetAllPositionAsync");
                throw;
            }
        }

        public async Task<ApiResponse<IEnumerable<MobileCountryCodeDto>>> GetAllMobileCodesAsync()
        {
            try
            {
                var result = await _listRepository.GetAllMobileCountriesAsync();
                if (string.Equals(result.ReturnStatus?.Trim(), "success", StringComparison.OrdinalIgnoreCase) && result.Data?.Any() == true)
                {
                    var dto = _mapper.Map<IEnumerable<MobileCountryCodeDto>>(result.Data);
                    return new(true, dto, "Mobile country codes fetched successfully.", ErrorCodes.Success);
                }
                return new(false, null, "No mobile country codes found.", ErrorCodes.NotFound);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetAllMobileCodesAsync");
                throw;
            }
        }

        public async Task<ApiResponse<IEnumerable<DocumentListDto>>> GetDocumentsList()
        {
            try
            {
                var result = await _listRepository.GetDocumentListAsync();
                if (string.Equals(result.ReturnStatus?.Trim(), "success", StringComparison.OrdinalIgnoreCase) && result.Data?.Any() == true)
                {
                    var dto = _mapper.Map<IEnumerable<DocumentListDto>>(result.Data);
                    return new(true, dto, "Document list fetched successfully.", ErrorCodes.Success);
                }
                return new(false, null, "No documents found.", ErrorCodes.NotFound);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetDocumentsList");
                throw;
            }
        }

        public async Task<ApiResponse<IEnumerable<DocumentSectionDto>>> GetAllDocumentSectionAsync()
        {
            try
            {
                var result = await _listRepository.GetAllDocumentSectionAsync();
                if (string.Equals(result.ReturnStatus?.Trim(), "success", StringComparison.OrdinalIgnoreCase) && result.Data?.Any() == true)
                {
                    var dto = _mapper.Map<IEnumerable<DocumentSectionDto>>(result.Data);
                    return new(true, dto, "Document sections fetched successfully.", ErrorCodes.Success);
                }
                return new(false, null, "No document sections found.", ErrorCodes.NotFound);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetAllDocumentSectionAsync");
                throw;
            }
        }

        public async Task<ApiResponse<IEnumerable<DocumentCategoryDto>>> GetAllDocumentCategoryAsync()
        {
            try
            {
                var result = await _listRepository.GetAllDocumentCategoryAsync();
                if (string.Equals(result.ReturnStatus?.Trim(), "success", StringComparison.OrdinalIgnoreCase) && result.Data?.Any() == true)
                {
                    var dto = _mapper.Map<IEnumerable<DocumentCategoryDto>>(result.Data);
                    return new(true, dto, "Document categories fetched successfully.", ErrorCodes.Success);
                }
                return new(false, null, "No document categories found.", ErrorCodes.NotFound);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetAllDocumentCategoryAsync");
                throw;
            }
        }

        public async Task<ApiResponse<IEnumerable<DocumentTypeDto>>> GetAllDocumentTypeAsync()
        {
            try
            {
                var result = await _listRepository.GetAllDocumentTypeAsync();
                if (string.Equals(result.ReturnStatus?.Trim(), "success", StringComparison.OrdinalIgnoreCase) && result.Data?.Any() == true)
                {
                    var dto = _mapper.Map<IEnumerable<DocumentTypeDto>>(result.Data);
                    return new(true, dto, "Document types fetched successfully.", ErrorCodes.Success);
                }
                return new(false, null, "No document types found.", ErrorCodes.NotFound);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetAllDocumentTypeAsync");
                throw;
            }
        }

        public async Task<ApiResponse<IEnumerable<IndustryDto>>> GetAllIndustryAsync()
        {
            try
            {
                var result = await _listRepository.GetAllIndustryAsync();
                if (string.Equals(result.ReturnStatus?.Trim(), "success", StringComparison.OrdinalIgnoreCase) && result.Data?.Any() == true)
                {
                    var dto = _mapper.Map<IEnumerable<IndustryDto>>(result.Data);
                    return new(true, dto, "Industries fetched successfully.", ErrorCodes.Success);
                }
                return new(false, null, "No industries found.", ErrorCodes.NotFound);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetAllIndustryAsync");
                throw;
            }
        }
    }
}

