﻿using ShipJobPortal.Application.DTOs;

namespace ShipJobPortal.Application.IServices;

public interface IJobApplyService
{
    Task<ApiResponse<AppliedCandidatesListDto>> GetAppliedCandidatesAsync(GetAppliedCandidateRequestDto request);
    Task<ApiResponse<string>> ApplyJobAsync(JobApplyPostDto model);
    Task<ApiResponse<AppliedJobsListDto>> GetAppliedJobsAsync(GetAppliedJobsForCandidateDto request);
    Task<ApiResponse<string>> SaveJobAsync(JobWishListDto model);
    Task<ApiResponse<SavedJobsListDto>> GetSavedJobsAsync(GetSavedJobsForCandidateDto request);
    Task<ApiResponse<string>> UpdateJobApplicationStatusAsync(JobActiononCandidateDto model);
}
