﻿using ShipJobPortal.Application.DTOs;

namespace ShipJobPortal.Application.IServices
{
    public interface IDocumentService
    {
        Task<ApiResponse<string>> LookUpItemAddAsync(LookupItemDto model);
        Task<ApiResponse<string>> DocumentInsertUpdateAsync(DocumentSaveDto model);
    }
}
