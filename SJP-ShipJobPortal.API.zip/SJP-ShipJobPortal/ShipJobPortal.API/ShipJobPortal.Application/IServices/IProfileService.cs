﻿using ShipJobPortal.Application.DTOs;

namespace ShipJobPortal.Application.IServices;

public interface IProfileService
{
    Task<ApiResponse<string>> UploadAndProcessResumeAsync(VideoResumeFileDto file);
    //        Task<ReturnResult> CreateUserProfileAsync(UserProfileDto dto);
    Task<ApiResponse<string>> CreateUserProfileAsync(UserProfileDto dto);
    Task<ApiResponse<string>> UserSaveFileAsync(UserResumeandImageDto dto);
    Task<ApiResponse<UserProfileViewDto>> GetSeafarerProfileAsync(int userId);
    Task<ApiResponse<string>> ReferFriendAsync(ReferAFriendDto dto);
    Task<ApiResponse<string>> UpdateUserExperianceAsync(List< SeaExperianceViewPatchDto> dto);
    Task<ApiResponse<string>> UpdateUserDocumentCertificateAsync(List< CertificatesViewPatchDto> dto);
    Task<ApiResponse<CompanyViewDto>> GetcompanyProfileAsync(int userId);
    Task<ApiResponse<string>> GetVideoResumeBase64Async(int userId);
    Task<ApiResponse<UserFilesDto>> GetUserFilesAsync(int userId);


}
