import os
import sys
from dotenv import load_dotenv, find_dotenv


load_dotenv(find_dotenv())

#*************************************************************************************************************************************************

if getattr(sys, 'frozen', False):
    BASE_DIR = sys._MEIPASS  # Use internal temp directory for bundled files
    EXE_DIR = os.path.dirname(sys.executable)  # For things like .env or temp files
else:
    BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    EXE_DIR = BASE_DIR

#*********************************************************************************************************************************************
ASSETS_DIR = os.path.join(BASE_DIR, "Assets")
TEMP_DIR = os.path.join(EXE_DIR, "temp")
os.makedirs(TEMP_DIR, exist_ok=True)
LOG_DIR = os.path.join(EXE_DIR, 'logs', 'app.log')
os.makedirs(TEMP_DIR, exist_ok=True)

#*********************************************************************************************************************************************

FLASK_HOST = os.getenv("FLASK_HOST")
FLASK_PORT = os.getenv("FLASK_PORT")
FLASK_THREADS = os.getenv("THREADS")
FLASK_CONNECTION_LIMIT = os.getenv("CONNECTION_LIMIT")
FLASK_BACKLOG = os.getenv("BACKLOG")

MAX_FILE_SIZE_MB=32

#*************************************************************************************************************************************************

# DB details
DB_DRIVER = os.getenv("DB_DRIVER")
DB_USER = os.getenv("DB_USER")
DB_PASSWORD = os.getenv("DB_PASSWORD")
DB_NAME = os.getenv("DB_NAME")
DB_SERVER = os.getenv("DB_SERVER")
DB_ENCRYPT = os.getenv("DB_ENCRYPT")

TABLES_SCHEMA = os.getenv("TABLES_SCHEMA")
SP_SCHEMA = os.getenv("SP_SCHEMA")
INDEX_SCHEMA = os.getenv("INDEX_SCHEMA")
TABLES_SCHEMA_PATH = os.path.join(ASSETS_DIR, TABLES_SCHEMA)
SP_SCHEMA_PATH = os.path.join(ASSETS_DIR, SP_SCHEMA)
INDEX_SCHEMA_PATH = os.path.join(ASSETS_DIR, INDEX_SCHEMA)

#*********************************************************************************************************************************************

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

#*************************************************************************************************************************************************

JWT_KEY = os.getenv("JWT_KEY")
JWT_ISSUER = os.getenv("JWT_ISSUER")
JWT_AUDIENCE = os.getenv("JWT_AUDIENCE")
JWT_VALIDITY = int(os.getenv("JWT_VALIDITY"))
REFRESH_VALIDITY = int(os.getenv("REFRESH_VALIDITY"))
DEV_INSECURE_COOKIES = os.getenv("DEV_INSECURE_COOKIES")
