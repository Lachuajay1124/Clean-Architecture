import logging
import os
import io
import sys

from config.settings import LOG_DIR

#*************************************************************************************************************************************************

def setup_logger(name='app_logger', log_file=LOG_DIR, level=logging.INFO):

    logger = logging.getLogger(name)
    logger.setLevel(level)

    # Avoid duplicate handlers if already initialized
    if not logger.handlers:
        # Ensure log directory exists
        os.makedirs(os.path.dirname(log_file), exist_ok=True)

        # File handler
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

        # Safe stdout handler (only if running in terminal mode)
        if sys.stdout and hasattr(sys.stdout, "buffer"):
            try:
                utf8_stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
                stream_handler = logging.StreamHandler(utf8_stdout)
                stream_handler.setFormatter(formatter)
                logger.addHandler(stream_handler)
            except Exception:
                pass  # fallback: don't attach stdout stream

    return logger

#*************************************************************************************************************************************************

logger = setup_logger()