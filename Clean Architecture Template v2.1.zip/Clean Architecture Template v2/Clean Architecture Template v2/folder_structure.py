import os

def save_tree(path, file, indent=''):
    for i, name in enumerate(sorted(os.listdir(path))):
        fullpath = os.path.join(path, name)
        if name in ['__pycache__', '.git', 'venv']:  # skip common noise
            continue
        is_last = i == len(os.listdir(path)) - 1
        file.write(f"{indent}{'└── ' if is_last else '├── '}{name}\n")
        if os.path.isdir(fullpath):
            save_tree(fullpath, file, indent + ('    ' if is_last else '│   '))

with open("folder_structure.txt", "w", encoding='utf-8') as f:
    f.write("Project Structure\n")
    f.write("=================\n")
    save_tree(".", f)
