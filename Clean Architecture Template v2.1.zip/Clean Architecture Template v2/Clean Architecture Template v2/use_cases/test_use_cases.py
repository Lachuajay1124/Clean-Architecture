from flask import jsonify

def test():
    return jsonify({"message":"test"}), 200
