import secrets
import bcrypt
from flask import request, jsonify, make_response

from config.logger import logger
from config.settings import REFRESH_VALIDITY
from shared.db import get_db_connection

from shared.auth import (
    REFRESH_COOKIE,
    issue_access_jwt,         # -> (token, exp_ts)
    set_login_cookies,        # sets access+refresh cookies (handles secure/dev flags)
    clear_auth_cookies,       # removes both cookies
    _db_refresh_replace,   # refresh flow (validate, rotate, mint new access)
    _db_refresh_insert,       # insert hashed refresh into DB
    _db_refresh_delete_by_hash,
    _db_refresh_get_by_hash,
    _hash_refresh,
    _ts
)

#*********************************************************************************************************************************************

def check_login(data):
    
    """
    Verify username/password, then:
        - issue access JWT + opaque refresh
        - store hashed refresh in DB
        - set cookies
        - return { Username, Role, CompanyID, Modules }
    """
    
    logger.info("📥 POST /verify_login request received")

    Username = (data or {}).get("Username")
    Password = (data or {}).get("Password")

    if not Username or not Password:
        logger.warning("❗ Missing Username or Password")
        return jsonify({"error": "Missing Username or Password"}), 400

    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # 1) Fetch stored hash
        cursor.execute("EXEC SP_GetPasswordHashByUser ?", (Username,))
        row = cursor.fetchone()
        if not row:
            logger.warning("⚠️ No login record for %s", Username)
            return jsonify({"error": "Invalid username or password"}), 401

        stored_hash = row.PasswordHash
        stored_hash_bytes = stored_hash.encode("utf-8") if isinstance(stored_hash, str) else stored_hash
        if not bcrypt.checkpw(Password.encode("utf-8"), stored_hash_bytes):
            logger.warning("⚠️ Password mismatch for %s", Username)
            return jsonify({"error": "Invalid username or password"}), 401

        # 2) Update last-login, fetch CompanyID & Role
        cursor.execute("EXEC SP_UpdateLastLoginAndGetCompanyAndRole ?", (Username,))
        info = cursor.fetchone()
        conn.commit()
        if not info:
            logger.error("❌ Failed to fetch CompanyID/Role for %s", Username)
            return jsonify({"error": "Login succeeded but failed to fetch company or role"}), 500

        company_id = info.CompanyID
        Role = info.Role

        # 3) Issue access + refresh; store hashed refresh
        access_token, access_exp = issue_access_jwt(sub=Username, role=Role, companyid=company_id)
        refresh_raw = secrets.token_urlsafe(48)
        refresh_exp = _ts() + int(REFRESH_VALIDITY)
        _db_refresh_insert(username=Username, token_hash=_hash_refresh(refresh_raw), exp_ts=refresh_exp)

        # 4) Modules for the UI
        modules = get_modules_for_role(Role)

        # 5) Set cookies & respond
        resp = make_response(
            jsonify({
                "message": "Login successful",
                "Username": Username,
                "Role": Role,
                "CompanyID": company_id,
                "Modules": modules
            }),
            200,
        )
        resp = set_login_cookies(
            resp,
            access_token=access_token, access_exp=access_exp,
            refresh_token=refresh_raw,  refresh_exp=refresh_exp,
        )
        return resp

    except Exception:
        logger.exception("❌ Error during login verification")
        return jsonify({"error": "Internal server error"}), 500

    finally:
        try:
            cursor.close()
            conn.close()
        except Exception:
            pass

#*********************************************************************************************************************************************

def refresh_tokens():
    
    """
    POST /auth/refresh
        - If refresh token valid and not expired -> rotate refresh token and issue new access; set cookies
        - If refresh invalid/expired -> clear both cookies and return 401
    """

    conn = None
    cursor = None
    
    try:
        raw = request.cookies.get(REFRESH_COOKIE)
        if not raw:
            resp = make_response(jsonify({"error": "missing_refresh"}), 401)
            return clear_auth_cookies(resp)

        token_hash = _hash_refresh(raw)
        row = _db_refresh_get_by_hash(token_hash)
        now = _ts()

        if not row:
            logger.warning("🔄 refresh invalid (no DB match)")
            resp = make_response(jsonify({"error": "invalid_refresh"}), 401)
            return clear_auth_cookies(resp)

        username = row.Username
        exp_ts = int(row.ExpiresAt)

        if now >= exp_ts:
            logger.info("🔄 refresh expired for user=%s", username)
            _db_refresh_delete_by_hash(token_hash)
            resp = make_response(jsonify({"error": "refresh_expired"}), 401)
            return clear_auth_cookies(resp)

        # Rotate refresh token
        new_refresh_raw = secrets.token_urlsafe(48)
        new_refresh_exp = now + int(REFRESH_VALIDITY)
        rotated = _db_refresh_replace(token_hash, _hash_refresh(new_refresh_raw), new_refresh_exp)
        if not rotated:
            logger.warning("🔄 refresh rotation failed (possible reuse) user=%s", username)
            resp = make_response(jsonify({"error": "invalid_refresh"}), 401)
            return clear_auth_cookies(resp)

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("EXEC SP_UpdateLastLoginAndGetCompanyAndRole ?", (username,))
        info = cursor.fetchone()
        conn.commit()
        if not info:
            logger.error("❌ Failed to fetch CompanyID/Role for %s", username)
            return jsonify({"error": "Login succeeded but failed to fetch company or role"}), 500

        company_id = info.CompanyID
        Role = info.Role

        # Issue new access JWT (include role/companyid if desired)
        access, access_exp = issue_access_jwt(sub=username, role=Role, companyid=company_id)

        resp = make_response(jsonify({"ok": True}), 200)
        set_login_cookies(
            resp,
            access_token=access, access_exp=access_exp,
            refresh_token=new_refresh_raw, refresh_exp=new_refresh_exp
        )
        return resp

    except Exception:
        logger.exception("❌ Error in /auth/refresh")
        return jsonify({"error": "Internal server error"}), 500

    finally:
        try:
            if cursor:
                cursor.close()
            if conn:
                conn.close()
        except Exception:
            pass

#*********************************************************************************************************************************************

def confirm_logout():
    
    """
    Logout:
        - Delete the refresh row if present
        - Clear both cookies
    """

    raw = request.cookies.get("refresh_token")
    if raw:
        try:
            _db_refresh_delete_by_hash(_hash_refresh(raw))
        except Exception:
            logger.warning("⚠️ Failed to delete refresh row during logout", exc_info=True)

    resp = make_response(jsonify({"message": "Logout Successful"}), 200)
    clear_auth_cookies(resp)
    return resp

#*********************************************************************************************************************************************

def get_modules_for_role(role_name: str):

    """
    Returns a list of modules & permissions for the given role.
    Calls: EXEC ES.SP_GetModulesByRole ?
    """
    
    if not role_name:
        logger.warning("❗ Missing role_name")
        return []

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("EXEC ES.SP_GetModulesByRole ?", (role_name,))
        rows = cursor.fetchall()

        modules = []
        for r in rows:
            modules.append({
                "ModuleID":          r.ModuleID,
                "ParentModuleID":    r.ParentModuleID,
                "ModuleName":        r.ModuleName,
                "ModuleDescription": r.ModuleDescription,
                "ModulePath":        r.ModulePath,
                "SortOrder":         r.SortOrder,
                "IsDefault":         bool(r.IsDefault),
                "Hide":              bool(r.Hide),
                "ViewAllowed":       bool(r.ViewAllowed),
                "AddAllowed":        bool(r.AddAllowed),
                "EditAllowed":       bool(r.EditAllowed),
                "DeleteAllowed":     bool(r.DeleteAllowed),
                "PrintAllowed":      bool(r.PrintAllowed),
                "EmailAllowed":      bool(r.EmailAllowed),
            })
        return modules

    except Exception:
        logger.exception("❌ Failed to fetch modules for role")
        return []

    finally:
        try:
            cursor.close()
            conn.close()
        except Exception:
            pass
