from waitress import serve

from framework_drivers.flask_app.routes import create_app
from framework_drivers.flask_app.init_db import setup_database

from config.settings import FLASK_HOST, FLASK_PORT, FLASK_THREADS, FLASK_CONNECTION_LIMIT, FLASK_BACKLOG
from config.logger import setup_logger

from framework_drivers.flask_app.mutex import enforce_single_instance

#*************************************************************************************************************************************************

logger= setup_logger()
print("📦 Flask application initializing...")
logger.info("📦 Flask application initializing...")

app = create_app()

#*************************************************************************************************************************************************

if __name__ == "__main__":
    enforce_single_instance()
    setup_database()
    # for development
    logger.info("🚀 Starting Flask server on http://localhost:5000")
    print("🚀 Starting Flask server on http://localhost:5021")
    app.run(host="0.0.0.0", port=5021, ssl_context="adhoc")
    # for production
    #logger.info(f"🚀 Starting server on http://{FLASK_HOST}:{FLASK_PORT}")
    #serve(app,
    #        host=FLASK_HOST,
    #        port=FLASK_PORT,
    #        threads=FLASK_THREADS,
    #        connection_limit=FLASK_CONNECTION_LIMIT,
    #        backlog=FLASK_BACKLOG
    #        )
