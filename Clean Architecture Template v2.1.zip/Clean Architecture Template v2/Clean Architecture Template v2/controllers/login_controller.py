from flask import request

from use_cases import login_use_cases

# ****************************************************************************************

def verify_login():
    data = request.json
    return login_use_cases.check_login(data)

def logout():
    # Clears both cookies and revokes refresh token (if present)
    return login_use_cases.confirm_logout()

def refresh_route():
    # Validates refresh cookie, rotates it, and mints a new access token
    return login_use_cases.refresh_tokens()
