from flask import jsonify, Response

from use_cases.test_use_cases import test

#****************************************************************************************

def tester():
    return test()
