from flask import jsonify, Response

from config.settings import LOG_DIR

#****************************************************************************************

def health_check():
    return jsonify({"status": "ok"}), 200

def get_log_content():
    try:
        with open(LOG_DIR, 'r', encoding='utf-8') as log_file:
            content = log_file.read()
        return Response(content, mimetype='text/plain')
    except FileNotFoundError:
        return {'error': 'Log file not found'}, 404