# auth_tokens.py

import jwt
import secrets
import hashlib
import time
import datetime as dt
from functools import wraps
from flask import request, jsonify, make_response, g

from config.logger import logger
from config.settings import (
    JWT_KEY, JWT_ISSUER, JWT_AUDIENCE, JWT_VALIDITY, REFRESH_VALIDITY, DEV_INSECURE_COOKIES
)
from shared.db import get_db_connection

#*************************************************************************************************************************************************

# ---------------------------
# Config / constants
# ---------------------------

JWT_ALG = "HS256"  # tight allow-list
ACCESS_COOKIE = "access_token"
REFRESH_COOKIE = "refresh_token"
ACCESS_COOKIE_PATH = "/"
REFRESH_COOKIE_PATH = "/"  # narrow scope to refresh endpoint
SAMESITE_ACCESS = "None"
SAMESITE_REFRESH = "None"
LEEWAY_SECS = 10  # clock skew tolerance
REQUIRE_TYP_AT = "at+jwt"  # typed tokens (RFC 8725 guidance)

#*************************************************************************************************************************************************

# ---------------------------
# Helpers
# ---------------------------

def _utc_now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)

def _ts() -> int:
    return int(_utc_now().timestamp())

def _hash_refresh(raw: str) -> str:
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()

def _precheck_header(token: str, expected_typ: str | None = REQUIRE_TYP_AT) -> dict:
    """Minimal RFC 8725-ish header checks for JWS (3-part)."""
    if token.count(".") == 4:
        # This guard only handles signed JWS in this example
        raise jwt.InvalidTokenError("Encrypted (JWE) tokens are not accepted")
    try:
        hdr = jwt.get_unverified_header(token)
    except Exception as e:
        raise jwt.DecodeError(f"Malformed JWT header: {e}")
    alg = hdr.get("alg")
    if not alg or alg == "none" or alg != JWT_ALG:
        raise jwt.InvalidTokenError("Disallowed or missing algorithm")
    if expected_typ is not None and hdr.get("typ") != expected_typ:
        raise jwt.InvalidTokenError("Unexpected or missing 'typ' header")
    if any(k in hdr for k in ("jku", "x5u", "crit")):
        # Hardening: never auto-fetch keys or accept crit headers here
        raise jwt.InvalidTokenError("Disallowed JOSE headers present")
    return hdr

#*************************************************************************************************************************************************

# ---------------------------
# Access token (JWT) issuance/verification
# ---------------------------

def issue_access_jwt(*, sub: str, role: str | None = None, companyid: int | None = None) -> tuple[str, int]:
    """
    Create a short-lived access JWT (HS256) with required claims.
    Returns (token, exp_ts).
    """
    now = _ts()
    exp = now + int(JWT_VALIDITY)
    claims = {
        "iss": JWT_ISSUER,
        "aud": JWT_AUDIENCE,
        "sub": sub,
        "iat": now,
        "nbf": now,
        "exp": exp,
    }
    if role is not None:
        claims["role"] = role
    if companyid is not None:
        claims["companyid"] = companyid

    headers = {"typ": REQUIRE_TYP_AT, "alg": JWT_ALG}
    token = jwt.encode(claims, JWT_KEY, algorithm=JWT_ALG, headers=headers)
    logger.info("access jwt header: %s", jwt.get_unverified_header(token))

    logger.info("🔑 Issued access JWT for sub=%s exp=%s", sub, exp)
    return token, exp

def verify_access_jwt(token: str) -> dict:
    """
    Verify & decode the access JWT. Raises jwt.* on failure/expiry.
    """
     
    logger.info("verifying jwt header: %s", jwt.get_unverified_header(token))
    _precheck_header(token, expected_typ=REQUIRE_TYP_AT)
    payload = jwt.decode(
        token,
        JWT_KEY,
        algorithms=[JWT_ALG],
        issuer=JWT_ISSUER,
        audience=JWT_AUDIENCE,
        leeway=LEEWAY_SECS,
        options={"require": ["exp", "iat", "nbf"]},
    )
    # sanity: iat not far in future
    now = _ts()
    if int(payload.get("iat", now)) > now + LEEWAY_SECS:
        raise jwt.InvalidTokenError("'iat' is in the future")
    return payload

#*************************************************************************************************************************************************

# ---------------------------
# Cookie helpers
# ---------------------------

def set_login_cookies(resp, *, access_token: str, access_exp: int, refresh_token: str, refresh_exp: int):
    # Access cookie (sent to most routes)
    resp.set_cookie(
        ACCESS_COOKIE, access_token,
        httponly=True,
        secure=True,   # ← secure only in prod
        samesite=SAMESITE_ACCESS
    )
    resp.set_cookie(
        REFRESH_COOKIE, refresh_token,
        httponly=True,
        secure=True,   # ← secure only in prod
        samesite=SAMESITE_REFRESH,
        max_age=max(1, refresh_exp - _ts())
    )
    return resp

def clear_auth_cookies(resp):
    resp.delete_cookie(ACCESS_COOKIE, path=ACCESS_COOKIE_PATH)
    resp.delete_cookie(REFRESH_COOKIE, path=REFRESH_COOKIE_PATH)
    return resp

def issue_login_tokens_and_set_cookies(*, username: str, role: str | None, companyid: int | None):
    """
    Call this in your /login handler after verifying credentials.
    - Issues access JWT and opaque refresh token
    - Stores hashed refresh in DB
    - Returns a Flask response with both cookies set
    """
    access, access_exp = issue_access_jwt(sub=username, role=role, companyid=companyid)
    refresh_raw = secrets.token_urlsafe(48)
    refresh_exp = _ts() + int(REFRESH_VALIDITY)
    _db_refresh_insert(username=username, token_hash=_hash_refresh(refresh_raw), exp_ts=refresh_exp)

    resp = make_response(jsonify({"ok": True, "message": "logged in"}), 200)
    set_login_cookies(resp,
                    access_token=access, access_exp=access_exp,
                    refresh_token=refresh_raw, refresh_exp=refresh_exp)
    return resp

#*************************************************************************************************************************************************

# ---------------------------
# Decorator: require valid access token
# ---------------------------

def jwt_access_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        token = request.cookies.get(ACCESS_COOKIE)
        if not token:
            return (
                jsonify({"error": "missing_token"}),
                401,
                {"WWW-Authenticate": 'Bearer error="invalid_token", error_description="missing"'}
            )
        try:
            payload = verify_access_jwt(token)
            # expose identity to route code
            g.jwt = payload
            return fn(*args, **kwargs)

        except jwt.ExpiredSignatureError:
            logger.info("⌛ access token expired")
            return (
                jsonify({"error": "token_expired"}),
                401,
                {"WWW-Authenticate": 'Bearer error="invalid_token", error_description="expired"'}
            )
        except jwt.InvalidTokenError as e:
            logger.warning("🔐 invalid access token: %s", e)
            return (
                jsonify({"error": "invalid_token"}),
                401,
                {"WWW-Authenticate": 'Bearer error="invalid_token", error_description="invalid"'}
            )
        except Exception as e:
            logger.exception("JWT check failed")
            return jsonify({"error": "invalid_token"}), 401
    return wrapper

#*************************************************************************************************************************************************

# ---------------------------
# Refresh token helpers
# ---------------------------

def _db_refresh_insert(username: str, token_hash: str, exp_ts: int) -> None:
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO AuthRefresh (TokenHash, Username, ExpiresAt, CreatedAt) VALUES (?, ?, ?, ?)",
                (token_hash, username, exp_ts, _ts())
            )
        conn.commit()
    finally:
        conn.close()

def _db_refresh_get_by_hash(token_hash: str):
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT Username, ExpiresAt FROM AuthRefresh WHERE TokenHash = ?",
                (token_hash,)
            )
            row = cur.fetchone()
        return row  # row.Username, row.ExpiresAt or None
    finally:
        conn.close()

def _db_refresh_delete_by_hash(token_hash: str) -> int:
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM AuthRefresh WHERE TokenHash = ?", (token_hash,))
            n = cur.rowcount
        conn.commit()
        return n
    finally:
        conn.close()

def _db_refresh_replace(old_hash: str, new_hash: str, new_exp: int) -> bool:
    """
    Rotate: replace existing row (by old hash) with new hash+expiry.
    Returns True if rotation succeeded.
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            # Ensure atomicity with a simple delete+insert in a tx.
            cur.execute("SELECT Username FROM AuthRefresh WHERE TokenHash = ?", (old_hash,))
            row = cur.fetchone()
            if not row:
                return False
            username = row.Username

            cur.execute("DELETE FROM AuthRefresh WHERE TokenHash = ?", (old_hash,))
            cur.execute(
                "INSERT INTO AuthRefresh (TokenHash, Username, ExpiresAt, CreatedAt) VALUES (?, ?, ?, ?)",
                (new_hash, username, new_exp, _ts())
            )
        conn.commit()
        return True
    finally:
        conn.close()
        
#*************************************************************************************************************************************************

# ---------------------------
# Refresh flow
# ---------------------------

def handle_refresh_request():
    
    """
    Call this in your POST /auth/refresh route.
    Behavior:
        - If refresh token valid and not expired -> rotate refresh token and issue new access; set cookies
        - If refresh invalid/expired -> clear both cookies and return 401
    """
    
    raw = request.cookies.get(REFRESH_COOKIE)
    if not raw:
        # No refresh to use
        resp = make_response(jsonify({"error": "missing_refresh"}), 401)
        return clear_auth_cookies(resp)

    token_hash = _hash_refresh(raw)
    row = _db_refresh_get_by_hash(token_hash)
    now = _ts()

    if not row:
        logger.warning("🔄 refresh invalid (no DB match)")
        resp = make_response(jsonify({"error": "invalid_refresh"}), 401)
        return clear_auth_cookies(resp)

    username = row.Username
    exp_ts = int(row.ExpiresAt)

    if now >= exp_ts:
        logger.info("🔄 refresh expired for user=%s", username)
        _db_refresh_delete_by_hash(token_hash)
        resp = make_response(jsonify({"error": "refresh_expired"}), 401)
        return clear_auth_cookies(resp)

    # Valid: rotate refresh and issue new access
    new_refresh_raw = secrets.token_urlsafe(48)
    new_refresh_exp = now + int(REFRESH_VALIDITY)
    rotated = _db_refresh_replace(token_hash, _hash_refresh(new_refresh_raw), new_refresh_exp)
    if not rotated:
        # Race/reuse detected: treat as invalid and clear cookies
        logger.warning("🔄 refresh rotation failed (possible reuse) user=%s", username)
        resp = make_response(jsonify({"error": "invalid_refresh"}), 401)
        return clear_auth_cookies(resp)

    # (Optional) fetch role/companyid here if you want them in access JWT; omitted for brevity
    access, access_exp = issue_access_jwt(sub=username)

    resp = make_response(jsonify({"ok": True}), 200)
    set_login_cookies(resp,
                        access_token=access, access_exp=access_exp,
                        refresh_token=new_refresh_raw, refresh_exp=new_refresh_exp)
    return resp
