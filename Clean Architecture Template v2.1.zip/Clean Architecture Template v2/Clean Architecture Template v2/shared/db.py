import pyodbc
import re

from config.logger import logger
from config.settings import DB_DRIVER, DB_SERVER, DB_NAME, DB_USER, DB_PASSWORD, DB_ENCRYPT

#*************************************************************************************************************************************************

# DB Initialization and Setup
def get_db_connection():
    
    """Create a new database connection every time it's needed."""
    logger.info("🔌 Attempting to connect to the database...")

    try:
        connection = pyodbc.connect(
        f"DRIVER={DB_DRIVER};"
        f"SERVER={DB_SERVER};"
        f"DATABASE={DB_NAME};"
        f"UID={DB_USER};"
        f"PWD={DB_PASSWORD};"
        f"Encrypt={DB_ENCRYPT}"
        f"TrustServerCertificate=yes;"
        )
        logger.info(f"✅ Database connection established to '{DB_NAME}' on server '{DB_SERVER}'")
        return connection

    except Exception as e:
        logger.error(f"❌ Failed to connect to database '{DB_NAME}' on server '{DB_SERVER}': {e}")
        return None

#*************************************************************************************************************************************************

def execute_create_tables(file_path):

    conn = get_db_connection()
    cursor = conn.cursor()
    logger.info("✅ Connected to database")

    with open(file_path, 'r', encoding='utf-8') as f:
        ddl_text = f.read()

    create_statements = extract_create_table_statements(ddl_text)
    existing_tables = get_existing_table_names(cursor)

    for stmt in create_statements:
        # inside execute_create_tables, instead of re.search(r"CREATE\s+TABLE\s+(\w+)", ...)
        match = re.search(
            r"CREATE\s+TABLE\s+((?:\[[^\]]+\]|\w+)(?:\s*\.\s*(?:\[[^\]]+\]|\w+))?)",
            stmt,
            flags=re.IGNORECASE
        )
        if not match:
            logger.error("⚠️ Could not extract table name from statement, skipping.")
            continue

        full_name = match.group(1)            # e.g. "DM.Message" or "[DM].[Message]"
        table_name = full_name.split('.')[-1]  # "Message"
        table_name = table_name.strip('[]').lower()
        if table_name.lower() in existing_tables:
            logger.info(f"ℹ️ Table '{table_name}' already exists, skipping.")
        else:
            try:
                cursor.execute(stmt)
                conn.commit()
                logger.info(f"✅ Created table: {table_name}")
            except Exception as e:
                logger.error(f"❌ Failed to create table {table_name}: {e}")

    cursor.close()
    conn.close()
    logger.info("🎯 Schema sync complete.")

#*************************************************************************************************************************************************

def get_existing_table_names(cursor):

    cursor.execute("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE'")
    return set(row.TABLE_NAME.lower() for row in cursor.fetchall())

#*************************************************************************************************************************************************

def extract_create_table_statements(sql_text):

    """
    Extracts all CREATE TABLE statements from a raw SQL file.
    Returns a list of full SQL CREATE TABLE strings.
    """
    
    pattern = re.compile(
        r"""
        (                               # start capture
            CREATE \s+ TABLE \s+          # the CREATE TABLE keywords
            (?:\[[^\]]+\]|\w+)            #   schema or table name
            (?: \s* \. \s* (?:\[[^\]]+\]|\w+))?  # optional .schema
            \s* \(                        # opening parenthesis of column list
                [\s\S]*?                    # lazily consume anything (incl. newlines)
            \)                            # the matching closing parenthesis
            \s* ;                         # the semicolon terminator
        )                               # end capture
        """,
        re.IGNORECASE | re.VERBOSE
    )
    return [m.group(1) for m in pattern.finditer(sql_text)]

#*************************************************************************************************************************************************

def execute_stored_procedures_from_file(filepath):
    
    conn = get_db_connection()
    cursor = conn.cursor()

    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Normalize line endings
    content = re.sub(r'\r\n|\r', '\n', content).strip()

    # Split on each CREATE OR ALTER PROCEDURE (keep the header in the result)
    chunks = re.split(r'(?=CREATE\s+OR\s+ALTER\s+PROCEDURE)', content, flags=re.IGNORECASE)

    # Filter out empty or junk content
    procedures = [chunk.strip() for chunk in chunks if chunk.strip().lower().startswith("create or alter procedure")]

    logger.info(f"🧩 Found {len(procedures)} stored procedures to execute.")

    for i, proc in enumerate(procedures, start=1):
        try:
            logger.info(f"⚙️ Executing procedure #{i}...")
            cursor.execute(proc)
            conn.commit()
            logger.info(f"✅ Procedure #{i} executed successfully.")
        except Exception as e:
            logger.error(f"❌ Error in procedure #{i}:\n{e}\n--- SQL Preview ---\n{proc[:200]}...\n")
    cursor.close()
    conn.close()

#*************************************************************************************************************************************************

def execute_create_indexes(file_path):
    
    conn = get_db_connection()
    cursor = conn.cursor()
    logger.info("✅ Connected to database for index creation")

    with open(file_path, 'r', encoding='utf-8') as f:
        ddl_text = f.read()

    # Extract full CREATE INDEX statements (including optional INCLUDE clauses)
    create_statements = extract_create_index_statements(ddl_text)

    for stmt in create_statements:
        # Pull out the index name so we can skip if it already exists
        idx_match = re.search(
            r"CREATE\s+(?:UNIQUE\s+)?INDEX\s+((?:\[[^\]]+\]|\w+))",
            stmt,
            flags=re.IGNORECASE
        )
        if not idx_match:
            logger.error("⚠️ Could not extract index name, skipping statement.")
            continue

        idx_name = idx_match.group(1).strip("[]")

        # Check if this index already exists in the database
        cursor.execute("""
            SELECT 1
                FROM sys.indexes
            WHERE name = ?
        """, (idx_name,))
        if cursor.fetchone():
            logger.info(f"ℹ️ Index '{idx_name}' already exists, skipping.")
            continue

        # Execute the CREATE INDEX statement
        try:
            cursor.execute(stmt)
            conn.commit()
            logger.info(f"✅ Created index: {idx_name}")
        except Exception as e:
            logger.error(f"❌ Failed to create index {idx_name}: {e}\nSQL was:\n{stmt}")

    cursor.close()
    conn.close()
    logger.info("🎯 Index sync complete.")

#*************************************************************************************************************************************************

def extract_create_index_statements(sql_text: str) -> list[str]:

    """
    Finds every CREATE [UNIQUE] INDEX … ON … (…) ; block in the file,
    even if it spans multiple lines, until the matching closing );
    """
    
    pattern = re.compile(
        r"""
        (
        CREATE \s+
        (?:UNIQUE \s+)? INDEX \s+
        (?:\[[^\]]+\]|\w+)
        (?: \s* \. \s* (?:\[[^\]]+\]|\w+))?
        \s+ ON \s+
        (?:\[[^\]]+\]|\w+)
        (?: \s* \. \s* (?:\[[^\]]+\]|\w+))?
        \s* \(
            [\s\S]*?
        \)
        (?:\s* INCLUDE \s* \( [\s\S]*? \) )?  # optional INCLUDE(columns)
        \s* ;
        )
        """,
        re.IGNORECASE | re.VERBOSE
    )
    return [m.group(1) for m in pattern.finditer(sql_text)]
