import os

#*************************************************************************************************************************************************

def ensure_directories():
    
    os.makedirs("logs", exist_ok=True)
    os.makedirs("temp", exist_ok=True)
    os.makedirs("Assets", exist_ok=True)
