from flask import Flask, request, make_response, jsonify
from flask_cors import CORS
from werkzeug.middleware.proxy_fix import ProxyFix
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

from config.logger import logger
from controllers import health_controller, login_controller, test_controller
from framework_drivers.flask_app.ensure_folders import ensure_directories
from shared.auth import jwt_access_required

#*********************************************************************************************************************************************

def create_app():
    ensure_directories()
    app = Flask(__name__)

    # Trust 1 proxy hop (IIS/NGINX/ARR) so get_remote_address sees the real client IP via X-Forwarded-For
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1)

    # --- Rate Limiter ---
    # Default limits map to your “*:/api/*” style caps: 30/min and 500/hour (applied to all routes).
    limiter = Limiter(
        key_func=get_remote_address,                 # per-IP
        default_limits=["30 per minute", "500 per hour"],
        storage_uri="memory://",                     
        headers_enabled=True,
        strategy="fixed-window",
    )
    limiter.init_app(app)

    # Whitelist OPTIONS (CORS preflights) + GET /health + GET /log-content
    @limiter.request_filter
    def _whitelist_and_preflights():
        if request.method == "OPTIONS":
            return True
        if request.method == "GET" and request.path in ("/health", "/log-content"):
            return True
        return False

    # Custom 429 JSON (mirrors your desired body)
    @app.errorhandler(429)
    def _ratelimit_handler(e):
        return (
            jsonify(
                success=False,
                message="Rate limit exceeded. Please try again later.",
                errorCode="RATE_LIMIT_EXCEEDED",
            ),
            429,
        )

    # ─── MANUAL CORS (your existing logic) ───────────────────────────────────
    @app.before_request
    def handle_preflight():
        if request.method == "OPTIONS":
            resp = make_response()
            origin = request.headers.get("Origin")
            if origin:
                resp.headers["Access-Control-Allow-Origin"] = origin
                resp.headers["Access-Control-Allow-Credentials"] = "true"
                resp.headers["Access-Control-Allow-Methods"] = "GET,POST,PUT,DELETE,OPTIONS"
                resp.headers["Access-Control-Allow-Headers"] = "Authorization,Content-Type"
            return resp  # stop further handling for preflight

    @app.after_request
    def apply_cors(response):
        origin = request.headers.get("Origin")
        if origin:
            response.headers["Access-Control-Allow-Origin"] = origin
            response.headers["Access-Control-Allow-Credentials"] = "true"
            response.headers["Access-Control-Allow-Methods"] = "GET,POST,PUT,DELETE,OPTIONS"
            response.headers["Access-Control-Allow-Headers"] = "Authorization,Content-Type"
        return response

    # ─── RATE LIMIT RULES (map your JSON to current endpoints) ───────────────
    # Shared 10/min bucket for ALL POST endpoints (analogous to POST:/api/* 10/min)
    post_bucket = limiter.shared_limit("10 per minute", scope="post-global")

    # Register routes (same endpoints you already expose)
    app.add_url_rule("/health", view_func=health_controller.health_check, methods=["GET"])
    app.add_url_rule("/log-content", view_func=health_controller.get_log_content, methods=["GET"])

    # Login: POST /verify_login → 3/min + 10/15min
    # Also counts toward POST 10/min and global 30/min & 500/hour
    app.add_url_rule(
        "/verify_login",
        view_func=post_bucket(
            limiter.limit("3 per minute;10 per 15 minutes")(login_controller.verify_login)
        ),
        methods=["POST"],
    )

    # Other routes inherit global caps; POST-wide 10/min does not apply since these are GETs
    app.add_url_rule("/logout", view_func=jwt_access_required(login_controller.logout), methods=["GET"])
    app.add_url_rule("/refresh_route", view_func=login_controller.refresh_route, methods=["GET"])
    app.add_url_rule("/testing", view_func=jwt_access_required(test_controller.tester), methods=["GET"])

    logger.info("✅ All routes registered with rate limiting and manual CORS")
    return app
