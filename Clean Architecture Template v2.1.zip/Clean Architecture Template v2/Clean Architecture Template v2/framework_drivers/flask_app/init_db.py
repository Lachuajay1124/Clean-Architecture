import os

from config.logger import logger

from config.settings import TABLES_SCHEMA_PATH, SP_SCHEMA_PATH, INDEX_SCHEMA_PATH

from shared.db import execute_create_tables, execute_stored_procedures_from_file, execute_create_indexes

#*************************************************************************************************************************************************

def setup_database():
    logger.info(TABLES_SCHEMA_PATH)
    logger.info(SP_SCHEMA_PATH)
    logger.info(INDEX_SCHEMA_PATH)
    if TABLES_SCHEMA_PATH and os.path.exists(TABLES_SCHEMA_PATH):
        execute_create_tables(TABLES_SCHEMA_PATH)
    if SP_SCHEMA_PATH and os.path.exists(SP_SCHEMA_PATH):
        execute_stored_procedures_from_file(SP_SCHEMA_PATH)
    if INDEX_SCHEMA_PATH and os.path.exists(INDEX_SCHEMA_PATH):
        execute_create_indexes(INDEX_SCHEMA_PATH)