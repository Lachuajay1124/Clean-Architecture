import os
import sys
import win32event
import win32api
import winerror
from config.logger import logger

#*************************************************************************************************************************************************

def enforce_single_instance():

    MUTEX_NAME = os.getenv("MUTEX") or "DEFAULT_FLASK_MUTEX_DEBUG"
    logger.info(f"🔧 Trying to acquire mutex: '{MUTEX_NAME}'")
    logger.info(f"🔧 Current PID: {os.getpid()}")

    mutex = win32event.CreateMutex(None, False, MUTEX_NAME)
    last_error = win32api.GetLastError()
    logger.error(f"🔧 GetLastError: {last_error}")

    if last_error == winerror.ERROR_ALREADY_EXISTS:
        logger.info(f"🔒 Mutex '{MUTEX_NAME}' already exists. Another instance is likely running.")
        sys.exit(0)
    else:
        logger.info(f"✅ Mutex '{MUTEX_NAME}' acquired.")
