﻿using System.Diagnostics;
using System.Security.Claims;

namespace ShipJobPortal.API.Middlewares
{
    public sealed class AuditMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<AuditMiddleware> _logger;
        private const int DefaultSlowMs = 5000;

        public AuditMiddleware(RequestDelegate next, ILogger<AuditMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var sw = Stopwatch.StartNew();
            try
            {
                if (IsSecurityRelevantRequest(context))
                {
                    LogSecurityEvent(context, "REQUEST");
                }

                await _next(context);

                if (IsSecurityRelevantRequest(context))
                {
                    LogSecurityEvent(context, "RESPONSE", sw.ElapsedMilliseconds);
                }
            }
            finally
            {
                sw.Stop();

                if (sw.ElapsedMilliseconds > DefaultSlowMs)
                {
                    _logger.LogWarning(
                        "Slow request: {Method} {Path} took {Duration} ms from {IP} (Status {Status}) TraceId={TraceId}",
                        context.Request.Method,
                        context.Request.Path,
                        sw.ElapsedMilliseconds,
                        GetClientIpAddress(context),
                        context.Response.StatusCode,
                        context.TraceIdentifier
                    );
                }
            }
        }

        private void LogSecurityEvent(HttpContext ctx, string eventType, long? durationMs = null)
        {
            var auditEvent = new
            {
                EventType = eventType,
                Timestamp = DateTime.Now,
                Method = ctx.Request.Method,
                Path = ctx.Request.Path.Value,
                QueryString = ctx.Request.QueryString.Value,
                StatusCode = ctx.Response.StatusCode,
                IPAddress = GetClientIpAddress(ctx),
                UserAgent = ctx.Request.Headers["User-Agent"].FirstOrDefault(),
                UserId = ctx.User?.FindFirst(ClaimTypes.NameIdentifier)?.Value,
                UserEmail = ctx.User?.FindFirst(ClaimTypes.Email)?.Value,
                Duration = durationMs,
                RequestId = ctx.TraceIdentifier
            };

            string logText = $@"
----- AUDIT LOG -----
EventType   : {auditEvent.EventType}
Timestamp   : {auditEvent.Timestamp:u}
Method      : {auditEvent.Method}
Path        : {auditEvent.Path}
QueryString : {auditEvent.QueryString}
StatusCode  : {auditEvent.StatusCode}
IPAddress   : {auditEvent.IPAddress}
UserAgent   : {auditEvent.UserAgent}
UserId      : {auditEvent.UserId}
UserEmail   : {auditEvent.UserEmail}
Duration    : {auditEvent.Duration} ms
RequestId   : {auditEvent.RequestId}
----------------------
";

            var logDirectory = Path.Combine(AppContext.BaseDirectory, "Logs", "Audit");
            Directory.CreateDirectory(logDirectory); // ensures folder exists

            var logFilePath = Path.Combine(logDirectory, $"Audit_{DateTime.Now:yyyyMMdd}.txt");
            File.AppendAllText(logFilePath, logText);

            _logger.LogInformation("Security Audit Event: {@AuditEvent}", auditEvent);
        }

        private static bool IsSecurityRelevantRequest(HttpContext context)
        {
            var path = context.Request.Path.Value?.ToLowerInvariant() ?? string.Empty;

            string[] authPaths = ["/login", "/register", "/logout", "/refresh-token", "/reset-password"];
            if (authPaths.Any(path.Contains))
                return true;

            if (context.Request.Method is "POST" or "PUT" or "DELETE")
                return true;

            if (context.Response.StatusCode >= 400)
                return true;

            return false;
        }

        private static string GetClientIpAddress(HttpContext context)
        {
            var forwardedFor = context.Request.Headers["X-Forwarded-For"].FirstOrDefault();
            if (!string.IsNullOrWhiteSpace(forwardedFor))
                return forwardedFor.Split(',')[0].Trim();

            var realIp = context.Request.Headers["X-Real-IP"].FirstOrDefault();
            if (!string.IsNullOrWhiteSpace(realIp))
                return realIp;

            return context.Connection.RemoteIpAddress?.ToString() ?? "Unknown";
        }
    }

    public static class AuditMiddlewareExtensions
    {
        public static IApplicationBuilder UseAudit(this IApplicationBuilder app)
            => app.UseMiddleware<AuditMiddleware>();
    }
}
