﻿using System.ComponentModel.DataAnnotations;
using System.Net;
using System.Text.Json;

namespace ShipJobPortal.API.Middlewares
{
    public sealed class ExceptionMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<ExceptionMiddleware> _logger;
        private readonly IHostEnvironment _env;

        public ExceptionMiddleware(RequestDelegate next, ILogger<ExceptionMiddleware> logger, IHostEnvironment env)
        {
            _next = next;
            _logger = logger;
            _env = env;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }
        }

        private async Task HandleExceptionAsync(HttpContext context, Exception ex)
        {
            var correlationId = context.TraceIdentifier;

            using (_logger.BeginScope(new Dictionary<string, object?>
            {
                ["CorrelationId"] = correlationId,
                ["Path"] = context.Request.Path.Value,
                ["Method"] = context.Request.Method,
                ["User"] = context.User?.Identity?.Name ?? "anonymous",
                ["RemoteIp"] = context.Connection.RemoteIpAddress?.ToString()
            }))
            {
                _logger.LogError(ex, "Unhandled exception. CorrelationId={CorrelationId}", correlationId);
            }

            // If response already started, let the server terminate the connection gracefully
            if (context.Response.HasStarted)
            {
                _logger.LogWarning("The response has already started, cannot write error body. CorrelationId={CorrelationId}", correlationId);
                return;
            }

            var statusCode = GetStatusCode(ex);
            context.Response.Clear();
            context.Response.StatusCode = statusCode;
            context.Response.ContentType = "application/json";

            // Standard API envelope (matches your project’s pattern)
            var errorPayload = new
            {
                success = false,
                data = (object?)null,
                message = GetSafeErrorMessage(ex, _env),
                errorCode = MapErrorCode(statusCode, ex), // e.g., "ERR400", "ERR401", "ERR500"
                correlationId
            };

            var json = JsonSerializer.Serialize(errorPayload, new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });
            await context.Response.WriteAsync(json);
        }

        private static string MapErrorCode(int status, Exception ex) => status switch
        {
            (int)HttpStatusCode.BadRequest => "ERR400",
            (int)HttpStatusCode.Unauthorized => "ERR401",
            (int)HttpStatusCode.Forbidden => "ERR403",
            (int)HttpStatusCode.NotFound => "ERR404",
            (int)HttpStatusCode.RequestTimeout => "ERR408",
            _ => "ERR500"
        };

        private static int GetStatusCode(Exception ex) => ex switch
        {
            ValidationException => (int)HttpStatusCode.BadRequest,
            ArgumentException => (int)HttpStatusCode.BadRequest,
            UnauthorizedAccessException => (int)HttpStatusCode.Unauthorized,
            KeyNotFoundException => (int)HttpStatusCode.NotFound,
            TimeoutException => (int)HttpStatusCode.RequestTimeout,
            // Add Forbidden if you throw it somewhere:
            // ForbiddenException                   => (int)HttpStatusCode.Forbidden,
            _ => (int)HttpStatusCode.InternalServerError
        };

        private static string GetSafeErrorMessage(Exception ex, IHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                // In Dev, surface the real message (but still skip stack traces in the response)
                return ex.Message;
            }

            return ex switch
            {
                ValidationException => "Invalid input data provided",
                ArgumentException => "Invalid request parameters",
                UnauthorizedAccessException => "Access denied",
                KeyNotFoundException => "The requested resource was not found",
                TimeoutException => "Request timed out",
                _ => "An unexpected error occurred"
            };
        }
    }

    public static class ExceptionMiddlewareExtensions
    {
        public static IApplicationBuilder UseExceptionHandling(this IApplicationBuilder app)
            => app.UseMiddleware<ExceptionMiddleware>();
    }
}
