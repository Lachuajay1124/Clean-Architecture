﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using ShipJobPortal.API.Helpers;
using ShipJobPortal.Application.DTOs;
using ShipJobPortal.Application.IServices;
using ShipJobPortal.Domain.Interfaces;

namespace ShipJobPortal.WebAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class JobPostController : ControllerBase
{
    private readonly IJobPostService _jobService;
    private readonly ILogger<JobPostController> _logger;
    private readonly IDbExceptionLogger _dbExceptionLogger;

    public JobPostController(IJobPostService jobService, ILogger<JobPostController> logger, IDbExceptionLogger dbExceptionLogger)
    {
        _jobService = jobService;
        _logger = logger;
        _dbExceptionLogger = dbExceptionLogger;
    }
    /// <summary>
    /// Job vacancy create
    /// </summary>
    /// <param name="dto"></param>
    /// <returns></returns>
    [Authorize(Roles = "Recruiter")]
    [HttpPost("createJobVacancy")]
    public async Task<IActionResult> CreateJob([FromBody] JobCreateDto dto)
    {
        try
        {
            var result = await _jobService.CreateJobAsync(dto);

            return this.ToActionResult(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred in CreateJob");
            await _dbExceptionLogger.LogExceptionAsync("CreateJob_Controller", ex.Message, ex.StackTrace);
            throw;
        }
    }
    /// <summary>
    /// Get job vacancy for seafarer
    /// </summary>
    /// <param name="pageNumber"></param>
    /// <param name="pageSize"></param>
    /// <param name="vacancyId"></param>
    /// <param name="positionId"></param>
    /// <param name="vesselTypeId"></param>
    /// <param name="locationId"></param>
    /// <param name="durationId"></param>
    /// <param name="searchKey"></param>
    /// <param name="CandidateId"></param>
    /// <returns></returns>
    [Authorize(Roles = "Seafarer")]
    [HttpGet("getJobVacancy")]
    public async Task<IActionResult> GetAllJobs([FromQuery] JobFilterRequestDto request)
    {
        try
        {
            var result = await _jobService.GetJobsFilteredAsync(request);
            return this.ToActionResult(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred in GetAllJobs");
            await _dbExceptionLogger.LogExceptionAsync("GetAllJobs_Controller", ex.Message, ex.StackTrace);
            throw;
        }
    }
    /// <summary>
    /// Get jobs created by recruiter
    /// </summary>
    /// <param name="userId"></param>
    /// <param name="companyId"></param>
    /// <param name="pageNumber"></param>
    /// <param name="pageSize"></param>
    /// <param name="positionId"></param>
    /// <param name="vesselTypeId"></param>
    /// <param name="locationId"></param>
    /// <param name="durationId"></param>
    /// <param name="searchKey"></param>
    /// <returns></returns>
    [Authorize(Roles = "Recruiter")]
    [HttpGet("getJobsbyUser")]
    public async Task<IActionResult> GetAllJobsbyUser([FromQuery] JobFilterRequestDto dto)
    {
        try
        {
            dto.VacancyId = -1;
            var result = await _jobService.GetJobsFilteredAsync(dto);

            return this.ToActionResult(result);

        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred in GetAllJobsByUser");
            await _dbExceptionLogger.LogExceptionAsync("GetAllJobsByUser_Controller", ex.Message, ex.StackTrace);
            throw;
        }
    }
    /// <summary>
    /// for editing job vacancy
    /// </summary>
    /// <param name="jobId"></param>
    /// <param name="patchDto"></param>
    /// <returns></returns>
    [Authorize(Roles = "Recruiter")]
    [HttpPatch("editJobVacancy")]
    public async Task<IActionResult> EditJob(int jobId, [FromBody] JobPatchDto patchDto)
    {

        var json = JsonConvert.SerializeObject(patchDto);
        var patchData = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);


        try
        {
            JobCreateDto dto = new();
            var result = await _jobService.EditJobAsync(jobId, patchData);

            return this.ToActionResult(result);

        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred in EditJob");
            await _dbExceptionLogger.LogExceptionAsync("EditJob", ex.Message, ex.StackTrace);
            throw;
        }
    }
    /// <summary>
    /// for deleting job vacancy
    /// </summary>
    /// <param name="jobId"></param>
    /// <returns></returns>
    [Authorize(Roles = "Recruiter")]
    [HttpPost("delete/{jobId}")]
    public async Task<IActionResult> DeleteJob(int jobId)
    {
        try
        {
            var result = await _jobService.DeleteJobAsync(jobId);

            return this.ToActionResult(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred in DeleteJob");
            await _dbExceptionLogger.LogExceptionAsync("DeleteJob_Controller", ex.Message, ex.StackTrace);
            throw;
        }
    }
    /// <summary>
    /// for adding job count
    /// </summary>
    /// <param name="dto"></param>
    /// <returns></returns>
    [Authorize(Roles = "Seafarer")]
    [HttpPost("jobcount")]
    public async Task<IActionResult> jobcount([FromBody] JobViewCountDto dto)
    {
        try
        {
            var result = await _jobService.JobViewCount(dto);

            return this.ToActionResult(result);

        }
        catch (Exception ex)
        {
            await _dbExceptionLogger.LogExceptionAsync("ReferFriend", ex.Message, ex.StackTrace);
            _logger.LogError(ex, "Exception occurred in ReferFriend");
            throw;
        }
    }

}


