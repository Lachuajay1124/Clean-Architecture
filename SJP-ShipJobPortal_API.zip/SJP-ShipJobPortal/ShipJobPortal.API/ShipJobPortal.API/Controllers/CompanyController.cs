﻿using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using ShipJobPortal.Application.DTOs;
using ShipJobPortal.Application.IServices;
using ShipJobPortal.Domain.Interfaces;
using ShipJobPortal.API.Helpers;
using Microsoft.AspNetCore.Authorization;

namespace ShipJobPortal.WebAPI.Controllers
{
    /// <summary>
    /// This controller work fine with V1 dapper
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Authorize] 
    public class CompanyController : ControllerBase
    {
        private readonly ICompanyService _companyService;
        private readonly ILogger<CompanyController> _logger;
        private readonly IDbExceptionLogger _dbExceptionLogger;

        public CompanyController(ICompanyService companyService, ILogger<CompanyController> logger, IDbExceptionLogger dbExceptionLogger)
        {
            _companyService = companyService;
            _logger = logger;
            _dbExceptionLogger = dbExceptionLogger;
        }

        /// <summary>
        /// to create a company profile
        /// </summary>
        /// <param name="companyCreateDto"></param>
        /// <returns></returns>
        [Authorize(Roles = "Admin")]
        [HttpPost("createCompany")]
        public async Task<IActionResult> CreateCompany([FromBody] CompanyCreateDto companyCreateDto)
        {

            var username = User.FindFirst(ClaimTypes.Email)?.Value;
            try
            {
                var result = await _companyService.CreateCompanyAsync(companyCreateDto, username);
                return this.ToActionResult(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception occurred while creating company");
                await _dbExceptionLogger.LogExceptionAsync("CreateCompany_Controller", ex.Message, ex.StackTrace);
                throw;
            }
        }

        /// <summary>
        /// to get all companies
        /// </summary>
        /// <returns></returns>
        [Authorize(Roles = "Admin")]
        [HttpGet("getAllCompanies")]
        public async Task<IActionResult> GetAllCompanies()
        {
            try
            {
                var response = await _companyService.GetAllCompaniesAsync();
                return this.ToActionResult(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception occurred while retrieving companies.");
                await _dbExceptionLogger.LogExceptionAsync("GetAllCompanies_Controller", ex.Message, ex.StackTrace);
                throw;
            }
        }

        /// <summary>
        /// to get company details
        /// </summary>
        /// <param name="CompanyId"></param>
        /// <returns></returns>
        [Authorize(Roles = "Admin")]
        [HttpGet("getCompany")]
        public async Task<IActionResult> GetCompany(int CompanyId)
        {
            try
            {
                var response = await _companyService.GetCompanyAsync(CompanyId);
                return this.ToActionResult(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception occurred while retrieving companies.");
                await _dbExceptionLogger.LogExceptionAsync("GetAllCompanies_Controller", ex.Message, ex.StackTrace);
                throw;
            }
        }
    }
}
