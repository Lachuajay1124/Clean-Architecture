﻿using Microsoft.AspNetCore.Mvc;
using ShipJobPortal.API.Helpers;
using ShipJobPortal.Application.DTOs;
using ShipJobPortal.Application.IServices;
using ShipJobPortal.Domain.Constants;
using ShipJobPortal.Domain.Interfaces;

namespace ShipJobPortal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly ILoginService _loginServices;
        private readonly ILogger<LoginController> _logger;
        private readonly IDbExceptionLogger _dbExceptionLogger;
        private readonly IConfiguration _configuration;
        private readonly IOtpService _otpService;
        private readonly ICookieHelper _cookieHelper;

        public LoginController(ILoginService loginServices, ILogger<LoginController> logger, IDbExceptionLogger dbExceptionLogger, IConfiguration configuration, IOtpService otpService, ICookieHelper cookieHelper)
        {
            _loginServices = loginServices;
            _logger = logger;
            _dbExceptionLogger = dbExceptionLogger;
            _configuration = configuration;
            _otpService = otpService;
            _cookieHelper = cookieHelper;

        }


        /// <summary>
        /// Account creation
        /// </summary>
        /// <param name="userDto"></param>
        /// <returns></returns>
        [HttpPost("CreateUser")]
        public async Task<IActionResult> CreateUser([FromBody] UserApplicantDto userDto)
        {
            try
            {
                var result = await _loginServices.CreateUserAsync(userDto);
                return this.ToActionResult(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in CreateUser");
                await _dbExceptionLogger.LogExceptionAsync("CreateUser_Controller", ex.Message, ex.StackTrace);
                throw;
            }
        }
        /// <summary>
        /// Refresh route
        /// </summary>
        /// <returns></returns>
        [HttpPost("refresh-token")]
        public async Task<IActionResult> RefreshToken()
        {
            try
            {
                var refreshToken = Request.Cookies["SjpJwtRefreshToken"];
                await _dbExceptionLogger.LogExceptionAsync("Logout_Controller", "refreshToken", refreshToken);
                if (string.IsNullOrEmpty(refreshToken))
                {
                    var data = new ApiResponse<object>(false, null, "Missing refresh token.", ErrorCodes.Unauthorized);
                    return this.ToActionResult(data);

                }
                var result = await _loginServices.RefreshTokenAsync(refreshToken);

                if (!result.Success)
                {
                    return this.ToActionResult(result);
                }
                var auth = result.Data;
                int jwtExpiryHours = Convert.ToInt32(_configuration["TokenSettings:JwtTokenExpiryHours"]);
                int refreshExpiryDays = Convert.ToInt32(_configuration["TokenSettings:RefreshTokenExpiryDays"]);
                Response.Cookies.Append("SjpJwtToken", auth.AccessToken, _cookieHelper.GetSecureCookieOptions(jwtExpiryHours));

                Response.Cookies.Append("SjpJwtRefreshToken", auth.RefreshToken, _cookieHelper.GetSecureRefreshCookieOptions(refreshExpiryDays));


                var safeData = new
                {
                    userId = auth.UserId,
                    email = auth.Email,
                    role = auth.Role
                };
                var returnData = new ApiResponse<object>(true, safeData, "Token refreshed successfully.", ErrorCodes.Success);
                return this.ToActionResult(returnData);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in RefreshToken");
                await _dbExceptionLogger.LogExceptionAsync("RefreshToken_Controller", ex.Message, ex.StackTrace);
                throw;
            }
        }
        /// <summary>
        /// logout
        /// </summary>
        /// <returns></returns>
        [HttpPost("logout")]
        public async Task<IActionResult> Logout()
        {
            try
            {
                var returnData = new ApiResponse<object>(false, null, "", ErrorCodes.Success);
                var refreshToken = Request.Cookies["SjpJwtRefreshToken"];
                var accesstoken = Request.Cookies["SjpJwtToken"];
                var allowedRoutes = Request.Cookies["allowedRoutes"];
                var navigation = Request.Cookies["navigation"];
                var user = Request.Cookies["user"];
                var userEmail = Request.Cookies["userEmail"];
                var userId = Request.Cookies["userId"];

                if (string.IsNullOrEmpty(refreshToken))
                {
                    returnData = new ApiResponse<object>(false, null, "Missing refresh token.", ErrorCodes.Unauthorized);
                    return this.ToActionResult(returnData);
                }



                var result = await _loginServices.LogoutAsync(refreshToken); // revoke in DB

                if (result.Success)
                {
                    Response.Cookies.Delete("SjpJwtRefreshToken");
                    Response.Cookies.Delete("SjpJwtToken");
                    Response.Cookies.Delete("allowedRoutes");
                    Response.Cookies.Delete("navigation");
                    Response.Cookies.Delete("user");
                    Response.Cookies.Delete("userEmail");
                    Response.Cookies.Delete("userId");

                    returnData = new ApiResponse<object>(true, null, "Logged out successfully.", ErrorCodes.Success);

                    return this.ToActionResult(returnData);

                }

                returnData = new ApiResponse<object>(false, null, "Invalid or already deleted token.", ErrorCodes.BadRequest);
                return this.ToActionResult(returnData);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Logout");
                await _dbExceptionLogger.LogExceptionAsync("Logout_Controller", ex.Message, ex.StackTrace);
                throw;
            }
        }
        /// <summary>
        /// for reset password
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("reset-password")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordDto request)
        {
            try
            {
                var result = await _loginServices.ResetPasswordAsync(request);

                return this.ToActionResult(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in ResetPassword");
                await _dbExceptionLogger.LogExceptionAsync("ResetPassword_Controller", ex.Message, ex.StackTrace);
                throw;
            }
        }

        #region Login
        /// <summary>
        /// for throttle test
        /// </summary>
        /// <returns></returns>
        [HttpPost("throttle-test")]
        public IActionResult ThrottleTest() => Ok(new { ok = true });

        /// <summary>
        /// for verifying seaman book and passport
        /// </summary>
        /// <param name="userDto"></param>
        /// <returns></returns>
        [HttpPost("CheckSeamanBookorPassport")]
        public async Task<IActionResult> SeamanBookorPassportCheck([FromBody] SeamanBookDto dto)
        {
            try
            {
                var result = await _loginServices.VerifySeamanbookAsync(dto.seamanBookorPassport);

                return this.ToActionResult(result);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in SeamanBookorPassportCheck");
                await _dbExceptionLogger.LogExceptionAsync("SeamanBookorPassportCheck_Controller", ex.Message, ex.StackTrace);
                throw;
            }
        }

        /// <summary>
        /// Login and account creation for OAuth users
        /// </summary>
        /// <param name="loginDto"></param>
        /// <returns></returns>
        [HttpPost("login-Para")]
        public async Task<IActionResult> loginasync([FromBody] UserLoginDto loginDto)
        {
            try
            {

                var result = await _loginServices.AuthenticateUserAsync_test(loginDto);
                if (result.Data == null)
                {
                    return this.ToActionResult(result);
                }
                if (result.Data.ResumeStatus.ToLower() == "available" || result.Data.ResumeStatus.ToLower() == "recruiter")
                {
                    //tokens
                    int jwtExpiryHours = Convert.ToInt32(_configuration["TokenSettings:JwtTokenExpiryHours"]);
                    int refreshExpiryDays = Convert.ToInt32(_configuration["TokenSettings:RefreshTokenExpiryDays"]);
                    string jwttoken = result.Data.AccessToken; string refreshtoken = result.Data.RefreshToken;
                    Response.Cookies.Append("SjpJwtToken", jwttoken, _cookieHelper.GetSecureCookieOptions(jwtExpiryHours));

                    Response.Cookies.Append("SjpJwtRefreshToken", refreshtoken, _cookieHelper.GetSecureRefreshCookieOptions(refreshExpiryDays));

                    result.Data.Email = null; result.Data.Role = null; result.Data.LoginType = null;
                    return this.ToActionResult(result);
                }

                return this.ToActionResult(result);


            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Login");
                await _dbExceptionLogger.LogExceptionAsync("Login", ex.Message, ex.StackTrace);
                throw;
            }
        }

        /// <summary>
        /// for sending Otp
        /// </summary>
        /// <param name="otp"></param>
        /// <returns></returns>
        [HttpPost("otpSent")]
        public async Task<IActionResult> UserOtpSave([FromBody] userOtpDto otp)
        {
            try
            {
                var result = await _otpService.GenerateAndSaveOtpAsync(otp);

                return this.ToActionResult(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception in UserOtpSave");
                await _dbExceptionLogger.LogExceptionAsync("UserOtpSave", ex.Message, ex.StackTrace);
                throw;
            }
        }
        /// <summary>
        /// otp verifying
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [HttpPost("userOtpVerify")]
        public async Task<IActionResult> UserOtpVerify([FromBody] UserOtpVerifyDto user)
        {
            try
            {
                var result = await _otpService.UserOtpVerification(user);

                return this.ToActionResult(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception in UserOtpVerify");
                await _dbExceptionLogger.LogExceptionAsync("UserOtpVerify", ex.Message, ex.StackTrace);
                throw;
            }
        }

        #endregion
    }
}

