﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ShipJobPortal.API.Helpers;
using ShipJobPortal.Application.DTOs;
using ShipJobPortal.Application.IServices;
using ShipJobPortal.Domain.Constants;
using ShipJobPortal.Domain.Interfaces;

namespace ShipJobPortal.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class JobApplyController : ControllerBase
    {
        private readonly IJobApplyService _ApplyService;
        private readonly ILogger<JobApplyController> _logger;
        private readonly IDbExceptionLogger _dbExceptionLogger;

        public JobApplyController(IJobApplyService jobApplyService, ILogger<JobApplyController> logger, IDbExceptionLogger dbExceptionLogger)
        {
            _ApplyService = jobApplyService;
            _logger = logger;
            _dbExceptionLogger = dbExceptionLogger;
        }

        /// <summary>
        /// to get applied candidates of specific jobs
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [Authorize(Roles = "Recruiter")]
        [HttpGet("applied-candidates")]
        public async Task<IActionResult> GetAppliedCandidates([FromQuery] GetAppliedCandidateRequestDto request)
        {
            try
            {

                var response = await _ApplyService.GetAppliedCandidatesAsync(request);
                return this.ToActionResult(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetAppliedCandidates");
                await _dbExceptionLogger.LogExceptionAsync("GetAppliedCandidates", ex.Message, ex.StackTrace);
                throw;
            }
        }

        /// <summary>
        /// to applied  a job for candidates
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [Authorize(Roles = "Seafarer")]
        [HttpPost("apply-job")]
        public async Task<IActionResult> ApplyJob([FromBody] JobApplyPostDto model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new ApiResponse<string>(false, null, "Invalid request data.", ErrorCodes.BadRequest));
            }
            try
            {
                var response = await _ApplyService.ApplyJobAsync(model);
                return this.ToActionResult(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in ApplyJob endpoint.");
                await _dbExceptionLogger.LogExceptionAsync("ApplyJob", ex.Message, ex.StackTrace);
                throw;
            }
        }

        /// <summary>
        /// Get Applied jobs for candidate
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [Authorize(Roles = "Seafarer")]
        [HttpGet("applied-Jobs")]
        public async Task<IActionResult> GetAppliedJobsForCandidate([FromQuery] GetAppliedJobsForCandidateDto request)
        {

            try
            {
                var response = await _ApplyService.GetAppliedJobsAsync(request);
                return this.ToActionResult(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetAppliedJobsForCandidate");
                await _dbExceptionLogger.LogExceptionAsync("GetAppliedJobsForCandidate", ex.Message, ex.StackTrace);
                throw;
            }
        }

        /// <summary>
        /// to save a job into wishlist
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [Authorize(Roles = "Seafarer")]
        [HttpPost("favouriteJob")]
        public async Task<IActionResult> SaveJobtowishlist([FromBody] JobWishListDto model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new ApiResponse<string>(false, null, "Invalid request data.", ErrorCodes.BadRequest));
            }
            try
            {
                var response = await _ApplyService.SaveJobAsync(model);
                return this.ToActionResult(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in SaveJobtowishlist endpoint.");
                await _dbExceptionLogger.LogExceptionAsync("SaveJobtowishlist", ex.Message, ex.StackTrace);
                throw;
            }
        }

        /// <summary>
        /// Get Saved Jobs For Candidate
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [Authorize(Roles = "Seafarer")]
        [HttpGet("savedJobs")]
        public async Task<IActionResult> GetSavedJobsForCandidate([FromQuery] GetSavedJobsForCandidateDto request)
        {
            try
            {

                var response = await _ApplyService.GetSavedJobsAsync(request);
                return this.ToActionResult(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetSavedJobsForCandidate");
                await _dbExceptionLogger.LogExceptionAsync("GetSavedJobsForCandidate", ex.Message, ex.StackTrace);
                throw;
            }
        }

        /// <summary>
        /// To Job Action on Candidate
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [Authorize(Roles = "Seafarer")]
        [HttpPost("jobAction")]
        public async Task<IActionResult> JobActiononCandidateAsync([FromBody] JobActiononCandidateDto model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new ApiResponse<string>(false, null, "Invalid request data.", ErrorCodes.BadRequest));
            }
            try
            {
                var response = await _ApplyService.UpdateJobApplicationStatusAsync(model);
                return this.ToActionResult(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in JobActiononCandidateAsync endpoint.");
                await _dbExceptionLogger.LogExceptionAsync("JobActiononCandidateAsync", ex.Message, ex.StackTrace);
                throw;
            }
        }

    }
}
