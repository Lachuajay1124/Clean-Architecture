﻿using Microsoft.AspNetCore.Mvc;
using ShipJobPortal.API.Helpers;
using ShipJobPortal.Application.DTOs;
using ShipJobPortal.Application.IServices;
using ShipJobPortal.Domain.Constants;
using ShipJobPortal.Domain.Interfaces;

namespace ShipJobPortal.API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class GetListController : ControllerBase
{
    /// <summary>
    /// Working status : fine 
    /// List : 
    /// GetAllCountry
    /// getAllState
    /// GetAllCity
    /// </summary>
    private readonly IGetListService _listService;
    private readonly ILogger<GetListController> _logger;
    private readonly IDbExceptionLogger _dbExceptionLogger;
    public GetListController(IGetListService listService, ILogger<GetListController> logger, IDbExceptionLogger dbExceptionLogger)
    {
        _listService = listService;
        _logger = logger;
        _dbExceptionLogger = dbExceptionLogger;
    }

    /// <summary> 18-july 2025
    /// to Get countries for drop dow menu
    /// </summary>
    /// <returns>list of countries via GetCountryListDto</returns>
    [HttpGet("getAllCountries")]
    public async Task<IActionResult> GetAllCountry()
    {
        try
        {
            var response = await _listService.GetAllCountryAsync();
            return this.ToActionResult(response, treatEmptyEnumerableAsNotFound: true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred while retrieving countries.");
            await _dbExceptionLogger.LogExceptionAsync("GetAllCountry_Controller", ex.Message, ex.StackTrace);
            throw;
        }
    }

    /// <summary> 18 july 2025
    /// to Get state for drop dow menu
    /// </summary>
    /// <returns>list of countries via GetStateListDto</returns>
    [HttpGet("getAllstates")]
    public async Task<IActionResult> getAllState(int? countryId)
    {
        try
        {
            var response = await _listService.GetAllStateAsync(countryId);
            return this.ToActionResult(response, treatEmptyEnumerableAsNotFound: true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred while retrieving states.");
            await _dbExceptionLogger.LogExceptionAsync("getAllState_Controller", ex.Message, ex.StackTrace);
            throw;
        }
    }

    /// <summary> 18 july 2025
    /// to Get city for drop dow menu
    /// </summary>
    /// <returns>list of countries via GetCityListDto</returns>
    [HttpGet("getAllcities")]
    public async Task<IActionResult> GetAllCity(int? stateId)
    {
        try
        {
            var response = await _listService.GetAllCityAsync(stateId);
            return this.ToActionResult(response, treatEmptyEnumerableAsNotFound: true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred while retrieving cities.");
            await _dbExceptionLogger.LogExceptionAsync("GetAllCity_Controller", ex.Message, ex.StackTrace);
            throw;
        }
    }


    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    [HttpGet("getAllVesseltype")]
    public async Task<IActionResult> GetAllVesselTypes()
    {
        try
        {
            var response = await _listService.GetAllVesselTypeAsync();
            return this.ToActionResult(response, treatEmptyEnumerableAsNotFound: true);

        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred while retrieving vessel types.");
            await _dbExceptionLogger.LogExceptionAsync("getAllVesseltype_Controller", ex.Message, ex.StackTrace);
            throw;
        }
    }

    /// <summary> 22-july 2025
    /// to Get Contract duration for drop dow menu
    /// </summary>
    /// <returns>list of duration via ContractDurationDto</returns>
    [HttpGet("getAllContractduration")]
    public async Task<IActionResult> GetAllContractDuration()
    {
        try
        {
            var response = await _listService.GetAllContractDurationAsync();
            return this.ToActionResult(response, treatEmptyEnumerableAsNotFound: true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred while retrieving Contract Duration.");
            await _dbExceptionLogger.LogExceptionAsync("GetAllContractDuration", ex.Message, ex.StackTrace);
            throw;
        }
    }

    /// <summary> 23 july 2025
    /// to Get position for drop dow menu
    /// </summary>
    /// <returns>list of position via PositionDto</returns>
    [HttpGet("getAllposition")]
    public async Task<IActionResult> GetAllPosition(int companyId)
    {
        try
        {
            var response = await _listService.GetAllPositionAsync(companyId);
            return this.ToActionResult(response, treatEmptyEnumerableAsNotFound: true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred while retrieving GetAllPosition.");
            await _dbExceptionLogger.LogExceptionAsync("GetAllPosition", ex.Message, ex.StackTrace);
            throw;
        }
    }


    /// <summary> 18-August 2025
    /// to Get Mobile codes for drop dow menu
    /// </summary>
    /// <returns>list of countries via GetCountryListDto</returns>
    [HttpGet("GetAllMobileCodes")]
    public async Task<IActionResult> GetAllMobileCodes()
    {
        try
        {
            var response = await _listService.GetAllMobileCodesAsync();
            return this.ToActionResult(response, treatEmptyEnumerableAsNotFound: true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred while retrieving countries.");
            await _dbExceptionLogger.LogExceptionAsync("GetAllCountry_Controller", ex.Message, ex.StackTrace);
            throw;
        }
    }



    /// <summary> 23-August 2025
    /// to Get Document Section for drop dow menu
    /// </summary>
    /// <returns>list of Document Section via DocumentSectionDto</returns>
    [HttpGet("getAllDocumentSections")]
    public async Task<IActionResult> GetAllDocumentSection()
    {
        try
        {
            var response = await _listService.GetAllDocumentSectionAsync();
            return this.ToActionResult(response, treatEmptyEnumerableAsNotFound: true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred while retrieving Document Sections.");
            await _dbExceptionLogger.LogExceptionAsync("GetAllDocumentSections_Controller", ex.Message, ex.StackTrace);
            throw;
        }
    }

    /// <summary> 23-August 2025
    /// to Get Document Category for drop dow menu
    /// </summary>
    /// <returns>list of Document Category via DocumentCategoryDto</returns>
    [HttpGet("getAllDocumentCategories")]
    public async Task<IActionResult> GetAllDocumentCategory()
    {
        try
        {
            var response = await _listService.GetAllDocumentCategoryAsync();
            return this.ToActionResult(response, treatEmptyEnumerableAsNotFound: true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred while retrieving Document Category.");
            await _dbExceptionLogger.LogExceptionAsync("GetAllDocumentCategory_Controller", ex.Message, ex.StackTrace);
            throw;
        }
    }

    /// <summary> 23-August 2025
    /// to Get Document Type for drop dow menu
    /// </summary>
    /// <returns>list of Document Types via DocumentTypeDto</returns>
    [HttpGet("getAllDocumentTypes")]
    public async Task<IActionResult> GetAllDocumentType()
    {
        try
        {
            var response = await _listService.GetAllDocumentTypeAsync();
            return this.ToActionResult(response, treatEmptyEnumerableAsNotFound: true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred while retrieving Document Type.");
            await _dbExceptionLogger.LogExceptionAsync("GetAllDocumentType_Controller", ex.Message, ex.StackTrace);
            throw;
        }
    }

    /// <summary> 23-August 2025
    /// to Get Industry for drop dow menu
    /// </summary>
    /// <returns>list of industries via IndustryDto</returns>
    [HttpGet("getAllIndustries")]
    public async Task<IActionResult> GetAllIndustry()
    {
        try
        {
            var response = await _listService.GetAllIndustryAsync();
            return this.ToActionResult(response, treatEmptyEnumerableAsNotFound: true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred while retrieving industries.");
            await _dbExceptionLogger.LogExceptionAsync("GetAllIndustry_Controller", ex.Message, ex.StackTrace);
            throw;
        }
    }

    /// <summary> 23-Aug 2025
    /// to Get Documents for drop dow menu
    /// </summary>
    /// <returns>list of countries via GetCountryListDto</returns>
    [HttpGet("GetDocuments")]
    public async Task<IActionResult> GetDocumentAsync()
    {
        try
        {
            var response = await _listService.GetDocumentsList();
            return this.ToActionResult(response, treatEmptyEnumerableAsNotFound: true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred while retrieving countries.");
            await _dbExceptionLogger.LogExceptionAsync("GetDocumentAsync_Controller", ex.Message, ex.StackTrace);
            throw;
        }
    }
}