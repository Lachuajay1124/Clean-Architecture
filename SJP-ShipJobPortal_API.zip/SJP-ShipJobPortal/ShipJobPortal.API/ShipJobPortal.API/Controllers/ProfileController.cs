﻿using Azure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ShipJobPortal.API.Helpers;
using ShipJobPortal.Application.DTOs;
using ShipJobPortal.Application.IServices;
using ShipJobPortal.Domain.Constants;
using ShipJobPortal.Domain.Entities;
using ShipJobPortal.Domain.Interfaces;
using ShipJobPortal.Infrastructure.DataHelpers;
using ShipJobPortal.Infrastructure.Repositories;
using Sprache;

namespace ShipJobPortal.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize] // This is important to access `User` from JWT
public class ProfileController : ControllerBase
{
    private readonly IProfileService _profileService;
    private readonly ILogger<ProfileController> _logger;
    private readonly IDbExceptionLogger _dbExceptionLogger;

    public ProfileController(IProfileService profileService, ILogger<ProfileController> logger, IDbExceptionLogger dbExceptionLogger)
    {
        _profileService = profileService;
        _logger = logger;
        _dbExceptionLogger = dbExceptionLogger;
    }


    [Authorize(Roles ="Seafarer")]
    [HttpPost("videoresume")]
    public async Task<IActionResult> UploadVideoResume([FromForm] VideoResumeFileDto file)
    {
        try
        {

            var result = await _profileService.UploadAndProcessResumeAsync(file);
            return this.ToActionResult(result);

        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in UploadVideoResume");
            await _dbExceptionLogger.LogExceptionAsync("UploadVideoResume", ex.Message, ex.StackTrace);
            //return StatusCode(500, new ApiResponse<string>(false, null, "Internal Server Error", "ERR500"));
            throw;
        }
    }


    [Authorize(Roles = "Seafarer")]
    [HttpPost("profileCreation")]//using 
    public async Task<IActionResult> CreateUserProfile([FromBody] UserProfileDto userProfile)
    {
        try
        {
            var result = await _profileService.CreateUserProfileAsync(userProfile);
            return this.ToActionResult(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in CreateUserProfile");
            await _dbExceptionLogger.LogExceptionAsync("CreateUserProfile", ex.Message, ex.StackTrace);
            throw;
        }
    }

    [Authorize(Roles = "Seafarer")]
    [HttpPost("applicantSaveFiles")]//using 
    public async Task<IActionResult> UserApplicantSaveFiles([FromBody] UserResumeandImageDto userProfile)
    {
        try
        {
            var result = await _profileService.UserSaveFileAsync(userProfile);
            return this.ToActionResult(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in UserApplicantSaveFiles");
            await _dbExceptionLogger.LogExceptionAsync("applicantSaveFiles", ex.Message, ex.StackTrace);
            return StatusCode(500, "Internal Server Error");
        }
    }

    [Authorize(Roles = "Seafarer")]
    [HttpGet("seafarer-profile")]
    public async Task<IActionResult> GetSeafarerProfile([FromQuery] int userId)
    {
        try
        {
            var result = await _profileService.GetSeafarerProfileAsync(userId);

            return this.ToActionResult(result);

        }
        catch (Exception ex)
        {
            await _dbExceptionLogger.LogExceptionAsync("GetSeafarerProfile", ex.Message, ex.StackTrace);
            _logger.LogError(ex, "Exception occurred in GetSeafarerProfile");
            throw;
        }

    }

    [Authorize(Roles = "Seafarer")]
    [HttpPost("refer")]
    public async Task<IActionResult> ReferFriend([FromBody] ReferAFriendDto dto)
    {
        try
        {

            var result = await _profileService.ReferFriendAsync(dto);

            return this.ToActionResult(result);

        }
        catch (Exception ex)
        {
            await _dbExceptionLogger.LogExceptionAsync("ReferFriend", ex.Message, ex.StackTrace);
            _logger.LogError(ex, "Exception occurred in ReferFriend");
            throw;
        }
    }

    [Authorize(Roles = "Recruiter")]
    [HttpGet("companyprofile")]
    public async Task<IActionResult> GetCompanyProfile([FromQuery] int companyId)
    {
        try
        {


            var result = await _profileService.GetcompanyProfileAsync(companyId);

            return this.ToActionResult(result);

        }
        catch (Exception ex)
        {
            await _dbExceptionLogger.LogExceptionAsync("GetSeafarerProfile", ex.Message, ex.StackTrace);
            _logger.LogError(ex, "Exception occurred in GetSeafarerProfile");
            throw;
        }
    }

    [Authorize(Roles ="Seafarer")]
    [HttpPost("updateExperience")]
    public async Task<IActionResult> UpdateSeaExperience([FromBody] List<SeaExperianceViewPatchDto> dto)
    {
        try
        {
            var result = await _profileService.UpdateUserExperianceAsync(dto);

            return this.ToActionResult(result);

        }
        catch (Exception ex)
        {
            await _dbExceptionLogger.LogExceptionAsync("UpdateSeaExperience", ex.Message, ex.StackTrace);
            _logger.LogError(ex, "Error occurred in UpdateSeaExperience");
            throw;
        }
    }

    [Authorize(Roles ="Seafarer")]
    [HttpPost("updateCertificates")]
    public async Task<IActionResult> UpdateCertificateDetails([FromBody] List<CertificatesViewPatchDto> dto)
    {
        try
        {
            var result = await _profileService.UpdateUserDocumentCertificateAsync(dto);

            return this.ToActionResult(result);

        }
        catch (Exception ex)
        {
            await _dbExceptionLogger.LogExceptionAsync("UpdateCertificateDetails", ex.Message, ex.StackTrace);
            _logger.LogError(ex, "Error occurred in UpdateCertificateDetails");
            throw;
        }
    }

    [Authorize(Roles = "Seafarer")]
    [HttpGet("videoresume/base64/{userId:int}")]
    public async Task<IActionResult> GetVideoResumeBase64(int userId)
    {
        try
        {
            var result = await _profileService.GetVideoResumeBase64Async(userId);

            return this.ToActionResult(result);

        }
        catch (Exception ex)
        {
            await _dbExceptionLogger.LogExceptionAsync("GetVideoResumeBase64", ex.Message, ex.StackTrace);
            _logger.LogError(ex, "Error in GetVideoResumeBase64 for userId: {UserId}", userId);
            throw;
        }
    }

    [Authorize(Roles = "Seafarer")]
    [HttpGet("getUserfiles/{userId:int}")]
    public async Task<IActionResult> GetUserFiles(int userId)
    {
        try
        {
            var result = await _profileService.GetUserFilesAsync(userId);

            return this.ToActionResult(result);


        }
        catch (Exception ex)
        {
            await _dbExceptionLogger.LogExceptionAsync("GetVideoResumeBase64", ex.Message, ex.StackTrace);
            _logger.LogError(ex, "Error in GetVideoResumeBase64 for userId: {UserId}", userId);
            throw;
        }
    }
}