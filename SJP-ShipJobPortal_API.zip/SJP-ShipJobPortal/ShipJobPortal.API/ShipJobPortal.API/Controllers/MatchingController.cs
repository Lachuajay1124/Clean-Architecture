﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ShipJobPortal.API.Helpers;
using ShipJobPortal.Application.DTOs;
using ShipJobPortal.Application.IServices;
using ShipJobPortal.Controllers;
using ShipJobPortal.Domain.Constants;
using ShipJobPortal.Domain.Interfaces;
using Sprache;
namespace ShipJobPortal.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MatchingController : ControllerBase
    {
        private readonly IMatchingService _matchingServices;
        private readonly ILogger<MatchingController> _logger;
        private readonly IDbExceptionLogger _dbExceptionLogger;
        private readonly IConfiguration _configuration;
        public MatchingController(IMatchingService matchingServices, ILogger<MatchingController> logger, IDbExceptionLogger dbExceptionLogger, IConfiguration configuration)
        {
            _matchingServices = matchingServices;
            _logger = logger;
            _dbExceptionLogger = dbExceptionLogger;
            _configuration = configuration;
        }

        /// <summary>
        /// for sending user details to shiphire
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [Authorize(Roles ="Recruiter")]
        [HttpPost("sendCandidateDetails")]
        public async Task<IActionResult> SendCandidatetoShipHire([FromBody] CandidateListtoShiphireDto model)
        {
            try
            {
                var response = await _matchingServices.SendCandidatestoShipHire(model);
                return this.ToActionResult(response);
            }
            catch (Exception ex)

            {
                _logger.LogError(ex, "Error in SendCandidatetoShipHire");
                await _dbExceptionLogger.LogExceptionAsync("SendCandidatetoShipHire", ex.Message, ex.StackTrace);
                throw;
            }
        }

        [Authorize(Roles = "Recruiter")]
        [HttpGet("matchingCandidate")]
        public async Task<IActionResult> GetMatchingCandidateForJob([FromQuery]GetMatchingCandidateForJobDto request)
        {
            try
            {
                var result = await _matchingServices.GetMatchingCandidatesAsync(request);
                return this.ToActionResult(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetMatchingCandidateForJob");
                await _dbExceptionLogger.LogExceptionAsync("GetMatchingCandidateForJob", ex.Message, ex.StackTrace);
                throw;
            }
        }
    }
}

