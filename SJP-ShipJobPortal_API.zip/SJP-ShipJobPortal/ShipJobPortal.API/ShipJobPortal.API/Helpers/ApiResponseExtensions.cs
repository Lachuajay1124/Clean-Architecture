﻿using Microsoft.AspNetCore.Mvc;
using ShipJobPortal.Application.DTOs;   // ApiResponse<T>
using ShipJobPortal.Domain.Constants;  // ErrorCodes

namespace ShipJobPortal.API.Helpers
{
    public static class ApiResponseExtensions
    {
        /// <summary>
        /// Maps a domain/application ApiResponse<T> to an IActionResult.
        /// Set treatEmptyEnumerableAsNotFound=true to return 404 for success + empty enumerables.
        /// </summary>
        public static IActionResult ToActionResult<T>(
            this ControllerBase controller,
            ApiResponse<T> response,
            bool treatEmptyEnumerableAsNotFound = false)
        {
            // Defensive: null response -> 500
            if (response is null)
            {
                var nullResp = new ApiResponse<string>(false, null, "Null response.", ErrorCodes.InternalServerError);
                return controller.StatusCode(StatusCodes.Status500InternalServerError, nullResp);
            }

            // Success path
            if (response.Success)
            {
                if (treatEmptyEnumerableAsNotFound
                    && response.Data is System.Collections.IEnumerable seq
                    && response.Data is not string
                    && !seq.Cast<object>().Any())
                {
                    var notFound = new ApiResponse<object>(false, null, "No records found.", ErrorCodes.NotFound);
                    return controller.NotFound(notFound);
                }

                return controller.Ok(response);
            }

            // Failure path: map known error codes to HTTP
            if (response.ErrorCode == ErrorCodes.NotFound)     return controller.NotFound(response);
            if (response.ErrorCode == ErrorCodes.BadRequest)   return controller.BadRequest(response);
            if (response.ErrorCode == ErrorCodes.Unauthorized) return controller.Unauthorized(response);
            if (response.ErrorCode == ErrorCodes.Forbidden)    return controller.StatusCode(StatusCodes.Status403Forbidden, response);
            if (response.ErrorCode == ErrorCodes.Conflict)     return controller.Conflict(response);

            // Default -> 500
            return controller.StatusCode(StatusCodes.Status500InternalServerError, response);
        }
    }
}
