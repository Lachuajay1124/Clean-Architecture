﻿namespace ShipJobPortal.API.Helpers;

public interface ICookieHelper
{
    CookieOptions GetSecureCookieOptions(int expiryHours);
    CookieOptions GetSecureRefreshCookieOptions(int expiryDays);
}
public class CookieHelper : ICookieHelper
{
    private readonly IWebHostEnvironment _env;
    public CookieHelper(IWebHostEnvironment env)
    {
        _env = env;
    }
    public CookieOptions GetSecureCookieOptions(int expiryHours)
    {
        if (expiryHours <= 0 || expiryHours > 24)
            throw new ArgumentException("JWT expiry must be between 1-24 hours");

        return new CookieOptions
        {
            HttpOnly = true,
            Secure = true,//!_env.IsDevelopment(), // true in production, false in development
            SameSite = SameSiteMode.Strict,
            //Path = "/",
            Expires = DateTimeOffset.UtcNow.AddHours(expiryHours),
            //IsEssential = true
        };
    }

    public CookieOptions GetSecureRefreshCookieOptions(int expiryDays)
    {
        return new CookieOptions
        {
            HttpOnly = true,
            Secure = true,// !_env.IsDevelopment(),
            SameSite = SameSiteMode.Strict,
            //Path = "/",
            Expires = DateTimeOffset.UtcNow.AddDays(expiryDays),
            //IsEssential = true
        };
    }
}