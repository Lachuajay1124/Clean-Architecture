﻿namespace ShipJobPortal.Application.DTOs
{
    public class userOtpDto 
    {
        public string Email { get; set; }
    }

    public class UserOtpVerifyDto
    {

        public string emailid { get; set; }
        public string otp { get; set; }
        public string IpAddress { get; set; } = null;

    }
}
