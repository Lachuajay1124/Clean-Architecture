﻿namespace ShipJobPortal.Application.DTOs;
public class JobFilterRequestDto
{
    public int? PageNumber { get; set; } 
    public int? PageSize { get; set; } 
    public int? VacancyId { get; set; }
    public int? PositionId { get; set; }
    public int? VesselTypeId { get; set; }
    public int? LocationId { get; set; }
    public int? DurationId { get; set; }
    public string? SearchKey { get; set; }
    public int CandidateId { get; set; }
    public int? UserId { get; set; }
    public int? CompanyId { get; set; }
}

public class GetAppliedCandidateRequestDto
{
    public int jobId { get; set; }
    public int pageNumber { get; set; } = 1;
    public int pageSize { get; set; } = 8;
    public int? positionId { get; set; } = 0;
    public int? vesselTypeId { get; set; } = 0;
    public int? locationId { get; set; } = 0;
    public int? durationId { get; set; } = 0;
    public string? searchKey { get; set; }
}

public class GetAppliedJobsForCandidateDto
{
    public int UserId { get; set; }
    public int pageNumber { get; set; } = 1;
    public int pageSize { get; set; } = 8;
    public int? positionId { get; set; } = 0;
    public int? vesselTypeId { get; set; } = 0;
    public int? locationId { get; set; } = 0;
    public int? durationId { get; set; } = 0;
    public string? searchKey { get; set; }
}

public class GetSavedJobsForCandidateDto
{
    public int UserId { get; set; }
    public int pageNumber { get; set; } = 1;
    public int pageSize { get; set; } = 10;
    public int? positionId { get; set; } = 0;
    public int? vesselTypeId { get; set; } = 0;
    public int? locationId { get; set; } = 0;
    public int? durationId { get; set; } = 0;
    public int? monthValue { get; set; } = 0;
    public string? searchKey { get; set; }
}

public class GetMatchingCandidateForJobDto
{
    public int jobId { get; set; }
    public int userId { get; set; }
    public int pageNumber { get; set; } = 1;
    public int pageSize { get; set; } = 10;
    public int? positionId { get; set; } = 0;
    public int? vesselTypeId { get; set; } = 0;
    public int? locationId { get; set; } = 0;
    public int? durationId { get; set; } = 0;
}