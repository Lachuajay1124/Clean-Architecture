﻿namespace ShipJobPortal.Application.DTOs
{
    public class ResumeDetialsDto
    {
        public string? Address { get; set; }
        public string? Addresscountry { get; set; }
        public string? Addressstateorprovince { get; set; }
        public string? Dateofbirth { get; set; }
        public string? Email { get; set; }
        public string? Firstname { get; set; }
        public string? Mobilenumber { get; set; }
        public string? Nationality { get; set; }
        public string? Seamanbooknumber { get; set; }
        public string? Surname { get; set; }


    }
    public class SeaExperianceDto
    {

    }

    public class PersonalDocuments
    {

    }
}
