﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShipJobPortal.Application.DTOs
{
    public class NationalityDto
    {
        public int NationalityId { get; set; }
        public string Nationality { get; set; }
        public string CountryCode { get; set; }
    }
}
