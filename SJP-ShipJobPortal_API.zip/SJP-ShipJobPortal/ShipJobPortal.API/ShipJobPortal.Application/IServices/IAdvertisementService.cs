﻿namespace ShipJobPortal.Application.IServices;

public interface IAdvertisementService
{
}
