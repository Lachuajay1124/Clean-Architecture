﻿using ShipJobPortal.Application.DTOs;

namespace ShipJobPortal.Application.IServices;

public interface IJobPostService
{
    Task<ApiResponse<string>> CreateJobAsync(JobCreateDto dto);
    Task<ApiResponse<JobViewFilteredDto>> GetJobsFilteredAsync(JobFilterRequestDto dto);
    Task<ApiResponse<string>> EditJobAsync(int vacancyId, Dictionary<string, object> patchData);
    Task<ApiResponse<string>> DeleteJobAsync(int vacancyId);

    Task<ApiResponse<string>> JobViewCount(JobViewCountDto dto); 

}
