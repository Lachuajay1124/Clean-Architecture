﻿using ShipJobPortal.Application.DTOs;

namespace ShipJobPortal.Application.IServices;

public interface IGetListService
{
    Task<ApiResponse<IEnumerable<GetCountryListDto>>> GetAllCountryAsync();
    Task<ApiResponse<IEnumerable<GetStateListDto>>> GetAllStateAsync(int? countryId);
    Task<ApiResponse<IEnumerable<GetCityListDto>>> GetAllCityAsync(int? stateId);
    Task<ApiResponse<IEnumerable<VesselTypeDto>>> GetAllVesselTypeAsync();
    Task<ApiResponse<IEnumerable<ContractDurationDto>>> GetAllContractDurationAsync();
    Task<ApiResponse<IEnumerable<PositionDto>>> GetAllPositionAsync(int? companyId);
    Task<ApiResponse<IEnumerable<MobileCountryCodeDto>>> GetAllMobileCodesAsync();
    Task<ApiResponse<IEnumerable<DocumentListDto>>> GetDocumentsList();
    Task<ApiResponse<IEnumerable<DocumentSectionDto>>> GetAllDocumentSectionAsync();
    Task<ApiResponse<IEnumerable<DocumentCategoryDto>>> GetAllDocumentCategoryAsync();
    Task<ApiResponse<IEnumerable<DocumentTypeDto>>> GetAllDocumentTypeAsync();
    Task<ApiResponse<IEnumerable<IndustryDto>>> GetAllIndustryAsync();

}
