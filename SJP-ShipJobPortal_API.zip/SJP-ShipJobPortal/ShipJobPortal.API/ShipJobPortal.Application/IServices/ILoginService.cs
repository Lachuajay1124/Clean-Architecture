﻿using ShipJobPortal.Application.DTOs;
using ShipJobPortal.Application.Services;
using ShipJobPortal.Application.Validators;
using ShipJobPortal.Domain.Constants;
using ShipJobPortal.Domain.Entities;
using ShipJobPortal.Domain.Interfaces;

namespace ShipJobPortal.Application.IServices;

public interface ILoginService
{
    Task<ApiResponse<object>> CreateUserAsync(UserApplicantDto dto);

    Task<ApiResponse<AuthResponse>> RefreshTokenAsync(string refreshToken);

    Task<ApiResponse<bool>> LogoutAsync(string refreshToken);

    Task<ApiResponse<object>> ResetPasswordAsync(ResetPasswordDto request);

    Task<ApiResponse<string>> VerifySeamanbookAsync(string SeamanBooknumorPassport);

    Task<ApiResponse<AuthenticateResult?>> AuthenticateUserAsync_test(UserLoginDto loginDto);

    Task<ApiResponse<AuthenticateResult?>> AuthenticateUserAsync(UserLoginDto loginDto);
    Task<ApiResponse<AuthenticateResult>> RegisterAsyns(UserLoginDto loginDto);

    Task<ApiResponse<AuthenticateResult>> OauthuserAsync(UserLoginDto loginDto);
}

