﻿using ShipJobPortal.Application.DTOs;

namespace ShipJobPortal.Application.IServices;

public interface ICompanyService
{
    Task<ApiResponse<string>> CreateCompanyAsync(CompanyCreateDto dto, string username);
    Task<ApiResponse<IEnumerable<CompanyDto>>> GetCompanyAsync(int CompanyId);
    Task<ApiResponse<IEnumerable<CompanyDropDto>>> GetAllCompaniesAsync();
}