﻿using ShipJobPortal.Application.DTOs;
namespace ShipJobPortal.Application.IServices;
public interface IMatchingService
{
    Task<ApiResponse<string>> SendCandidatestoShipHire(CandidateListtoShiphireDto model);
    Task<ApiResponse<MatchingCandidateViewDto>> GetMatchingCandidatesAsync(GetMatchingCandidateForJobDto request);
}