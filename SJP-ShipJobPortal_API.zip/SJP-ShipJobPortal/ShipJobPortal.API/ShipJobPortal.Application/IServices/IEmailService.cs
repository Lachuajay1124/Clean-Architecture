﻿using ShipJobPortal.Application.DTOs;

namespace ShipJobPortal.Application.IServices;

public interface IEmailService
{
    Task<ApiResponse<bool>> SendOtpEmailAsync(string toEmail, string otpCode);
}
