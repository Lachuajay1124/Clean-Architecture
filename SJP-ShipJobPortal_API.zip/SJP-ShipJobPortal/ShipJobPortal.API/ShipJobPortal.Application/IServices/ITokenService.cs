﻿namespace ShipJobPortal.Application.IServices;

public interface ITokenService
{
    string GenerateRefreshToken();
    string GenerateJwtToken(string username, string userRole);


}
