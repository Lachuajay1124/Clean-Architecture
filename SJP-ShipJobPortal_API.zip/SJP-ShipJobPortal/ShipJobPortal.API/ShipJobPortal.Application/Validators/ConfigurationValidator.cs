﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace ShipJobPortal.Application.Validators
{
    public static class ConfigurationValidator
    {
        public static void ValidateSecurityConfiguration(IConfiguration config,
        IWebHostEnvironment env)
        {
            var errors = new List<string>();
            // Validate JWT settings
            ValidateJwtSettings(config, env, errors);
            // Validate connection strings
            ValidateConnectionStrings(config, errors);
            // Validate CORS settings
            ValidateCorsSettings(config, errors);
            if (errors.Any())
            {
                var errorMessage = "Configuration validation failed:\n" + string.Join("\n",
                errors);
                throw new InvalidOperationException(errorMessage);
            }
        }
        private static void ValidateJwtSettings(IConfiguration config, IWebHostEnvironment env,
        List<string> errors)
        {
            // Check for JWT configuration
            var jwtKey = Environment.GetEnvironmentVariable("JWT_TOKEN_KEY") ??
            config["TokenSettings:TokenKey"];
            if (string.IsNullOrEmpty(jwtKey))
            {
                errors.Add("JWT_TOKEN_KEY environment variable or TokenSettings:TokenKey is required");
            }
            else if (jwtKey.Length < 32)
            {
                errors.Add("JWT_TOKEN_KEY must be at least 32 characters long");
            }
            var issuer = Environment.GetEnvironmentVariable("JWT_ISSUER") ??
            config["TokenSettings:Issuer"];
            if (string.IsNullOrEmpty(issuer))
            {
                errors.Add("JWT_ISSUER environment variable or TokenSettings:Issuer is required");
            }
            var audience = Environment.GetEnvironmentVariable("JWT_AUDIENCE") ??
            config["TokenSettings:Audience"];
            if (string.IsNullOrEmpty(audience))
            {
                errors.Add("JWT_AUDIENCE environment variable or TokenSettings:Audience is required");
            }
            // Validate token expiry
            var expiryHours = config.GetValue<int>("TokenSettings:JwtTokenExpiryHours");
            if (expiryHours <= 0 || expiryHours > 24)
            {
                errors.Add("TokenSettings:JwtTokenExpiryHours must be between 1 and 24");
            }
        }
        private static void ValidateConnectionStrings(IConfiguration config, List<string>
        errors)
        {
            var defaultConnection =
            Environment.GetEnvironmentVariable("DATABASE_CONNECTION_STRING")
            ?? config.GetConnectionString("DefaultConnection");
            if (string.IsNullOrEmpty(defaultConnection))
            {
                errors.Add("DATABASE_CONNECTION_STRING environment variable or DefaultConnection is required");
            }
        }
        private static void ValidateCorsSettings(IConfiguration config, List<string> errors)
        {
            var allowedOrigins = config.GetSection("Cors:AllowedOrigins").Get<string[]>();
            if (allowedOrigins == null || !allowedOrigins.Any())
            {
                errors.Add("Cors:AllowedOrigins must be configured with at least one origin");
            }
        }
    }

}
