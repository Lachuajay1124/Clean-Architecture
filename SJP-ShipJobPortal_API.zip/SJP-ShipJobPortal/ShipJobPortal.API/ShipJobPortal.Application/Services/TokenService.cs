﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using ShipJobPortal.Application.IServices;
using ShipJobPortal.Domain.Interfaces;

namespace ShipJobPortal.Application.Services;

public class TokenService:ITokenService
{
    private readonly ITokenRepository _tokenRepository;
    private readonly ILogger<TokenService> _logger;
    private readonly IMapper _mapper;
    private readonly IConfiguration _configuration;


    public TokenService(ITokenRepository tokenRepository, ILogger<TokenService> logger, IMapper mapper, IConfiguration configuration)
    {
        _tokenRepository = tokenRepository;
        _logger = logger;
        _mapper = mapper;
        _configuration = configuration;
    }


    public string GenerateJwtToken(string username, string userRole)
    {
        try
        {
            //string userId = "";
            string tokenKey = _configuration["TokenSettings:TokenKey"];
            string issuer = _configuration["TokenSettings:Issuer"];
            string audience = _configuration["TokenSettings:Audience"];
            int jwtExpiryHours = Convert.ToInt32(_configuration["TokenSettings:JwtTokenExpiryHours"]);

            if (string.IsNullOrWhiteSpace(tokenKey) || tokenKey.Length < 16)
                throw new Exception("Token key must be at least 16 characters long.");

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(tokenKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
    new Claim(ClaimTypes.Email, username),
    new Claim(ClaimTypes.Role, userRole),
//new Claim(ClaimTypes.NameIdentifier, userId.ToString())
};

            var token = new JwtSecurityToken(
                issuer: issuer,
                audience: audience,
                claims: claims,
                expires: DateTime.UtcNow.AddHours(jwtExpiryHours),
                signingCredentials: creds
            );
            //var jwtString = new JwtSecurityTokenHandler().WriteToken(token);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred in GenerateJwtToken");
            throw;
        }
    }


    public string GenerateJwtToken_new(
    int userId,
    string username,
    string userRole,
    string? tenantId = null,
    IEnumerable<string>? scopes = null)
    {
        try
        {
            var tokenKey = _configuration["TokenSettings:TokenKey"];
            var issuer = _configuration["TokenSettings:Issuer"];
            var audience = _configuration["TokenSettings:Audience"];
            var accessMinutes = int.Parse(_configuration["TokenSettings:AccessTokenMinutes"] ?? "15");

            if (string.IsNullOrWhiteSpace(tokenKey) || tokenKey.Length < 32)
                throw new Exception("Token key must be at least 32 chars for HS256.");

            var now = DateTime.UtcNow;
            var jti = Guid.NewGuid().ToString("N");

            var claims = new List<Claim>
        {
            new Claim(JwtRegisteredClaimNames.Sub, userId.ToString()),
            new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
            new Claim(ClaimTypes.Name, username),
            new Claim(ClaimTypes.Role, userRole),
            new Claim(JwtRegisteredClaimNames.Jti, jti),
            new Claim(JwtRegisteredClaimNames.Iat,
                      new DateTimeOffset(now).ToUnixTimeSeconds().ToString(), ClaimValueTypes.Integer64)
        };

            if (!string.IsNullOrWhiteSpace(tenantId))
                claims.Add(new Claim("tid", tenantId));
            if (scopes != null && scopes.Any())
                claims.Add(new Claim("scope", string.Join(' ', scopes))); // space-delimited OAuth-style

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(tokenKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: issuer,
                audience: audience,
                claims: claims,
                notBefore: now,                               // nbf
                expires: now.AddMinutes(accessMinutes),      // exp
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in GenerateJwtToken");
            throw;
        }
    }



    public string GenerateRefreshToken()
    {
        try
        {
            return Convert.ToBase64String(RandomNumberGenerator.GetBytes(64));
        }
        catch (Exception ex)
        {
            throw;
        }
    }


}
