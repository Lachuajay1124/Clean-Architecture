﻿using ShipJobPortal.Domain.Entities;
using ShipJobPortal.Domain.Interfaces;
using Microsoft.Extensions.Configuration;
using ShipJobPortal.Application.DTOs;
using Microsoft.Extensions.Logging;
using AutoMapper;
using ShipJobPortal.Application.IServices;
using ShipJobPortal.Domain.Constants;
using ShipJobPortal.Application.Validators;
using System.Text.RegularExpressions;

namespace ShipJobPortal.Application.Services;

public class LoginService : ILoginService
{
    private readonly ILoginRepository _logInRepository;
    private readonly IConfiguration _configuration;
    private readonly IPasswordHasher _passwordHasher;
    private readonly ILogger<LoginService> _logger;
    private readonly IMapper _mapper;
    private readonly IDbExceptionLogger _dbExceptionLogger;
    private readonly ITokenService _tokenService;
    private readonly ITokenRepository _tokenRepository;
    public LoginService(ILoginRepository logInRepository, IConfiguration configuration, IPasswordHasher passwordHasher, ILogger<LoginService> logger, IMapper mapper, IDbExceptionLogger dbExceptionLogger, ITokenService tokenService, ITokenRepository tokenRepository)
    {
        _logInRepository = logInRepository;
        _configuration = configuration;
        _passwordHasher = passwordHasher;
        _logger = logger;
        _mapper = mapper;
        _dbExceptionLogger = dbExceptionLogger;
        _tokenService = tokenService;
        _tokenRepository = tokenRepository;
    }

    public async Task<ApiResponse<object>> CreateUserAsync(UserApplicantDto dto)
    {
        try
        {
            var user = _mapper.Map<UserApplicantModel>(dto);


            var (isValid, errorMsg) = PasswordPolicyValidator.Validate(
        password: user.Password,
        username: user.Email,              // Or dto.Username if different
        previousPassword: null             // Optional: can fetch from history if needed
    );

            if (!isValid)
                return new ApiResponse<object>(false, null, $"Password policy violation: {errorMsg}", ErrorCodes.InvalidPassword);

            user.Password = _passwordHasher.HashPassword(user.Password);



            var result = await _logInRepository.CreateUserAsync(user);
            if (result.ErrorCode == "ERR409")
                return new ApiResponse<object>(false, null, "Email or Contact Number already exists.", ErrorCodes.Conflict);

            if (result.ReturnStatus == "Seafarer Insert Success" && result.ErrorCode == "ERR200")
                return new ApiResponse<object>(true, null, "User created successfully.", ErrorCodes.Success);

            if (result.ReturnStatus == "Recruiter Insert Success" && result.ErrorCode == "ERR200")
                return new ApiResponse<object>(true, null, "User created successfully.", ErrorCodes.Success);

            return new ApiResponse<object>(false, null, "Failed to create user.", ErrorCodes.BadRequest);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred in CreateUserAsync");
            throw;
        }
    }

    public async Task<ApiResponse<AuthResponse>> RefreshTokenAsync(string refreshToken)
    {
        try
        {
            // 0) Validate input
            if (string.IsNullOrWhiteSpace(refreshToken))
            {
                return new ApiResponse<AuthResponse>(
                    false, null, "Refresh token is required.", ErrorCodes.BadRequest);
            }

            // 1) Fetch existing token (assumed: ReturnResult<RefreshToken>)
            var tokenRes = await _tokenRepository.GetRefreshTokenAsync(refreshToken);

            if (tokenRes == null ||
                !string.Equals(tokenRes.ReturnStatus, "success", StringComparison.OrdinalIgnoreCase) ||
                tokenRes.Data == null)
            {
                return new ApiResponse<AuthResponse>(
                    false, null, "Invalid refresh token.", ErrorCodes.InvalidCredentials);
            }

            var tokenEntity = tokenRes.Data;

            // 2) Expiry check (UTC)
            if (tokenEntity.TokenExpiryDate <= DateTime.UtcNow)
            {
                return new ApiResponse<AuthResponse>(
                    false, null, "Token expired.", ErrorCodes.InvalidCredentials);
            }

            // 3) Read config safely (with sane defaults)
            int jwtExpiryHours = int.TryParse(_configuration["TokenSettings:JwtTokenExpiryHours"], out var h)
                ? h : 1;
            int refreshExpiryDays = int.TryParse(_configuration["TokenSettings:RefreshTokenExpiryDays"], out var d)
                ? d : 7;

            // 4) Generate new tokens (rotation)
            var newAccessToken = _tokenService.GenerateJwtToken(tokenEntity.Email_Id, tokenEntity.Role);
            var newRefreshToken = _tokenService.GenerateRefreshToken();

            // 5) Persist rotated refresh token
            var updRes = await _tokenRepository.UpdateRefreshTokenAsync(new RefreshToken
            {
                Email_Id = tokenEntity.Email_Id,
                Token = newRefreshToken,
                TokenExpiryDate = DateTime.UtcNow.AddDays(refreshExpiryDays),
                Role = tokenEntity.Role,
                UserId = tokenEntity.UserId
            });

            if (updRes == null ||
                !string.Equals(updRes.ReturnStatus, "success", StringComparison.OrdinalIgnoreCase) ||
                !string.Equals(updRes.ErrorCode, "ERR200", StringComparison.OrdinalIgnoreCase))
            {
                return new ApiResponse<AuthResponse>(
                    false, null, "Failed to rotate refresh token.", updRes?.ErrorCode ?? ErrorCodes.InternalServerError);
            }

            // 6) Build response
            var response = new AuthResponse
            {
                AccessToken = newAccessToken,
                RefreshToken = newRefreshToken,
                Role = tokenEntity.Role,
                Email = tokenEntity.Email_Id,
                UserId = tokenEntity.UserId,
                ExpiresIn = jwtExpiryHours * 3600
            };

            return new ApiResponse<AuthResponse>(
                true, response, "Token refreshed successfully.", ErrorCodes.Success);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in RefreshTokenAsync");
            throw;
        }
    }

    public async Task<ApiResponse<bool>> LogoutAsync(string refreshToken)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(refreshToken))
            {
                return new ApiResponse<bool>(
                    false, false, "Refresh token is required.", ErrorCodes.BadRequest);
            }
            var getRes = await _tokenRepository.GetRefreshTokenAsync(refreshToken);

            if (getRes == null ||
                !string.Equals(getRes.ReturnStatus, "success", StringComparison.OrdinalIgnoreCase) ||
                getRes.Data == null)
            {
                return new ApiResponse<bool>(
                    false, false, "Refresh token not found.", ErrorCodes.NotFound);
            }

            var delRes = await _tokenRepository.DeleteRefreshTokenAsync(refreshToken);

            if (delRes != null &&
                string.Equals(delRes.ReturnStatus, "success", StringComparison.OrdinalIgnoreCase) &&
                string.Equals(delRes.ErrorCode, "ERR200", StringComparison.OrdinalIgnoreCase))
            {
                return new ApiResponse<bool>(
                    true, true, "Logged out successfully.", ErrorCodes.Success);
            }

            return new ApiResponse<bool>(
                false,
                false,
                "Failed to revoke refresh token.",
                delRes?.ErrorCode ?? ErrorCodes.InternalServerError
            );
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred in LogoutAsync for token: {RefreshToken}", refreshToken);
            throw;
        }
    }

    public async Task<ApiResponse<object>> ResetPasswordAsync(ResetPasswordDto request)
    {
        try
        {
            //string email = _encryptionService.Encrypt(request.Email);
            var password = _mapper.Map<UserApplicantModel>(request);

            var user = await _logInRepository.GetUserRoleAsync(request.Username);
            if (user == null)
            {
                return new ApiResponse<object>(false, null, "User not found", ErrorCodes.NotFound);
            }

            string encryptedPassword = user.Data.PasswordHash?.ToString();

            bool isCurrentPasswordValid = _passwordHasher.VerifyPassword(request.CurrentPassword, encryptedPassword);
            if (!isCurrentPasswordValid)
            {
                return new ApiResponse<object>(false, null, "Current password is incorrect", ErrorCodes.InvalidPassword);
            }

            var (isValid, errorMsg) = PasswordPolicyValidator.Validate(
                  password: password.Password,
                  username: password.Email,
                  previousPassword: null
            );

            if (!isValid)
                return new ApiResponse<object>(false, null, $"Password policy violation: {errorMsg}", ErrorCodes.InvalidPassword);

            string newHashedPassword = _passwordHasher.HashPassword(request.Password);
            await _logInRepository.ResetPasswordAsync(request.Username, encryptedPassword, newHashedPassword);

            return new ApiResponse<object>(true, null, "Password reset successfully.", ErrorCodes.Success);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred in ResetPasswordAsync");
            throw;
        }
    }

    public async Task<ApiResponse<string>> VerifySeamanbookAsync(string SeamanBooknumorPassport)
    {
        try
        {
            var user = await _logInRepository.SeamanBooknumberExistsAsync(SeamanBooknumorPassport);
            if (user.Data == null)
            {
                return new ApiResponse<string>(true, null, "User not exist", ErrorCodes.Success);
            }
            return new ApiResponse<string>(false, null, "User exist", ErrorCodes.BadRequest);

        }
        catch (Exception ex)
        {

        }
        return null;
    }

    public async Task<ApiResponse<AuthenticateResult?>> AuthenticateUserAsync_test(UserLoginDto loginDto)
    {
        try
        {
            int moduleFetch = -1;
            var result = new AuthenticateResult();
            if (loginDto.Role.ToLower() == "recruiter" && loginDto.LoginType.ToLower() != "portal")
            {
                return new ApiResponse<AuthenticateResult?>(false, null, "recruiters must login via portal", ErrorCodes.Forbidden);
            }

            if (loginDto.LoginType.ToLower() == "portal" && string.IsNullOrWhiteSpace(loginDto.Password))
            {
                return new ApiResponse<AuthenticateResult?>(false, null, "Password is required for portal login.", ErrorCodes.BadRequest);
            }
            // 1. Check if user exists
            var user = await _logInRepository.UserExistsAsync(loginDto.Email);
            if (loginDto.LoginType == "register" && user.Data == null)
            {

                // User doesn't exist - auto-create for Google/LinkedIn
                if (loginDto.LoginType.ToLower() == "register")
                {
                    loginDto.Password = _passwordHasher.HashPassword(loginDto.Password);
                }

                var userdata = _mapper.Map<UserApplicantModel>(loginDto);
                userdata.loginType = "Portal";
                var createResult = await _logInRepository.CreateUserAsync(userdata);
                var userCreationData = createResult.Data as UserCreationResult;

                if (userCreationData != null)
                {
                    result.ResumeStatus = userCreationData.Status;
                    result.UserId = userCreationData.UserId;
                }

                if (createResult.ReturnStatus == "Seafarer Insert Success")
                {
                    moduleFetch = 1;
                    result.Email = loginDto.Email;
                    result.Role = loginDto.Role;
                    result.LoginType = userdata.loginType;
                    moduleFetch = 1;
                    var jwtToken = _tokenService.GenerateJwtToken(result.Email, loginDto.Role); // custom method

                    var refreshToken = _tokenService.GenerateRefreshToken();

                    await _tokenRepository.UpdateRefreshTokenAsync(new RefreshToken
                    {
                        Email_Id = result.Email,
                        Token = refreshToken,
                        TokenExpiryDate = DateTime.UtcNow.AddDays(7), // or from config
                        Role = result.Role,
                        UserId = result.UserId
                    });
                    result.AccessToken = jwtToken;
                    result.RefreshToken = refreshToken;
                }
                else
                {
                    return new ApiResponse<AuthenticateResult>(false, null, "User creation failed.", ErrorCodes.InternalServerError);
                }
            }

            else if (user.Data == null && (loginDto.LoginType.ToLower() == "google" || loginDto.LoginType.ToLower() == "linkedin"))
            {
                var userdata = _mapper.Map<UserApplicantModel>(loginDto);
                var createResult = await _logInRepository.CreateUserAsync(userdata);
                var userCreationData = createResult.Data as UserCreationResult;

                if (userCreationData != null)
                {
                    result.ResumeStatus = userCreationData.Status;
                    result.UserId = userCreationData.UserId;
                }

                if (createResult.ReturnStatus == "Seafarer Insert Success")
                {
                    moduleFetch = 1;
                    result.Email = loginDto.Email;
                    result.Role = loginDto.Role;
                    result.LoginType = loginDto.LoginType;
                    moduleFetch = 1;
                    var jwtToken = _tokenService.GenerateJwtToken(result.Email, loginDto.Role); // custom method
                    var refreshToken = _tokenService.GenerateRefreshToken();

                    await _tokenRepository.UpdateRefreshTokenAsync(new RefreshToken
                    {
                        Email_Id = result.Email,
                        Token = refreshToken,
                        TokenExpiryDate = DateTime.UtcNow.AddDays(7), // or from config
                        Role = result.Role,
                        UserId = result.UserId
                    });
                    result.AccessToken = jwtToken;
                    result.RefreshToken = refreshToken;
                }
                else
                {
                    return new ApiResponse<AuthenticateResult>(false, null, "User creation failed.", ErrorCodes.InternalServerError);
                }
            }

            else
            {
                // 2. Existing user - verify password if portal
                var getUserResult = await _logInRepository.ExistingUserDetails(loginDto.Email);
                var getUser = getUserResult.Data;

                if (getUser == null)
                {
                    return new ApiResponse<AuthenticateResult>(false, null, "User not verified", ErrorCodes.NotFound);
                }

                if (loginDto.LoginType.ToLower() == "portal" || loginDto.LoginType.ToLower() == "register")
                {
                    if (!_passwordHasher.VerifyPassword(loginDto.Password, getUser.PasswordHash))
                    {
                        return new ApiResponse<AuthenticateResult>(false, null, "Incorrect password.", ErrorCodes.InvalidPassword);
                    }
                }
                result.ResumeStatus = getUser.ResumeStatus;
                if (getUser.RoleName.ToLower() == "recruiter")
                {
                    result.ResumeStatus = "recruiter";

                }
                result.UserId = getUser.UserId ?? 0;
                result.Email = getUser.Username;
                result.Role = getUser.RoleName;
                if (loginDto.Role.ToLower() != getUser.RoleName.ToLower())
                {
                    return new ApiResponse<AuthenticateResult>(false, null, "Invalid role for this login", ErrorCodes.InvalidCredentials);
                }
                result.LoginType = loginDto.LoginType;
                moduleFetch = 1;
                var jwtToken = _tokenService.GenerateJwtToken(result.Email, loginDto.Role); // custom method
                var refreshToken = _tokenService.GenerateRefreshToken();

                await _tokenRepository.UpdateRefreshTokenAsync(new RefreshToken
                {
                    Email_Id = result.Email,
                    Token = refreshToken,
                    TokenExpiryDate = DateTime.UtcNow.AddDays(7), // or from config
                    Role = result.Role,
                    UserId = result.UserId
                });
                result.AccessToken = jwtToken;
                result.RefreshToken = refreshToken;

            }

            // 3. Fetch module privileges
            if (moduleFetch == 1)
            {
                var moduleResult = await _logInRepository.GetModulePrivilegesByRoleAsync(loginDto.Role);

                if (moduleResult.Data == null || moduleResult.Data.Count == 0)
                {
                    return new ApiResponse<AuthenticateResult>(false, result, "No modules assigned to this role", ErrorCodes.NotFound);
                }

                result.RoleModulePrevilleages = _mapper.Map<List<ModulePrevilleages>>(moduleResult.Data);

                return new ApiResponse<AuthenticateResult>(true, result, "Login successful", ErrorCodes.Success);
            }

            return new ApiResponse<AuthenticateResult>(false, null, "Authentication failed", ErrorCodes.InternalServerError);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred in AuthenticateUserAsync");
            throw;
        }
    }

    public async Task<ApiResponse<AuthenticateResult?>> AuthenticateUserAsync(UserLoginDto loginDto)
    {
        try
        {
            int moduleFetch = -1;
            var result = new AuthenticateResult();

            // 1. Check if user exists
            var user = await _logInRepository.UserExistsAsync(loginDto.Email);
            if (user.Data != null)
            {
                // 2. Existing user - verify password if portal
                var getUserResult = await _logInRepository.ExistingUserDetails(loginDto.Email);
                var getUser = getUserResult.Data;

                if (getUser == null)
                {
                    return new ApiResponse<AuthenticateResult>(false, null, "User not found", ErrorCodes.NotFound);
                }

                if (loginDto.LoginType.ToLower() == "portal")// || loginDto.LoginType.ToLower() == "register")
                {
                    if (!_passwordHasher.VerifyPassword(loginDto.Password, getUser.PasswordHash))
                    {
                        return new ApiResponse<AuthenticateResult>(false, null, "Incorrect password.", ErrorCodes.InvalidPassword);
                    }
                }
                result.ResumeStatus = getUser.ResumeStatus;
                if (getUser.RoleName.ToLower() == "recruiter")
                {
                    result.ResumeStatus = "recruiter";

                }
                result.UserId = getUser.UserId ?? 0;
                result.Email = getUser.Username;
                result.Role = getUser.RoleName;
                if (loginDto.Role.ToLower() != getUser.RoleName.ToLower())
                {
                    return new ApiResponse<AuthenticateResult>(false, null, "Invalid role for this login", ErrorCodes.InvalidCredentials);
                }
                result.LoginType = loginDto.LoginType;
                moduleFetch = 1;
                var refreshToken = getUser.RefreshToken;

                var jwtToken = _tokenService.GenerateJwtToken(result.Email, loginDto.Role); // custom method
                if (getUser.RefreshToken == null)
                {
                    refreshToken = _tokenService.GenerateRefreshToken();
                    await _tokenRepository.UpdateRefreshTokenAsync(new RefreshToken
                    {
                        Email_Id = result.Email,
                        Token = refreshToken,
                        TokenExpiryDate = DateTime.UtcNow.AddDays(7), // or from config
                        Role = result.Role,
                        UserId = result.UserId
                    });
                }


                result.AccessToken = jwtToken;
                result.RefreshToken = refreshToken;

            }

            // 3. Fetch module privileges
            if (moduleFetch == 1)
            {
                var moduleResult = await _logInRepository.GetModulePrivilegesByRoleAsync(loginDto.Role);

                if (moduleResult.Data == null || moduleResult.Data.Count == 0)
                {
                    return new ApiResponse<AuthenticateResult>(false, result, "No modules assigned to this role", ErrorCodes.NotFound);
                }

                result.RoleModulePrevilleages = _mapper.Map<List<ModulePrevilleages>>(moduleResult.Data);

                return new ApiResponse<AuthenticateResult>(true, result, "Login successful", ErrorCodes.Success);
            }

            return new ApiResponse<AuthenticateResult>(false, null, "Authentication failed", ErrorCodes.InternalServerError);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred in AuthenticateUserAsync");
            throw;
        }
    }

    public async Task<ApiResponse<AuthenticateResult>> RegisterAsyns(UserLoginDto loginDto)
    {
        try
        {
            int moduleFetch = -1;
            var result = new AuthenticateResult();

            // 1. Check if user exists
            var user = await _logInRepository.UserExistsAsync(loginDto.Email);
            if (loginDto.LoginType == "register" && user.Data == null)
            {

                // User doesn't exist - auto-create for Google/LinkedIn
                if (loginDto.LoginType.ToLower() == "register")
                {
                    loginDto.Password = _passwordHasher.HashPassword(loginDto.Password);
                }

                var userdata = _mapper.Map<UserApplicantModel>(loginDto);
                userdata.loginType = "Portal";
                var createResult = await _logInRepository.CreateUserAsync(userdata);
                var userCreationData = createResult.Data as UserCreationResult;

                if (userCreationData != null)
                {
                    result.ResumeStatus = userCreationData.Status;
                    result.UserId = userCreationData.UserId;
                }

                if (createResult.ReturnStatus == "Seafarer Insert Success")
                {
                    moduleFetch = 1;
                    result.Email = loginDto.Email;
                    result.Role = loginDto.Role;
                    result.LoginType = userdata.loginType;
                    moduleFetch = 1;
                    var jwtToken = _tokenService.GenerateJwtToken(result.Email, loginDto.Role); // custom method
                    var refreshToken = _tokenService.GenerateRefreshToken();

                    await _tokenRepository.UpdateRefreshTokenAsync(new RefreshToken
                    {
                        Email_Id = result.Email,
                        Token = refreshToken,
                        TokenExpiryDate = DateTime.UtcNow.AddDays(7), // or from config
                        Role = result.Role,
                        UserId = result.UserId
                    });
                    result.AccessToken = jwtToken;
                    result.RefreshToken = refreshToken;
                }
                else
                {
                    return new ApiResponse<AuthenticateResult>(false, null, "User creation failed.", ErrorCodes.InternalServerError);
                }
            }
            if (moduleFetch == 1)
            {
                var moduleResult = await _logInRepository.GetModulePrivilegesByRoleAsync(loginDto.Role);

                if (moduleResult.Data == null || moduleResult.Data.Count == 0)
                {
                    return new ApiResponse<AuthenticateResult>(false, result, "No modules assigned to this role", ErrorCodes.NotFound);
                }

                result.RoleModulePrevilleages = _mapper.Map<List<ModulePrevilleages>>(moduleResult.Data);

                return new ApiResponse<AuthenticateResult>(true, result, "Login successful", ErrorCodes.Success);
            }

            return new ApiResponse<AuthenticateResult>(false, null, "Authentication failed", ErrorCodes.InternalServerError);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred in RegisterAsyns");
            throw;
        }

    }

    public async Task<ApiResponse<AuthenticateResult>> OauthuserAsync(UserLoginDto loginDto)
    {
        try
        {
            int moduleFetch = -1;
            var result = new AuthenticateResult();

            // 1. Check if user exists
            var user = await _logInRepository.UserExistsAsync(loginDto.Email);
            if (user.Data == null)
            {
                var userdata = _mapper.Map<UserApplicantModel>(loginDto);
                var createResult = await _logInRepository.CreateUserAsync(userdata);
                var userCreationData = createResult.Data as UserCreationResult;

                if (userCreationData != null)
                {
                    result.ResumeStatus = userCreationData.Status;
                    result.UserId = userCreationData.UserId;
                }

                if (createResult.ReturnStatus == "Seafarer Insert Success")
                {
                    moduleFetch = 1;
                    result.Email = loginDto.Email;
                    result.Role = loginDto.Role;
                    result.LoginType = loginDto.LoginType;
                    moduleFetch = 1;
                    var jwtToken = _tokenService.GenerateJwtToken(result.Email, loginDto.Role); // custom method
                    var refreshToken = _tokenService.GenerateRefreshToken();

                    await _tokenRepository.UpdateRefreshTokenAsync(new RefreshToken
                    {
                        Email_Id = result.Email,
                        Token = refreshToken,
                        TokenExpiryDate = DateTime.UtcNow.AddDays(7), // or from config
                        Role = result.Role,
                        UserId = result.UserId
                    });
                    result.AccessToken = jwtToken;
                    result.RefreshToken = refreshToken;
                }
                else
                {
                    return new ApiResponse<AuthenticateResult>(false, null, "User creation failed.", ErrorCodes.InternalServerError);
                }
            }
            else
            {
                var getUserResult = await _logInRepository.ExistingUserDetails(loginDto.Email);
                var getUser = getUserResult.Data;

                if (getUser == null)
                {
                    return new ApiResponse<AuthenticateResult>(false, null, "User not found", ErrorCodes.NotFound);
                }

                if (loginDto.LoginType.ToLower() == "portal" || loginDto.LoginType.ToLower() == "register")
                {
                    if (!_passwordHasher.VerifyPassword(loginDto.Password, getUser.PasswordHash))
                    {
                        return new ApiResponse<AuthenticateResult>(false, null, "Incorrect password.", ErrorCodes.InvalidPassword);
                    }
                }
                result.ResumeStatus = getUser.ResumeStatus;
                if (getUser.RoleName.ToLower() == "recruiter")
                {
                    result.ResumeStatus = "recruiter";
                }
                result.UserId = getUser.UserId ?? 0;
                result.Email = getUser.Username;
                result.Role = getUser.RoleName;
                if (loginDto.Role.ToLower() != getUser.RoleName.ToLower())
                {
                    return new ApiResponse<AuthenticateResult>(false, null, "Invalid role for this login", ErrorCodes.InvalidCredentials);
                }
                result.LoginType = loginDto.LoginType;

                var refreshToken = getUser.RefreshToken;

                var jwtToken = _tokenService.GenerateJwtToken(result.Email, loginDto.Role); // custom method
                if (getUser.RefreshToken == null)
                {
                    refreshToken = _tokenService.GenerateRefreshToken();
                    await _tokenRepository.UpdateRefreshTokenAsync(new RefreshToken
                    {
                        Email_Id = result.Email,
                        Token = refreshToken,
                        TokenExpiryDate = DateTime.UtcNow.AddDays(7), // or from config
                        Role = result.Role,
                        UserId = result.UserId
                    });
                }
                moduleFetch = 1;
                result.AccessToken = jwtToken;
                result.RefreshToken = refreshToken;

            }
            if (moduleFetch == 1)
            {
                var moduleResult = await _logInRepository.GetModulePrivilegesByRoleAsync(loginDto.Role);

                if (moduleResult.Data == null || moduleResult.Data.Count == 0)
                {
                    return new ApiResponse<AuthenticateResult>(false, result, "No modules assigned to this role", ErrorCodes.NotFound);
                }

                result.RoleModulePrevilleages = _mapper.Map<List<ModulePrevilleages>>(moduleResult.Data);

                return new ApiResponse<AuthenticateResult>(true, result, "Login successful", ErrorCodes.Success);
            }

            return new ApiResponse<AuthenticateResult>(false, null, "Authentication failed", ErrorCodes.InternalServerError);

        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred in AuthenticateUserAsync");
            throw;
        }
    }
}