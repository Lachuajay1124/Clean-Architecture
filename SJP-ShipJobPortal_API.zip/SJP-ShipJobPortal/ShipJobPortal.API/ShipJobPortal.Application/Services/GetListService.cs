﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using ShipJobPortal.Application.DTOs;
using ShipJobPortal.Application.IServices;
using ShipJobPortal.Domain.Constants;
using ShipJobPortal.Domain.Interfaces;
using ShipJobPortal.Application.Common;

namespace ShipJobPortal.Application.Services;

public class GetListService : IGetListService
{
    private readonly IGetListRepository _listRepository;
    private readonly IMapper _mapper;
    private readonly ILogger<GetListService> _logger;
    private readonly IMemoryCache _cache;


    public GetListService(IGetListRepository Listservice, IMemoryCache cache, IMapper mapper, ILogger<GetListService> logger)
    {
        _listRepository = Listservice;
        _mapper = mapper;
        _logger = logger;
        _cache = cache;


    }

    public async Task<ApiResponse<IEnumerable<GetCountryListDto>>> GetAllCountryAsync()
    {
        try
        {
            var dtoList = await _cache.GetOrCreateAsync<IEnumerable<GetCountryListDto>>(
                CacheKeys.Countries,
                async entry =>
                {
                    entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(24);
                    // entry.SlidingExpiration = TimeSpan.FromHours(6); // optional
                    // entry.Priority = CacheItemPriority.High;         // optional

                    var result = await _listRepository.GetAllCountriesAsync();
                    if (result.ReturnStatus == "success" && result.Data?.Any() == true)
                    {
                        return _mapper.Map<IEnumerable<GetCountryListDto>>(result.Data);
                    }

                    // Do not cache empty/failure: set very short TTL or return null
                    entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(1);
                    return null;
                });

            if (dtoList is not null && dtoList.Any())
            {
                return new ApiResponse<IEnumerable<GetCountryListDto>>(
                    success: true,
                    data: dtoList,
                    message: "countries fetched successfully.",
                    errorCode: ErrorCodes.Success
                );
            }

            // if factory returned null (no data)
            return new ApiResponse<IEnumerable<GetCountryListDto>>(
                success: false,
                data: null,
                message: "No countries found.",
                errorCode: ErrorCodes.NotFound
            );
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in GetAllCountryAsync");
            throw;
        }
    }

    public async Task<ApiResponse<IEnumerable<GetStateListDto>>> GetAllStateAsync(int? countryId)
    {
        try
        {
            int cId = countryId ?? 0; // single-line null→0
            var dtoList = await _cache.GetOrCreateAsync<IEnumerable<GetStateListDto>>(
                CacheKeys.States(cId),
                async entry =>
                {
                    entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(24);

                    var result = await _listRepository.GetAllStatesAsync(cId);
                    if (result.ReturnStatus == "success" && result.Data?.Any() == true)
                        return _mapper.Map<IEnumerable<GetStateListDto>>(result.Data);

                    entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(1); // short for empty
                    return Enumerable.Empty<GetStateListDto>();
                });

            if (dtoList.Any())
                return new(true, dtoList, "States fetched successfully.", ErrorCodes.Success);

            return new(false, null, "No states found.", ErrorCodes.NotFound);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in GetAllStateAsync");
            throw;
        }
    }



    public async Task<ApiResponse<IEnumerable<GetCityListDto>>> GetAllCityAsync(int? stateId)
    {
        try
        {
            int sId = stateId ?? 0;
            var dtoList = await _cache.GetOrCreateAsync<IEnumerable<GetCityListDto>>(
                CacheKeys.Cities(sId),
                async entry =>
                {
                    entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(24);

                    var result = await _listRepository.GetAllCitiesAsync(sId);
                    if (result.ReturnStatus == "success" && result.Data?.Any() == true)
                        return _mapper.Map<IEnumerable<GetCityListDto>>(result.Data);

                    entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(1);
                    return Enumerable.Empty<GetCityListDto>();
                });

            if (dtoList.Any())
                return new(true, dtoList, "Cities fetched successfully.", ErrorCodes.Success);

            return new(false, null, "No cities found.", ErrorCodes.NotFound);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in GetAllCityAsync");
            throw;
        }
    }


    public async Task<ApiResponse<IEnumerable<VesselTypeDto>>> GetAllVesselTypeAsync()
    {
        try
        {
            var dtoList = await _cache.GetOrCreateAsync<IEnumerable<VesselTypeDto>>(
                CacheKeys.VesselTypes,
                async entry =>
                {
                    entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(24);

                    var result = await _listRepository.GetAllVesselTypeAsync();
                    if (result.ReturnStatus == "success" && result.Data?.Any() == true)
                        return _mapper.Map<IEnumerable<VesselTypeDto>>(result.Data);

                    entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(1);
                    return Enumerable.Empty<VesselTypeDto>();
                });

            if (dtoList.Any())
                return new(true, dtoList, "Vessel type fetched successfully.", ErrorCodes.Success);

            return new(false, null, "No vessel types found.", ErrorCodes.NotFound);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in GetAllVesselTypeAsync");
            throw;
        }
    }


    public async Task<ApiResponse<IEnumerable<ContractDurationDto>>> GetAllContractDurationAsync()
    {
        try
        {
            var dtoList = await _cache.GetOrCreateAsync<IEnumerable<ContractDurationDto>>(
                CacheKeys.ContractDurations,
                async entry =>
                {
                    entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(24);

                    var result = await _listRepository.GetAllContractDurationAsync();
                    if (result.ReturnStatus == "success" && result.Data?.Any() == true)
                        return _mapper.Map<IEnumerable<ContractDurationDto>>(result.Data);

                    entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(1);
                    return Enumerable.Empty<ContractDurationDto>();
                });

            if (dtoList.Any())
                return new(true, dtoList, "Contract Duration fetched successfully.", ErrorCodes.Success);

            return new(false, null, "No Contract Duration found.", ErrorCodes.NotFound);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in GetAllContractDurationAsync");
            throw;
        }
    }


    public async Task<ApiResponse<IEnumerable<PositionDto>>> GetAllPositionAsync(int? companyId)
    {
        try
        {
            int compId = companyId ?? 0;
            var dtoList = await _cache.GetOrCreateAsync<IEnumerable<PositionDto>>(
                CacheKeys.Positions(compId),
                async entry =>
                {
                    entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(24);

                    var result = await _listRepository.GetAllPositionAsync(compId);
                    if (result.ReturnStatus == "success" && result.Data?.Any() == true)
                        return _mapper.Map<IEnumerable<PositionDto>>(result.Data);

                    entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(1);
                    return Enumerable.Empty<PositionDto>();
                });

            if (dtoList.Any())
                return new(true, dtoList, "position fetched successfully.", ErrorCodes.Success);

            return new(false, null, "No position found.", ErrorCodes.NotFound);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in GetAllPositionAsync");
            throw;
        }
    }


    public async Task<ApiResponse<IEnumerable<MobileCountryCodeDto>>> GetAllMobileCodesAsync()
    {
        try
        {
            var dtoList = await _cache.GetOrCreateAsync<IEnumerable<MobileCountryCodeDto>>(
                CacheKeys.MobileCountryCodes,
                async entry =>
                {
                    entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(24);

                    var result = await _listRepository.GetAllMobileCountriesAsync();
                    if (result.ReturnStatus == "success" && result.Data?.Any() == true)
                        return _mapper.Map<IEnumerable<MobileCountryCodeDto>>(result.Data);

                    entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(1);
                    return Enumerable.Empty<MobileCountryCodeDto>();
                });

            if (dtoList.Any())
                return new(true, dtoList, "mobile country codes fetched successfully.", ErrorCodes.Success);

            return new(false, null, "No countries found.", ErrorCodes.NotFound);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in GetAllMobileCodesAsync");
            throw;
        }
    }

}
