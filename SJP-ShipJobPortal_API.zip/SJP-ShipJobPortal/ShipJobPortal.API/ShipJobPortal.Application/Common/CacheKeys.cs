﻿namespace ShipJobPortal.Application.Common
{
    public static class CacheKeys
    {
        public const string Countries = "country_list_cached";
        public static string States(int countryId) => $"states_{countryId}";
        public static string Cities(int stateId) => $"cities_{stateId}";
        public const string VesselTypes = "vessel_types";
        public const string ContractDurations = "contract_durations";
        public static string Positions(int companyId) => $"positions_{companyId}";
        public const string MobileCountryCodes = "mobile_country_codes";
        public const string DocumentlistKeys = "document_list";
        public const string DocumentSection = "document_sections";
        public const string DocumentCategory = "document_Categories";
        public const string DocumentType = "document_Types";
        public const string Industry = "industries_Sjp";
    }
}
