﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShipJobPortal.Application.Common
{
    public static class CacheKeys
    {
        public const string Countries = "country_list_cached";
        public static string States(int countryId) => $"states_{countryId}";
        public static string Cities(int stateId) => $"cities_{stateId}";
        public const string VesselTypes = "vessel_types";
        public const string ContractDurations = "contract_durations";
        public static string Positions(int companyId) => $"positions_{companyId}";
        public const string MobileCountryCodes = "mobile_country_codes";
    }
}
