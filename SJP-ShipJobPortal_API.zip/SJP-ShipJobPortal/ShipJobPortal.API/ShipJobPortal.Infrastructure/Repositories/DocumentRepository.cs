﻿using System.Data;
using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ShipJobPortal.Domain.Entities;
using ShipJobPortal.Domain.Interfaces;
using ShipJobPortal.Infrastructure.DataAccessLayer;

namespace ShipJobPortal.Infrastructure.Repositories;

public class DocumentRepository:IDocumentRepository
{
    private readonly IDataAccess_Improved _dbHelper;
    private readonly IConfiguration _configuration;
    private readonly ILogger<DocumentRepository> _logger;
    private readonly string _dbKey;

    public DocumentRepository(IConfiguration configuration, IDataAccess_Improved dbHelper, ILogger<DocumentRepository> logger)
    {
        _configuration = configuration;
        _dbHelper = dbHelper;
        _logger = logger;

        _dbKey = string.IsNullOrWhiteSpace(_configuration["ConnectionStrings:DefaultConnection"])
            ? throw new Exception("DefaultConnection is missing in ConnectionStrings.")
            : "DefaultConnection";
    }



    public async Task<ReturnResult<string>> fn_InsertLookupItem(LookupItemModel model)
    {
        var insertVal = _configuration["StoredProcedureModes:Insert"] ?? "INSERT";
        var updateVal = _configuration["StoredProcedureModes:Update"] ?? "UPDATE";
        var mode = (model.itemId > 0) ? updateVal : insertVal;

        // 2) Ensure sortOrder is INT
        int? sortOrder = null;
        if (model.sortOrder is int so) sortOrder = so;
        else if (int.TryParse(Convert.ToString(model.sortOrder), out var so2)) sortOrder = so2;
        else return new ReturnResult<string> { ReturnStatus = "failed", ErrorCode = "ERR400_SORTORDER_NOT_INT" };

        var parameters = new DynamicParameters();
        parameters.Add("@Mode", mode, DbType.String, ParameterDirection.Input, size: 20);
        parameters.Add("@itemId", model.itemId, DbType.Int32);
        parameters.Add("@itemCode", model.itemCode, DbType.String, size: 20);
        parameters.Add("@itemHardCode", model.itemHardCode, DbType.String, size: 20);
        parameters.Add("@itemName", model.itemName, DbType.String, size: 200);
        parameters.Add("@recordType", model.recordType, DbType.String, size: 10);
        parameters.Add("@sortOrder", sortOrder, DbType.Int32);

        parameters.Add("@ReturnStatus", dbType: DbType.String, size: 50, direction: ParameterDirection.Output);
        parameters.Add("@ErrorCode", dbType: DbType.String, size: 50, direction: ParameterDirection.Output);

        await _dbHelper.ExecuteScalarAsync("dbo.usp_saveupdatedelete_lookup_item", parameters, _dbKey);

        var status = parameters.Get<string>("@ReturnStatus");
        var error = parameters.Get<string>("@ErrorCode");

        return new ReturnResult<string>
        {
            ReturnStatus = status,
            ErrorCode = error,
            Data = null
        };
    }

    public async Task<ReturnResult<string>> fn_InsertUpdateDocument(DocumentSaveModel model)
    {
        var insertVal = _configuration["StoredProcedureModes:Insert"] ?? "INSERT";
        var updateVal = _configuration["StoredProcedureModes:Update"] ?? "UPDATE";
        var mode = (model.Id > 0) ? updateVal : insertVal;

        int? sortOrder = null;
        if (model.SortOrder is int so) sortOrder = so;
        else if (int.TryParse(Convert.ToString(model.SortOrder), out var so2)) sortOrder = so2;
        else return new ReturnResult<string> { ReturnStatus = "failed", ErrorCode = "ERR400_SORTORDER_NOT_INT" };

        var parameters = new DynamicParameters();
        parameters.Add("@mode", mode, DbType.String, ParameterDirection.Input, size: 20);
        parameters.Add("@docId", model.Id, DbType.Int32);
        parameters.Add("@docCode", model.Code, DbType.String, size: 20);
        parameters.Add("@docName", model.Name, DbType.String, size: 20);
        parameters.Add("@companyId", model.CompanyId, DbType.Int32);
        parameters.Add("@sectionId", model.SectionId, DbType.Int32);
        parameters.Add("@typeId", model.TypeId, DbType.Int32);
        parameters.Add("@categoryId", model.CategoryId, DbType.Int32);
        parameters.Add("@sortOrder", model.SortOrder, DbType.Int32);
        parameters.Add("@industryId", model.IndustryId, DbType.Int32);
        parameters.Add("@havingExpiry", model.HaveExpiry, DbType.Int32);

        parameters.Add("@ReturnStatus", dbType: DbType.String, size: 50, direction: ParameterDirection.Output);
        parameters.Add("@ErrorCode", dbType: DbType.String, size: 50, direction: ParameterDirection.Output);

        await _dbHelper.ExecuteScalarAsync("usp_saveupdatedelete_document", parameters, _dbKey);

        var status = parameters.Get<string>("@ReturnStatus");
        var error = parameters.Get<string>("@ErrorCode");

        return new ReturnResult<string>
        {
            ReturnStatus = status,
            ErrorCode = error,
            Data = null
        };
    }

}
