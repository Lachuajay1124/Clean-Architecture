﻿using System.Data;
using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ShipJobPortal.Application.DTOs;
using ShipJobPortal.Domain.Constants;
using ShipJobPortal.Domain.Entities;
using ShipJobPortal.Domain.Interfaces;
using ShipJobPortal.Infrastructure.DataAccessLayer;

namespace ShipJobPortal.Infrastructure.Repositories;

public class JobApplyRepository : IJobApplyRepository
{
    private readonly IDataAccess_Improved _dbHelper;
    private readonly IConfiguration _configuration;
    private readonly ILogger<JobPostRepository> _logger;
    private readonly string _dbKey;

    public JobApplyRepository(IConfiguration configuration, IDataAccess_Improved dbHelper, ILogger<JobPostRepository> logger)
    {
        _configuration = configuration;
        _dbHelper = dbHelper;
        _logger = logger;

        _dbKey = string.IsNullOrWhiteSpace(_configuration["ConnectionStrings:DefaultConnection"])
            ? throw new Exception("DefaultConnection is missing in ConnectionStrings.")
            : "DefaultConnection";
    }


    public async Task<ReturnResult<AppliedCandidatesListModel>> GetAppliedCandidatesAsync(GetAppliedCandidateRequestModel requestModel)
    {
        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@JobId", requestModel.jobId);
            parameters.Add("@UserId", 0);
            parameters.Add("@Role", "recruiter");
            parameters.Add("@PageNumber", requestModel.pageNumber);
            parameters.Add("@PageSize", requestModel.pageSize);
            parameters.Add("@positionId", requestModel.positionId);
            parameters.Add("@vesselTypeId", requestModel.vesselTypeId);
            parameters.Add("@locationId", requestModel.locationId);
            parameters.Add("@durationId", requestModel.durationId);
            parameters.Add("@searchKey", requestModel.searchKey);

            var dbResult = await _dbHelper.QueryMultipleAsync("usp_get_jobApplied_history", parameters, _dbKey);

            if (dbResult == null || dbResult.Data.Count < 2)
            {
                return new ReturnResult<AppliedCandidatesListModel>("error", ErrorCodes.InternalServerError, null);
            }

            // First result set: Candidate list
            var candidateList = JsonConvert.DeserializeObject<List<JobAppliedModel>>(
                JsonConvert.SerializeObject(dbResult.Data[0])
            );

            // Second result set: Pagination
            var paginationRaw = dbResult.Data[1].FirstOrDefault();
            var pagination = paginationRaw != null
                ? JsonConvert.DeserializeObject<PaginationModel>(JsonConvert.SerializeObject(paginationRaw))
                : new PaginationModel();

            var resultModel = new AppliedCandidatesListModel
            {
                CandidatesList = candidateList,
                pagination = pagination
            };

            return new ReturnResult<AppliedCandidatesListModel>(
                dbResult.ReturnStatus ?? "success",
                dbResult.ErrorCode ?? ErrorCodes.Success,
                resultModel
            );
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in GetAppliedCandidatesAsync");
            throw;
        }
    }


    public async Task<ReturnResult<string>> ApplyJobAsync(JobApplyPostModel model)
    {
        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@UserId", model.UserId);
            parameters.Add("@JobId", model.JobId);
            parameters.Add("@CoverLetter", model.CoverLetter);
            parameters.Add("@ResumeFile", model.ResumeFile);
            parameters.Add("@Notes", model.Notes);

            parameters.Add("@ReturnStatus", dbType: DbType.String, direction: ParameterDirection.Output, size: 50);
            parameters.Add("@ErrorCode", dbType: DbType.String, direction: ParameterDirection.Output, size: 50);

            var dbResult = await _dbHelper.ExecuteScalarAsync("usp_insert_job_application", parameters, _dbKey);

            var result = new ReturnResult<string>
            {
                ReturnStatus = dbResult.ReturnStatus,
                ErrorCode = dbResult.ErrorCode,
                Data = null
            };

            return result;
        }
        catch (Exception ex)
        {
            throw;
        }
    }


    public async Task<ReturnResult<AppliedJobsListModel>> GetAppliedJobsAsync(GetAppliedJobsForCandidateModel requestBody)
    {
        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@JobId", 0);
            parameters.Add("@UserId", requestBody.UserId);
            parameters.Add("@Role", "Seafarer");
            parameters.Add("@PageNumber", requestBody.pageNumber);
            parameters.Add("@PageSize", requestBody.pageSize);
            parameters.Add("@positionId", requestBody.positionId);
            parameters.Add("@vesselTypeId", requestBody.vesselTypeId);
            parameters.Add("@locationId", requestBody.locationId);
            parameters.Add("@durationId", requestBody.durationId);
            parameters.Add("@searchKey", requestBody.searchKey);

            var dbResult = await _dbHelper.QueryMultipleAsync("usp_get_jobApplied_history", parameters, _dbKey);

            if (dbResult == null || dbResult.Data.Count < 2)
            {
                return new ReturnResult<AppliedJobsListModel>("error", ErrorCodes.InternalServerError, null);
            }

            // First result set: Candidate list
            var JobList = JsonConvert.DeserializeObject<List<AppliedJobs>>(
                JsonConvert.SerializeObject(dbResult.Data[0])
            );

            // Second result set: Pagination
            var paginationRaw = dbResult.Data[1].FirstOrDefault();
            var pagination = paginationRaw != null
                ? JsonConvert.DeserializeObject<PaginationModel>(JsonConvert.SerializeObject(paginationRaw))
                : new PaginationModel();

            var resultModel = new AppliedJobsListModel
            {
                JobsList = JobList,
                pagination = pagination
            };

            return new ReturnResult<AppliedJobsListModel>(
                dbResult.ReturnStatus ?? "success",
                dbResult.ErrorCode ?? ErrorCodes.Success,
                resultModel
            );
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in GetAppliedCandidatesAsync");
            throw;
        }
    }


    public async Task<ReturnResult<string>> WishlistJobAsync(JobWishlistModel model)
    {
        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@UserId", model.UserId);
            parameters.Add("@JobId", model.JobId);

            var dbResult = await _dbHelper.ExecuteScalarAsync("usp_save_candidate_job_wishlist", parameters, _dbKey);

            var result = new ReturnResult<string>
            {
                ReturnStatus = dbResult.ReturnStatus,
                ErrorCode = dbResult.ErrorCode,
                Data = null
            };

            return result;
        }
        catch (Exception ex)
        {
            throw;
        }
    }


    public async Task<ReturnResult<SavedJobsListModel>> GetSavedJobsAsync(GetSavedJobsForCandidateModel requestBody)
    {
        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@UserId", requestBody.UserId);
            parameters.Add("@PageNumber", requestBody.pageNumber);
            parameters.Add("@PageSize", requestBody.pageSize);
            parameters.Add("@positionId", requestBody.positionId);
            parameters.Add("@vesselTypeId", requestBody.vesselTypeId);
            parameters.Add("@locationId", requestBody.locationId);
            parameters.Add("@durationId", requestBody.durationId);
            parameters.Add("@durationId", requestBody.monthValue);
            parameters.Add("@searchKey", requestBody.searchKey);


            var dbResult = await _dbHelper.QueryMultipleAsync("usp_get_user_saved_jobs", parameters, _dbKey);

            if (dbResult == null || dbResult.Data.Count < 2)
            {
                return new ReturnResult<SavedJobsListModel>("error", ErrorCodes.InternalServerError, null);
            }

            // First result set: Candidate list
            var JobList = JsonConvert.DeserializeObject<List<SavedJobsModel>>(
                JsonConvert.SerializeObject(dbResult.Data[0])
            );

            // Second result set: Pagination
            var paginationRaw = dbResult.Data[1].FirstOrDefault();
            var pagination = paginationRaw != null
                ? JsonConvert.DeserializeObject<PaginationModel>(JsonConvert.SerializeObject(paginationRaw))
                : new PaginationModel();

            var resultModel = new SavedJobsListModel
            {
                JobsList = JobList,
                pagination = pagination
            };

            return new ReturnResult<SavedJobsListModel>(
                dbResult.ReturnStatus ?? "success",
                dbResult.ErrorCode ?? ErrorCodes.Success,
                resultModel
            );
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in GetSavedJobsAsync");
            throw;
        }
    }

    public async Task<ReturnResult<string>> JobActionOnCandidateAsync(JobActionOnCandidateModel model)
    {
        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@candidateId", model.candidateId);
            parameters.Add("@jobAction", model.jobAction);
            parameters.Add("@applicationId", model.applicationId);

            var dbResult = await _dbHelper.ExecuteScalarAsync("usp_update_job_application_status", parameters, _dbKey);

            var result = new ReturnResult<string>
            {
                ReturnStatus = dbResult.ReturnStatus,
                ErrorCode = dbResult.ErrorCode,
                Data = null
            };

            return result;
        }
        catch (Exception ex)
        {
            throw;
        }
    }


}

