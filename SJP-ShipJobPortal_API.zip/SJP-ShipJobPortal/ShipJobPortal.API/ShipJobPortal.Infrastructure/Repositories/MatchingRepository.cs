﻿using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ShipJobPortal.Application.DTOs;
using ShipJobPortal.Domain.Constants;
using ShipJobPortal.Domain.Entities;
using ShipJobPortal.Domain.Interfaces;
using ShipJobPortal.Infrastructure.DataAccessLayer;

namespace ShipJobPortal.Infrastructure.Repositories;

public class MatchingRepository : IMatchingRepository
{
    private readonly IDataAccess_Improved _dbHelper;
    private readonly IConfiguration _configuration;
    private readonly IEncryptionService _encryptionService;
    private readonly ILogger<MatchingRepository> _logger;
    private readonly string _dbKey;

    public MatchingRepository(IConfiguration configuration, IDataAccess_Improved dbHelper, IEncryptionService encryptionService, ILogger<MatchingRepository> logger)
    {
        _dbHelper = dbHelper;
        _encryptionService = encryptionService;
        _logger = logger;
        _configuration = configuration;

        _dbKey = string.IsNullOrWhiteSpace(_configuration["ConnectionStrings:DefaultConnection"])
            ? throw new Exception("DefaultConnection is missing in ConnectionStrings.")
        : "DefaultConnection";
    }

    public async Task<ReturnResult<MatchingCandidateViewModel>> GetMatchingCandidatesAsync(GetMatchingCandidateForJobModel requestBody)
    {
        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@jobId", requestBody.jobId);
            parameters.Add("@PageNumber", requestBody.pageNumber);
            parameters.Add("@PageSize", requestBody.pageSize);
            parameters.Add("@positionId", requestBody.positionId);
            parameters.Add("@vesselTypeId", requestBody.vesselTypeId);
            parameters.Add("@locationId", requestBody.locationId);
            parameters.Add("@durationId", requestBody.durationId);


            var dbResult = await _dbHelper.QueryMultipleAsync("matchdemo", parameters, _dbKey);

            // First result set: Candidate list
            var JobList = JsonConvert.DeserializeObject<List<MatchingCandidateModel>>(
                JsonConvert.SerializeObject(dbResult.Data[0])
            );

            // Second result set: Pagination
            var resultModel = new MatchingCandidateViewModel
            {
                candidates = JobList,
                pagination = new PaginationModel()//pagination
            };

            return new ReturnResult<MatchingCandidateViewModel>(
                dbResult.ReturnStatus ?? "success",
                dbResult.ErrorCode ?? ErrorCodes.Success,
                resultModel
            );
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in GetMatchingJobAsync");
            throw;
        }
    }

}

