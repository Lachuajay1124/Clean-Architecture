﻿using System.Data;
using Dapper;
using ShipJobPortal.Domain.Entities;
using ShipJobPortal.Domain.Interfaces;
using ShipJobPortal.Infrastructure.DataAccessLayer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace ShipJobPortal.Infrastructure.Repositories;

public class LoginRepository : ILoginRepository
{
    private readonly IDataAccess_Improved _dbHelper;
    private readonly IPasswordHasher _passwordHasher;
    private readonly IConfiguration _configuration;
    private readonly ILogger<LoginRepository> _logger;
    private readonly string _dbKey;


    public LoginRepository(
        IConfiguration configuration,
        IPasswordHasher passwordHasher,
        IDataAccess_Improved dbHelper,
        ILogger<LoginRepository> logger)
    {
        _configuration = configuration;
        _passwordHasher = passwordHasher;
        _dbHelper = dbHelper;
        _logger = logger;

        _dbKey = string.IsNullOrWhiteSpace(_configuration["ConnectionStrings:DefaultConnection"])
            ? throw new Exception("DefaultConnection is missing in ConnectionStrings.")
            : "DefaultConnection";
    }

    public async Task<ReturnResult<ResetPasswordDataModel>> GetUserRoleAsync(string username)
    {
        var result = new ReturnResult<ResetPasswordDataModel>();

        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@Username", username);

            var dbResult = await _dbHelper.QueryAsyncTrans<ResetPasswordDataModel>("usp_get_user_details", parameters, _dbKey);

            if (result.ReturnStatus == "success" && result.ErrorCode == "ERR200")
            {
                result.ReturnStatus = parameters.Get<string>("@ReturnStatus");
                result.ErrorCode = parameters.Get<string>("@ErrorCode");
                if (dbResult.Data != null && dbResult.Data.Any())
                {
                    result.Data = dbResult.Data.First();
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in GetUserRoleAsync");
            throw;
        }
        return result;
    }

    public async Task<ReturnResult> CreateUserAsync(UserApplicantModel user)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(user.Email))
            {
                throw new ArgumentException("Email is required.");
            }

            var parameters = new DynamicParameters();
            parameters.Add("@role", user.Role);
            parameters.Add("@loginType", user.loginType);
            parameters.Add("@FirstName", user.FirstName);
            parameters.Add("@MiddleName", user.MiddleName);
            parameters.Add("@Surname", user.Surname);
            parameters.Add("@Title", user.Title);
            parameters.Add("@Designation", user.Designation);
            parameters.Add("@CompanyId", user.CompanyId);
            parameters.Add("@CompanyDetails", user.CompanyDetails);
            parameters.Add("@Email", user.Email);
            parameters.Add("@ContactNumber", user.ContactNumber);
            parameters.Add("@CountryCode", user.CountryCode);
            parameters.Add("@Nationality", user.Nationality);
            parameters.Add("@Address", user.Address);
            parameters.Add("@CityID", user.CityID);
            parameters.Add("@StateID", user.StateID);
            parameters.Add("@CountryID", user.CountryID);
            parameters.Add("@PostalCode", user.PostalCode);
            parameters.Add("@DateOfBirth", user.DateOfBirth);
            parameters.Add("@PasswordHash", user.Password);
            parameters.Add("@seaManBook", user.SeamanBookNumber);
            parameters.Add("@userIdoutput", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@status", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

            var result = await _dbHelper.ExecuteScalarAsync("usp_create_user_account", parameters, _dbKey);

            var status = parameters.Get<string>("@status");
            var userId = parameters.Get<int>("@userIdoutput");

            return new ReturnResult
            {
                ReturnStatus = parameters.Get<string>("@ReturnStatus"),
                ErrorCode = parameters.Get<string>("@ErrorCode"),
                Data = new UserCreationResult
                {
                    Status = status,
                    UserId = userId
                }
            };


        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred in CreateUserAsync");
            throw;
        }
    }

    public async Task<ReturnResult<string>> ResetPasswordAsync(string email, string oldPassword, string newHashedPassword)
    {
        var result = new ReturnResult<string>();
        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@Email_Id", email);
            parameters.Add("@OldPassword", oldPassword);
            parameters.Add("@NewPassword", newHashedPassword);

            await _dbHelper.ExecuteScalarAsync("usp_reset_user_password", parameters, _dbKey);

            result.ReturnStatus = parameters.Get<string>("@ReturnStatus");
            result.ErrorCode = parameters.Get<string>("@ErrorCode");
            result.Data = result.ReturnStatus;

            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in ResetPasswordAsync");
            throw;
        }
    }

    //paralell
    public async Task<ReturnResult> UserExistsAsync(string email)
    {
        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@Email", email, DbType.String);
            parameters.Add("@Exists", dbType: DbType.Boolean, direction: ParameterDirection.Output);
            parameters.Add("@ReturnStatus", dbType: DbType.String, size: 50, direction: ParameterDirection.Output);
            parameters.Add("@ErrorCode", dbType: DbType.String, size: 100, direction: ParameterDirection.Output);

            var result = await _dbHelper.ExecuteScalarAsync("usp_CheckUserExistsByEmailRole", parameters, _dbKey);

            string returnStatus = result.ReturnStatus;
            string errorCode = result.ErrorCode;

            bool? exists = returnStatus == "User Exist"
                ? parameters.Get<bool>("@Exists")
                : null;

            return new ReturnResult
            {
                ReturnStatus = returnStatus,
                ErrorCode = errorCode,
                Data = exists
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred in UserExistsAsync");
            throw;
        }
    }

    public async Task<ReturnResult> SeamanBooknumberExistsAsync(string seamanbooknumber)
    {
        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@SeamanBookNumber", seamanbooknumber, DbType.String);
            parameters.Add("@Exists", dbType: DbType.Boolean, direction: ParameterDirection.Output);
            parameters.Add("@ReturnStatus", dbType: DbType.String, size: 50, direction: ParameterDirection.Output);
            parameters.Add("@ErrorCode", dbType: DbType.String, size: 100, direction: ParameterDirection.Output);

            var result = await _dbHelper.ExecuteScalarAsync("usp_CheckUserExistsSeamanBookNumber", parameters, _dbKey);

            string returnStatus = result.ReturnStatus;
            string errorCode = result.ErrorCode;

            bool? exists = returnStatus == "User Exist"
                ? parameters.Get<bool>("@Exists")
                : null;

            return new ReturnResult
            {
                ReturnStatus = returnStatus,
                ErrorCode = errorCode,
                Data = exists
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred in UserExistsAsync");
            throw;
        }
    }

    public async Task<ReturnResult<ExistingUserData>> ExistingUserDetails(string email)
    {
        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@Email", email, DbType.String);

            var result = await _dbHelper.QueryAsyncTrans<ExistingUserData>("usp_get_user_login_details_by_email", parameters, _dbKey);
            var firstOrDefault = result.Data?.FirstOrDefault();

            return new ReturnResult<ExistingUserData>
            {
                ReturnStatus = result.ReturnStatus,
                ErrorCode = result.ErrorCode,
                Data = firstOrDefault
            };

        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred in ExistingUserDetails");
            throw;
        }
    }

    public async Task<ReturnResult<List<ModulePrevilleagesModel>>> GetModulePrivilegesByRoleAsync(string userRole)
    {
        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@UserRole", userRole, DbType.String);
            parameters.Add("@ReturnStatus", dbType: DbType.String, direction: ParameterDirection.Output, size: 50);
            parameters.Add("@ErrorCode", dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

            var result = await _dbHelper.QueryAsyncTrans<ModulePrevilleagesModel>(
                "usp_get_modules_by_role", parameters, _dbKey);

            return new ReturnResult<List<ModulePrevilleagesModel>>
            {
                ReturnStatus = parameters.Get<string>("@ReturnStatus"),
                ErrorCode = parameters.Get<string>("@ErrorCode"),
                Data = result.Data
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in GetModulePrivilegesByRoleAsync");

            throw;
        }
    }

}

