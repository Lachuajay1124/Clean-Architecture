﻿using System.Data;
using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ShipJobPortal.Domain.Constants;
using ShipJobPortal.Domain.Entities;
using ShipJobPortal.Domain.Interfaces;
using ShipJobPortal.Infrastructure.DataAccessLayer;
using ShipJobPortal.Infrastructure.DataHelpers;

namespace ShipJobPortal.Infrastructure.Repositories;

public class ProfileRepository : IProfileRepository
{
    private readonly IDataAccess_Improved _dbHelper;
    private readonly IConfiguration _configuration;
    private readonly IEncryptionService _encryptionService;
    private readonly ILogger<ProfileRepository> _logger;
    private readonly string _dbKey;

    public ProfileRepository(IConfiguration configuration, IDataAccess_Improved dbHelper, IEncryptionService encryptionService, ILogger<ProfileRepository> logger)
    {
        _dbHelper = dbHelper;
        _encryptionService = encryptionService;
        _logger = logger;
        _configuration = configuration;

        _dbKey = string.IsNullOrWhiteSpace(_configuration["ConnectionStrings:DefaultConnection"])
            ? throw new Exception("DefaultConnection is missing in ConnectionStrings.")
            : "DefaultConnection";
    }


    public async Task<ReturnResult> CreateUserProfileAsync(UserProfileModel userProfile)
    {
        try
        {
            var applicant = userProfile.applicant ?? new UserApplicantPostModel();
            DynamicParameters parameters = new DynamicParameters();

            parameters.Add("@UserId", userProfile.userId);
            parameters.Add("@Mode", _configuration["StoredProcedureModes:Insert"]);

            parameters.Add("@Title", applicant.Title);
            parameters.Add("@FirstName", applicant.Firstname);
            parameters.Add("@MiddleName", applicant.Middlename);
            parameters.Add("@Surname", applicant.Surname);
            parameters.Add("@DateOfBirth", Convert.ToDateTime(applicant.Dateofbirth));
            parameters.Add("@Address", applicant.Address);
            parameters.Add("@City", applicant.City);
            parameters.Add("@State", applicant.State);
            parameters.Add("@PostalCode", applicant.Postalcode);
            parameters.Add("@Country", applicant.Country);
            parameters.Add("@CountryCode", applicant.Countrycode);
            parameters.Add("@SecondaryCountryCode", applicant.Secondarycountrycode);
            parameters.Add("@SecondaryNumber", applicant.Secondarynumber);
            parameters.Add("@MobileNumber", applicant.Contactnumber);
            parameters.Add("@WhatsappCountryCode", applicant.Whatsappcountrycode);
            parameters.Add("@WhatsappNumber", applicant.WhatsAppnumber);
            parameters.Add("@SkypeID", applicant.Skypeid);
            parameters.Add("@INDOSnumber", applicant.Indosnumber);
            parameters.Add("@SID", applicant.Sid);
            parameters.Add("@SeamanBookNumber", applicant.Seamanbooknumber);
            parameters.Add("@EducationQualifications", applicant.Educationqualifications);
            parameters.Add("@PersonalStatement", applicant.Personalstatement);
            parameters.Add("@PositionApplied", applicant.Positionapplied);
            parameters.Add("@SalaryExpected", applicant.salaryexpected);
            parameters.Add("@Nationality", applicant.Nationality);
            parameters.Add("@Designation", applicant.Designation);
            parameters.Add("@DateOfAvailability", Convert.ToDateTime(applicant.Dateofavailability));
            parameters.Add("@CompanyId", applicant.Companyid);
            parameters.Add("@CompanyDetails", applicant.Companydetails);
            parameters.Add("@CityID", applicant.Cityid);
            parameters.Add("@StateID", applicant.Stateid);
            parameters.Add("@CountryID", applicant.Countryid);

            var tvpDocs = TvpHelper.ToDocumentsTable(userProfile.Documents);
            parameters.Add("@Documents", tvpDocs.AsTableValuedParameter("DocumentsTVP"));

            var tvpExps = TvpHelper.ToExperienceTable(userProfile.Sea_experience);
            parameters.Add("@Experiences", tvpExps.AsTableValuedParameter("SeaExperienceTVP"));

            parameters.Add("@ReturnStatus", dbType: DbType.String, direction: ParameterDirection.Output, size: 20);
            parameters.Add("@ErrorCode", dbType: DbType.String, direction: ParameterDirection.Output, size: 20);

            var result = await _dbHelper.QueryAsyncTrans<object>("Insert_ProfileDetails", parameters, _dbKey);

            return new ReturnResult
            {
                ReturnStatus = parameters.Get<string>("@ReturnStatus"),
                ErrorCode = parameters.Get<string>("@ErrorCode")
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred in CreateUserProfileAsync");
            throw;
        }
    }

    public async Task<ReturnResult> AddUserFilesAsync(UserFilesModel model)
    {

        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@UserId", model.Userid);
            parameters.Add("@ResumeFile", model.ResumeFile, DbType.Binary);
            parameters.Add("@ImageFile", model.ImageFile, DbType.Binary);
            parameters.Add("@ImageUrl", model.ImageUrl, DbType.String, size: 500);

            parameters.Add("@ReturnStatus", dbType: DbType.String, size: 50, direction: ParameterDirection.Output);
            parameters.Add("@ErrorCode", dbType: DbType.String, size: 50, direction: ParameterDirection.Output);

            var result = await _dbHelper.ExecuteScalarAsync("usp_update_user_files", parameters, _dbKey);

            return new ReturnResult
            {
                ReturnStatus = parameters.Get<string>("@ReturnStatus"),
                ErrorCode = parameters.Get<string>("@ErrorCode")
            };
        }
        catch (Exception ex)
        {
            throw;
        }
    }


    public async Task<ReturnResult<UserProfileViewModel>> GetSeafarerProfileAsync(int userId)
    {
        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@UserId", userId);

            var dbResult = await _dbHelper.QueryMultipleAsync("usp_get_seafarer_Profile", parameters, _dbKey);

            if (dbResult == null || dbResult.Data.Count < 3)
            {
                return new ReturnResult<UserProfileViewModel>("error", ErrorCodes.InternalServerError, null);
            }

            // First result set: User basic info
            var userRaw = dbResult.Data[0].FirstOrDefault();
            var userProfile = userRaw != null
                ? JsonConvert.DeserializeObject<UserProfileViewModel>(JsonConvert.SerializeObject(userRaw))
                : new UserProfileViewModel();

            // Second result set: Sea experience list
            var experiences = JsonConvert.DeserializeObject<List<SeaExperianceViewPatchModel>>(
                JsonConvert.SerializeObject(dbResult.Data[1])
            );

            // Third result set: Certificates list
            var certificates = JsonConvert.DeserializeObject<List<CertificatesViewPatchModel>>(
                JsonConvert.SerializeObject(dbResult.Data[2])
            );

            userProfile.Experiances = experiences;
            userProfile.Certificates = certificates;

            return new ReturnResult<UserProfileViewModel>(
                dbResult.ReturnStatus ?? "success",
                dbResult.ErrorCode ?? ErrorCodes.Success,
                userProfile
            );
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in GetSeafarerProfileAsync");
            throw;
        }
    }

    public async Task<ReturnResult<string>> ReferFriendAsync(ReferAFriendModel model)
    {
        var result = new ReturnResult<string>();

        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@UserId", model.UserId);
            parameters.Add("@FriendEmail", model.FriendEmail);
            parameters.Add("@ReturnStatus", dbType: DbType.String, size: 50, direction: ParameterDirection.Output);
            parameters.Add("@ErrorCode", dbType: DbType.String, size: 50, direction: ParameterDirection.Output);

            await _dbHelper.ExecuteScalarAsync("usp_insert_refer_a_friend", parameters, _dbKey);

            result.ReturnStatus = parameters.Get<string>("@ReturnStatus");
            result.ErrorCode = parameters.Get<string>("@ErrorCode");
            result.Data = result.ReturnStatus;

            return result;
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    public async Task<ReturnResult<CompanyViewModel>> fn_GetcompanyProfileAsync(int companyId)
    {
        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@CompanyId", companyId);
            parameters.Add("@ReturnStatus", dbType: DbType.String, size: 50, direction: ParameterDirection.Output);
            parameters.Add("@ErrorCode", dbType: DbType.String, size: 100, direction: ParameterDirection.Output);

            var result = await _dbHelper.QueryAsyncTrans<CompanyViewModel>("usp_Get_CompanyProfileById", parameters, _dbKey);

            return new ReturnResult<CompanyViewModel>
            {
                ReturnStatus = parameters.Get<string>("@ReturnStatus"),
                ErrorCode = parameters.Get<string>("@ErrorCode"),
                Data = result.Data?.FirstOrDefault()
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in fn_GetcompanyProfileAsync");
            throw;
        }
    }

    public async Task<ReturnResult> UserVideoResume(VideoResumeFilesModel model)
    {

        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@UserId", model.Userid);
            parameters.Add("@ResumeFile", model.VideoResumeFile, DbType.Binary);

            parameters.Add("@ReturnStatus", dbType: DbType.String, size: 50, direction: ParameterDirection.Output);
            parameters.Add("@ErrorCode", dbType: DbType.String, size: 50, direction: ParameterDirection.Output);

            var result = await _dbHelper.ExecuteScalarAsync("usp_update_user_video_resume", parameters, _dbKey);

            return new ReturnResult
            {
                ReturnStatus = parameters.Get<string>("@ReturnStatus"),
                ErrorCode = parameters.Get<string>("@ErrorCode")
            };
        }
        catch (Exception ex)
        {
            throw;
        }
    }


    public async Task<ReturnResult> UpdateSeaExperiance(List<SeaExperianceViewPatchModel> experiances)
    {
        try
        {
            if (experiances == null || experiances.Count == 0)
            {
                return new ReturnResult
                {
                    ReturnStatus = "error",
                    ErrorCode = "ERR_NO_ROWS"
                };
            }

            var tvp = TvpHelper.ToPreviousSeaExperienceTvp(experiances);

            var p = new DynamicParameters();
            p.Add("@Rows", tvp.AsTableValuedParameter("dbo.PreviousSeaExperiencePatchTVP"));

            await _dbHelper.ExecuteScalarAsync("usp_Update_Previous_Sea_Experience", p, _dbKey);

            return new ReturnResult
            {
                ReturnStatus = p.Get<string>("@ReturnStatus"),
                ErrorCode = p.Get<string>("@ErrorCode")
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error occurred while upserting previous sea experience records via TVP");
            throw;
        }
    }

    public async Task<ReturnResult> UpdateCertificatesAsync(List<CertificatesViewPatchModel> certificates)
    {
        try
        {
            var tvp = TvpHelper.ToCertificatesTvp(certificates);

            var parameters = new DynamicParameters();

            parameters.Add("@Updates", tvp.AsTableValuedParameter("dbo.DocumentCertificationPatchTVP"));

            await _dbHelper.ExecuteScalarAsync("usp_update_document_certification", parameters, _dbKey);

            return new ReturnResult
            {
                ReturnStatus = parameters.Get<string>("@ReturnStatus"),
                ErrorCode = parameters.Get<string>("@ErrorCode")
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error occurred while updating certificate records");
            throw;
        }
    }




    public async Task<ReturnResult<VideoResumeFilesModel>> GetVideoResumeAsync(int userId)
    {
        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@UserId", userId);

            var dbResult = await _dbHelper.QueryAsyncTrans<VideoResumeFilesModel>(
                "usp_get_user_video_resume", parameters, _dbKey);

            var data = dbResult.Data?.FirstOrDefault();

            var status = dbResult.ReturnStatus ?? (data is null ? "not_found" : "success");
            var code = dbResult.ErrorCode ?? (data is null ? "ERR404" : ErrorCodes.Success);

            return new ReturnResult<VideoResumeFilesModel>(status, code, data);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in GetVideoResumeAsync");
            throw;
        }
    }



    public async Task<ReturnResult<UserFilesModel>> GetUserFiles(int userId)
    {
        try
        {
            var parameters = new DynamicParameters();
            parameters.Add("@UserId", userId);

            var dbResult = await _dbHelper.QueryAsyncTrans<UserFilesModel>(
                "usp_get_user_files", parameters, _dbKey);

            var data = dbResult.Data?.FirstOrDefault();

            var status = dbResult.ReturnStatus ?? (data is null ? "not_found" : "success");
            var code = dbResult.ErrorCode ?? (data is null ? "ERR404" : ErrorCodes.Success);

            return new ReturnResult<UserFilesModel>(status, code, data);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception in GetUSerFiles");
            throw;
        }
    }

}



