﻿using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ShipJobPortal.Domain.Entities;
using ShipJobPortal.Domain.Interfaces;
using ShipJobPortal.Infrastructure.DataAccessLayer;

namespace ShipJobPortal.Infrastructure.Repositories
{
    public class TokenRepository : ITokenRepository
    {
        private readonly IDataAccess_Improved _dbHelper;
        private readonly IConfiguration _configuration;
        private readonly ILogger<LoginRepository> _logger;
        private readonly string _dbKey;

        public TokenRepository(
    IConfiguration configuration,
    IDataAccess_Improved dbHelper,
    ILogger<LoginRepository> logger)
        {
            _configuration = configuration;
            _dbHelper = dbHelper;
            _logger = logger;

            _dbKey = string.IsNullOrWhiteSpace(_configuration["ConnectionStrings:DefaultConnection"])
                ? throw new Exception("DefaultConnection is missing in ConnectionStrings.")
                : "DefaultConnection";
        }

        public async Task<ReturnResult<RefreshToken>> GetRefreshTokenAsync(string token)
        {
            var result = new ReturnResult<RefreshToken>();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Token", token);

                var dbResult = await _dbHelper.QueryAsyncTrans<RefreshToken>("usp_get_refresh_token", parameters, _dbKey);

                if (dbResult.ReturnStatus == "success" && dbResult.ErrorCode == "ERR200")
                {
                    result.ReturnStatus = parameters.Get<string>("@ReturnStatus");
                    result.ErrorCode = parameters.Get<string>("@ErrorCode");
                    if (dbResult.Data != null && dbResult.Data.Any())
                    {
                        result.Data = dbResult.Data.First();
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception occurred in GetRefreshTokenAsync");
                throw;
            }

            return result;
        }

        public async Task<ReturnResult<string>> UpdateRefreshTokenAsync(RefreshToken token)
        {
            var result = new ReturnResult<string>();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Token", token.Token);
                parameters.Add("@TokenExpiresAt", token.TokenExpiryDate);
                parameters.Add("@Username", token.Email_Id);

                var dbResult = await _dbHelper.ExecuteScalarAsync("usp_update_refresh_token", parameters, _dbKey);

                result.ReturnStatus = parameters.Get<string>("@ReturnStatus");
                result.ErrorCode = parameters.Get<string>("@ErrorCode");
                result.Data = dbResult.ReturnStatus;

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception occurred in UpdateRefreshTokenAsync");
                throw;
            }
        }

        public async Task<ReturnResult> DeleteRefreshTokenAsync(string token)
        {
            var result = new ReturnResult();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Token", token);

                var data = await _dbHelper.ExecuteScalarAsync("usp_delete_refresh_token", parameters, _dbKey);


                return new ReturnResult()
                {
                    ReturnStatus = parameters.Get<string>("@ReturnStatus"),
                    ErrorCode = parameters.Get<string>("@ErrorCode")
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception occurred in DeleteRefreshTokenAsync");
                throw;
            }
        }

    }
}
