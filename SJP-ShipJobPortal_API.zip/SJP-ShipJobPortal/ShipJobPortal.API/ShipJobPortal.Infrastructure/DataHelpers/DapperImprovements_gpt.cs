﻿//*DataAccess_improved Version 2

using System.Data;
using Dapper;
using ShipJobPortal.Infrastructure.DataHelpers;

namespace ShipJobPortal.Infrastructure.DataAccessLayer;

public interface IDataAccess_Improved
{
    Task<DbResult<List<T>>> QueryAsync<T>(string spName, DynamicParameters parameters, string dbKey);
    Task<DbResult<T>> QuerySingleAsync<T>(string spName, DynamicParameters parameters, string dbKey);
    Task<DbResult<int>> ExecuteAsync(string spName, DynamicParameters parameters, string dbKey);
    Task<DbResult<object>> ExecuteScalarAsync(string spName, DynamicParameters parameters, string dbKey);
    Task<DbResult<List<IEnumerable<dynamic>>>> QueryMultipleAsync(string spName, DynamicParameters parameters, string dbKey);
    Task<DbResult<List<T>>> QueryAsyncTrans<T>(string spName, DynamicParameters parameters, string dbKey);
}

public class DataAccess_Improved : IDataAccess_Improved
{
    //private readonly Func<string, IDbConnection> _connectionFactory;
    private readonly IDbConnectionFactory _connectionFactory;
    public DataAccess_Improved(IDbConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    private void AddOutputParams(DynamicParameters parameters)
    {
        parameters.Add("@ReturnStatus", dbType: DbType.String, size: 50, direction: ParameterDirection.Output);
        parameters.Add("@ErrorCode", dbType: DbType.String, size: 50, direction: ParameterDirection.Output);
    }

    private DbResult<T> MapResult<T>(T result, DynamicParameters parameters)
    {
        try
        {
            return new DbResult<T>
            {
                Data = result,
                ReturnStatus = parameters.Get<string>("@ReturnStatus"),
                ErrorCode = parameters.Get<string>("@ErrorCode")
            };
        }
        catch (Exception ex)
        {
            throw;

        }
    }

    public async Task<DbResult<List<T>>> QueryAsync<T>(string spName, DynamicParameters parameters, string dbKey)
    {
        try
        {
            using var conn = _connectionFactory.CreateConnection(dbKey);
            AddOutputParams(parameters);
            var result = await conn.QueryAsync<T>(spName, parameters, commandType: CommandType.StoredProcedure);
            return MapResult(result.ToList(), parameters);
        }
        catch (Exception ex)
        {
            throw;

        }
    }

    public async Task<DbResult<T>> QuerySingleAsync<T>(string spName, DynamicParameters parameters, string dbKey)
    {
        try
        {
            using var conn = _connectionFactory.CreateConnection(dbKey);
            AddOutputParams(parameters);
            var result = await conn.QuerySingleOrDefaultAsync<T>(spName, parameters, commandType: CommandType.StoredProcedure);
            return MapResult(result, parameters);
        }
        catch (Exception ex)
        {
            throw;

        }
    }

    public async Task<DbResult<int>> ExecuteAsync(string spName, DynamicParameters parameters, string dbKey)
    {
        try
        {
            using var conn = _connectionFactory.CreateConnection(dbKey);
            AddOutputParams(parameters);
            var result = await conn.ExecuteAsync(spName, parameters, commandType: CommandType.StoredProcedure);
            return MapResult(result, parameters);
        }
        catch (Exception ex)
        {
            throw;

        }
    }

    public async Task<DbResult<object>> ExecuteScalarAsync(string spName, DynamicParameters parameters, string dbKey)
    {
        try
        {
            using var conn = _connectionFactory.CreateConnection(dbKey);
            AddOutputParams(parameters);
            var result = await conn.ExecuteScalarAsync(spName, parameters, commandType: CommandType.StoredProcedure);
            return MapResult(result, parameters);
        }
        catch (Exception ex)
        {
            throw;

        }
    }

    public async Task<DbResult<List<IEnumerable<dynamic>>>> QueryMultipleAsync(string spName, DynamicParameters parameters, string dbKey)
    {
        try
        {
            using var conn = _connectionFactory.CreateConnection(dbKey);
            AddOutputParams(parameters);
            using var grid = await conn.QueryMultipleAsync(spName, parameters, commandType: CommandType.StoredProcedure);

            var result = new List<IEnumerable<dynamic>>();
            while (!grid.IsConsumed)
            {
                result.Add((await grid.ReadAsync()).ToList());
            }

            return MapResult(result, parameters);
        }
        catch (Exception ex)
        {
            throw;

        }
    }

    public async Task<DbResult<List<T>>> QueryAsyncTrans<T>(string spName, DynamicParameters parameters, string dbKey)
    {
        using var conn = _connectionFactory.CreateConnection(dbKey);
        //conn.Open();
        using var tran = conn.BeginTransaction();

        try
        {
            AddOutputParams(parameters);
            var result = await conn.QueryAsync<T>(spName, parameters, tran, commandType: CommandType.StoredProcedure);

            if (parameters.Get<string>("@ReturnStatus") == "success")
                tran.Commit();
            else
                tran.Rollback();

            return MapResult(result.ToList(), parameters);
        }
        catch (Exception ex)
        {
            tran.Rollback();
            throw;
        }
    }
}

public class DbResult<T>
{
    public string ReturnStatus { get; set; }
    public string ErrorCode { get; set; }
    public T Data { get; set; }
}

//*/