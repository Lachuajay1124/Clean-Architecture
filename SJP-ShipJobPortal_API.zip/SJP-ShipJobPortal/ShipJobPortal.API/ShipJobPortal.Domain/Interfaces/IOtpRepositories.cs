﻿using ShipJobPortal.Domain.Entities;

namespace ShipJobPortal.Domain.Interfaces;

public interface IOtpRepositories
{
    Task<ReturnResult<string>> fn_UserOtpSave(UserOtpCredentialsOtp otp);
    Task<ReturnResult<string>> fn_UserOtpVerify(UserOtpVerifyModel user);
}
