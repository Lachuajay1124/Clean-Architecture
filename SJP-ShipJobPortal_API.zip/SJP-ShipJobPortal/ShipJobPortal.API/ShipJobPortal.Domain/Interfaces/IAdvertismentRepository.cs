﻿namespace ShipJobPortal.Domain.Interfaces;

public interface IAdvertismentRepository
{
}
