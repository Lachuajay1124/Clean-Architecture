﻿using ShipJobPortal.Domain.Entities;

namespace ShipJobPortal.Domain.Interfaces;

public interface IJobPostRepository
{
    Task<ReturnResult> CreateorUpdateJobAsync(JobPostModel job);
    Task<ReturnResult<JobViewFilteredModel>> GetAllJobsFilteredAsync(JobFilterRequest model);
    Task<ReturnResult> DeleteJobAsync(int vacancyId);
    Task<ReturnResult<string>> JobViewCountAsync(JobViewCountModel model);
}
