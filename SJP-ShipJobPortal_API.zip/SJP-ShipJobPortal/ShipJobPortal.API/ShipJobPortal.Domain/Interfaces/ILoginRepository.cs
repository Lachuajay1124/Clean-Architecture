﻿using System.Data;
using ShipJobPortal.Domain.Entities;

namespace ShipJobPortal.Domain.Interfaces;

public interface ILoginRepository
{
    Task<ReturnResult<ResetPasswordDataModel>> GetUserRoleAsync(string username);

    Task<ReturnResult> CreateUserAsync(UserApplicantModel user);

    Task<ReturnResult<string>> ResetPasswordAsync(string email, string oldPassword, string newHashedPassword);

    //paralell
    Task<ReturnResult> UserExistsAsync(string email);
    Task<ReturnResult> SeamanBooknumberExistsAsync(string seamanbooknumber);

    Task<ReturnResult<ExistingUserData>> ExistingUserDetails(string email);
    Task<ReturnResult<List<ModulePrevilleagesModel>>> GetModulePrivilegesByRoleAsync(string userRole);

}