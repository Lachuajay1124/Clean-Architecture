﻿using ShipJobPortal.Domain.Entities;

namespace ShipJobPortal.Domain.Interfaces;

public interface IDocumentRepository
{
    Task<ReturnResult<string>> fn_InsertLookupItem(LookupItemModel model);

    Task<ReturnResult<string>> fn_InsertUpdateDocument(DocumentSaveModel model);

}
