﻿namespace ShipJobPortal.Domain.Settings;

public class EmailSettings
{
    public string FromAddress { get; set; }
    public string AppPassword { get; set; }
}
