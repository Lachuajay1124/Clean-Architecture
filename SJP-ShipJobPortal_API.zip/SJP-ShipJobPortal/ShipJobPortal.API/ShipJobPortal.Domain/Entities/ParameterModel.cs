﻿namespace ShipJobPortal.Domain.Entities;
    public sealed class JobFilterRequest
    {
        public int PageNumber { get; init; }
        public int PageSize { get; init; }
        public int? VacancyId { get; init; }
        public int? PositionId { get; init; }
        public int? VesselTypeId { get; init; }
        public int? LocationId { get; init; }
        public int? DurationId { get; init; }
        public string? SearchKey { get; init; }   
        public int CandidateId { get; init; }
        public int? UserId { get; init; }
        public int? CompanyId { get; init; }
    }

    public class GetAppliedCandidateRequestModel
    {
        public int jobId { get; set; }
        public int pageNumber { get; set; } = 1;
        public int pageSize { get; set; } = 8;
        public int? positionId { get; set; } = 0;
        public int? vesselTypeId { get; set; } = 0;
        public int? locationId { get; set; } = 0;
        public int? durationId { get; set; } = 0;
        public string? searchKey { get; set; }
    }

    public class GetAppliedJobsForCandidateModel
    {
        public int UserId { get; set; }
        public int pageNumber { get; set; } = 1;
        public int pageSize { get; set; } = 8;
        public int? positionId { get; set; } = 0;
        public int? vesselTypeId { get; set; } = 0;
        public int? locationId { get; set; } = 0;
        public int? durationId { get; set; } = 0;
        public string? searchKey { get; set; }
    }

    public class GetSavedJobsForCandidateModel
    {
        public int UserId { get; set; }
        public int pageNumber { get; set; } = 1;
        public int pageSize { get; set; } = 10;
        public int? positionId { get; set; } = 0;
        public int? vesselTypeId { get; set; } = 0;
        public int? locationId { get; set; } = 0;
        public int? durationId { get; set; } = 0;
        public int? monthValue { get; set; } = 0;
        public string? searchKey { get; set; }
    }

   public class GetMatchingCandidateForJobModel
{
    public int jobId { get; set; }
    public int userId { get; set; }
    public int pageNumber { get; set; } = 1;
    public int pageSize { get; set; } = 10;
    public int? positionId { get; set; } = 0;
    public int? vesselTypeId { get; set; } = 0;
    public int? locationId { get; set; } = 0;
    public int? durationId { get; set; } = 0;
}

