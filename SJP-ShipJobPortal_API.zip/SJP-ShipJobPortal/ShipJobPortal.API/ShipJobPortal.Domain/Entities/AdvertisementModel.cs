﻿namespace ShipJobPortal.Domain.Entities;

public class AdvertisementModel
{
}
