﻿using System.Text.Json.Serialization;

namespace ShipJobPortal.Domain.Entities;

public class RoleModel
{
    public int RoleId {get;set;}
    public string? Name { get; set; }
    public string? Description { get; set; }
    public int? SortOrder { get; set; }
    public int? CompanyId { get; set; }
    [JsonIgnore]
    public string? CreatedBy { get; set; }
}
