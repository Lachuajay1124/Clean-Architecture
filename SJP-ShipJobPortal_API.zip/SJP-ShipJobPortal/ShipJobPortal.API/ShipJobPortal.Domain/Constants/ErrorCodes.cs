﻿namespace ShipJobPortal.Domain.Constants
{
    public static class ErrorCodes
    {
        // --- 2xx Success ---
        public const string Success = "ERR200";                  // OK
        public const string Created = "ERR201";                  // Created
        public const string Accepted = "ERR202";                 // Accepted
        public const string NoContent = "ERR204";                // No Content

        // --- 3xx Redirection ---
        public const string MovedPermanently = "ERR301";          // Moved Permanently
        public const string Found = "ERR302";                     // Found (Temporary Redirect)
        public const string NotModified = "ERR304";               // Not Modified
        public const string TemporaryRedirect = "ERR307";         // Temporary Redirect
        public const string PermanentRedirect = "ERR308";         // Permanent Redirect

        // --- 4xx Client Errors ---
        public const string BadRequest = "ERR400";                // Bad Request
        public const string Unauthorized = "ERR401";              // Unauthorized
        public const string Forbidden = "ERR403";                 // Forbidden
        public const string NotFound = "ERR404";                  // Not Found
        public const string MethodNotAllowed = "ERR405";          // Method Not Allowed
        public const string NotAcceptable = "ERR406";             // Not Acceptable
        public const string Conflict = "ERR409";                  // Conflict
        public const string Gone = "ERR410";                      // Gone
        public const string UnsupportedMediaType = "ERR415";      // Unsupported Media Type
        public const string UnprocessableEntity = "ERR422";       // Validation Error
        public const string TooManyRequests = "ERR429";           // Too Many Requests

        // --- 5xx Server Errors ---
        public const string InternalServerError = "ERR500";       // Internal Server Error
        public const string NotImplemented = "ERR501";            // Not Implemented
        public const string BadGateway = "ERR502";                // Bad Gateway
        public const string ServiceUnavailable = "ERR503";        // Service Unavailable
        public const string GatewayTimeout = "ERR504";            // Gateway Timeout

        // --- Domain-specific / Custom ---
        public const string InvalidCredentials = "ERR401C";       // Custom invalid credentials
        public const string InvalidPassword = "ERR402";           // Invalid password
        public const string MissingPassword = "ERR405C";          // Custom missing password
        public const string InvalidEmailFormat = "ERR406C";       // Custom invalid email
        public const string NoAnswersFound = "ERR_NO_ANSWERS";    // Domain-specific
    }
}
