// next-sitemap.config.js
/** @type {import('next-sitemap').IConfig} */
module.exports = {
  siteUrl: "http://10.60.120.76:3006/", // 🔁 replace with your domain
  generateRobotsTxt: true, // (optional) generate robots.txt
  changefreq: "daily",
  priority: 0.7,
  sitemapSize: 5000,
  outDir: "public", // ← ensures static export
};
