importScripts(
  "https://www.gstatic.com/firebasejs/10.5.0/firebase-app-compat.js"
);
importScripts(
  "https://www.gstatic.com/firebasejs/10.5.0/firebase-messaging-compat.js"
);

//For testing purposes only, will be removed in production

const firebaseConfig = {
  apiKey: "AIzaSyBJ3URPLryTdvAY4WHGMAhEhkK-GYGn--U",
  authDomain: "sjp-prototype.firebaseapp.com",
  projectId: "sjp-prototype",
  messagingSenderId: "65675015070",
  appId: "1:65675015070:web:dbc6f1bd8a90b2880fdc8f",
};

firebase.initializeApp(firebaseConfig);

const messaging = firebase.messaging();

messaging.onBackgroundMessage(function (payload) {
  console.log(
    "[firebase-messaging-sw.js] Received background message ",
    payload
  );

  const notificationTitle = payload.notification?.title || "Default Title";
  const notificationOptions = {
    body: payload.notification?.body || "Default body",
    icon: "/firebase-logo.png",
    badge: "/firebase-logo.png",
  };

  self.registration.showNotification(notificationTitle, notificationOptions);
});
