import { NextResponse, NextRequest } from "next/server";

// Public routes that don't need auth
const PUBLIC_PATHS = [
  "/login",
  "/api/auth",
  "/unauthorized",
  "/_not-found",
] as const;

// Only these prefixes require auth – everything else can render 404 if missing
const PROTECTED_PREFIXES = ["/candidates", "/recruiters"] as const;

type UserRole = "Seafarer" | "Recruiter";
const ROLE_REDIRECTS: Record<UserRole, string> = {
  Seafarer: "/candidates",
  Recruiter: "/recruiters",
};

function getAuthToken(req: NextRequest): string | null {
  const cookieToken = req.cookies.get("SjpJwtToken")?.value;
  if (cookieToken) return cookieToken;

  const auth =
    req.headers.get("authorization") || req.headers.get("Authorization");
  if (auth && auth.startsWith("Bearer "))
    return auth.slice("Bearer ".length).trim();
  return null;
}

function isPublicPath(pathname: string) {
  return PUBLIC_PATHS.some((p) => pathname.startsWith(p));
}
function isProtectedPath(pathname: string) {
  return PROTECTED_PREFIXES.some((p) => pathname.startsWith(p));
}

function safeParseJSON<T>(value: string | undefined, fallback: T): T {
  if (!value) return fallback;
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

function isPermitted(pathname: string, allowed: string[]) {
  if (!allowed.length) return true;
  if (allowed.includes(pathname)) return true;
  return allowed.some((r) => r !== "/" && pathname.startsWith(r));
}

function getRedirectPathFromRoleCookie(req: NextRequest) {
  const roleCookie = (req.cookies.get("role")?.value ?? "Seafarer") as UserRole;
  return ROLE_REDIRECTS[roleCookie] ?? "/login";
}

/** Redirect helper; optionally nukes auth cookies */
function redirectWithCookieClear(
  to: string | URL,
  origin: string,
  clearAuth = false
) {
  const res = NextResponse.redirect(new URL(to, origin));
  if (clearAuth) {
    res.cookies.set("SjpJwtToken", "", { path: "/", expires: new Date(0) });
    res.cookies.set("allowedRoutes", "", { path: "/", expires: new Date(0) });
    res.cookies.set("role", "", { path: "/", expires: new Date(0) });
  }
  return res;
}

export async function middleware(req: NextRequest) {
  const { pathname, origin } = req.nextUrl;

  const token = getAuthToken(req);
  const publicPath = isPublicPath(pathname);
  const protectedPath = isProtectedPath(pathname);
  const isUnauthorized = pathname === "/unauthorized";

  // Root → neutral redirect; middleware will route appropriately
  if (pathname === "/") {
    return NextResponse.redirect(
      new URL(token ? getRedirectPathFromRoleCookie(req) : "/login", origin)
    );
  }

  // Unauthenticated trying to access protected route → go to login
  if (!token && protectedPath) {
    return redirectWithCookieClear("/login", origin, true);
  }

  // Authenticated visiting a public page (except /unauthorized and /_not-found) → send to role home
  if (token && publicPath && !isUnauthorized && pathname !== "/_not-found") {
    return NextResponse.redirect(
      new URL(getRedirectPathFromRoleCookie(req), origin)
    );
  }

  // Optional: light UX permission gating (non-authoritative) only for protected paths
  if (token && protectedPath && !isUnauthorized) {
    const allowedRoutes = safeParseJSON<string[]>(
      req.cookies.get("allowedRoutes")?.value,
      []
    );
    if (!isPermitted(pathname, allowedRoutes)) {
      return NextResponse.redirect(new URL("/unauthorized", origin));
    }
  }

  // Let Next handle routing (including rendering the real 404)
  return NextResponse.next();
}

export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico|api/auth|images|fonts|firebase-messaging-sw.js|.well-known).*)",
  ],
};
