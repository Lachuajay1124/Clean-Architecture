"use client";

import React, { FC, useMemo, useState } from "react";
import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getSortedRowModel,
  SortingState,
  ColumnFiltersState,
  useReactTable,
} from "@tanstack/react-table";

import { Briefcase, Calendar, MapPin, ArrowUpDown } from "lucide-react";

import { Empty } from "@/components/common/EmptyMessage/Empty";
import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";
import { KnowMoreCard } from "@/components/common/Layout/Modal/CandidateModal/knowMoreCard/knowmore";
import { Pagination } from "@/components/common/Layout/Pagination/pagination";
import { useAllAppliedJobsByCandidate } from "@/hooks/listingHooks/useListingHooks";
import { sanitizeInput } from "@/lib/validation";
import { useJobFilterStore } from "@/store/useFilterStore";
import { useSearchStore } from "@/store/useSearchStore";

/** Row type inferred from your API shape */
type JobApplicationRow = {
  applicationId: number;
  jobId: number;
  jobTitle: string;
  companyName: string;
  nationality?: string | null;
  appliedDate: string; // ISO string
};

export const AllAppliedJobs: FC = () => {
  const { searchValue } = useSearchStore();
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedJob, setSelectedJob] = useState<number | null>(null);
  const { positionId, vesselTypeId, locationId, durationId } =
    useJobFilterStore();

  const {
    data: jobs,
    isLoading: isJobsLoading,
    error,
  } = useAllAppliedJobsByCandidate({
    searchKey: sanitizeInput(searchValue),
    pageNumber: currentPage,
    pageSize: 9,
    positionId,
    vesselTypeId,
    locationId,
    durationId,
  });

  const jobsList: JobApplicationRow[] = Array.isArray(jobs?.jobsList)
    ? jobs.jobsList
    : [];
  const totalPages = jobs?.pagination?.totalPages ?? 1;

  const [sorting, setSorting] = useState<SortingState>([
    { id: "appliedDate", desc: true },
  ]);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);

  const columns = useMemo<ColumnDef<JobApplicationRow>[]>(
    () => [
      {
        accessorKey: "jobTitle",
        header: ({ column }) => (
          <button
            className="flex items-center gap-1 font-semibold"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            aria-label="Sort by Job Title"
          >
            Job Title <ArrowUpDown className="h-3.5 w-3.5" />
          </button>
        ),
        cell: ({ row }) => (
          <span className="text-[10px] md:text-xs md:font-medium">
            {row.original.jobTitle}
          </span>
        ),
        filterFn: "includesString",
      },
      {
        accessorKey: "companyName",
        header: ({ column }) => (
          <button
            className="flex items-center gap-1 font-semibold"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            aria-label="Sort by Company"
          >
            Company <ArrowUpDown className="h-3.5 w-3.5" />
          </button>
        ),
        cell: ({ row }) => (
          <span className="text-[10px] md:text-xs md:font-medium">
            {row.original.companyName}
          </span>
        ),
        filterFn: "includesString",
      },
      {
        accessorKey: "nationality",
        header: () => <span>Job Location</span>,
        cell: ({ row }) => (
          <div className="flex items-center text-xs font-medium">
            <MapPin className="w-4 h-4 mr-2 text-gray-400 hidden md:block" />
            {row.original.nationality || "Remote"}
          </div>
        ),
        // Keep hidden on small like the original
        meta: { className: "hidden md:table-cell" },
        enableSorting: false,
      },
      {
        accessorKey: "appliedDate",
        header: ({ column }) => (
          <button
            className="flex items-center gap-1 font-semibold"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            aria-label="Sort by Applied Date"
          >
            Applied Date <ArrowUpDown className="h-3.5 w-3.5" />
          </button>
        ),
        cell: ({ row }) => {
          const d = new Date(row.original.appliedDate);
          const formatted = d.toLocaleDateString(undefined, {
            year: "numeric",
            month: "short",
            day: "numeric",
          });
          return (
            <div className="flex items-center text-[10px] md:text-xs md:font-medium">
              <Calendar className="w-4 h-4 mr-2 text-gray-400 hidden md:block" />
              {formatted}
            </div>
          );
        },
        sortingFn: (a, b) => {
          const da = new Date(a.original.appliedDate).getTime();
          const db = new Date(b.original.appliedDate).getTime();
          return da === db ? 0 : da > db ? 1 : -1;
        },
      },
    ],
    []
  );

  const table = useReactTable({
    data: jobsList,
    columns,
    state: { sorting, columnFilters, globalFilter: searchValue },
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    // We’re NOT paginating via TanStack; you already do server pagination below.
  });

  const showEmpty =
    !isJobsLoading && !error && table.getRowModel().rows.length === 0;

  return (
    <>
      {/* Body */}
      <div className="h-full overflow-hidden flex flex-col">
        {isJobsLoading ? (
          <LoadingSpinner />
        ) : error ? (
          <div className="text-center">
            <h3 className="text-lg font-semibold text-red-600 mb-2">
              Error loading applied jobs
            </h3>
            <p className="text-gray-500">Please try again later</p>
          </div>
        ) : showEmpty ? (
          <Empty
            icon={<Briefcase size={24} className="text-blue-600" />}
            title="No Jobs Found"
            description="Try adjusting your search or filters."
          />
        ) : (
          <div className="bg-white rounded-md border border-gray-100 shadow-md flex flex-col overflow-hidden h-full">
            <div className="overflow-auto flex-1">
              <table className="min-w-full table-fixed">
                <thead className="btn-primary text-white sticky top-0 z-10">
                  {table.getHeaderGroups().map((hg) => (
                    <tr key={hg.id}>
                      {hg.headers.map((header) => {
                        const meta = header.column.columnDef.meta as
                          | { className?: string }
                          | undefined;
                        return (
                          <th
                            key={header.id}
                            className={`${
                              meta?.className ?? ""
                            } p-1 md:p-2 text-left text-[10px] md:text-xs md:font-semibold uppercase tracking-wider`}
                          >
                            {header.isPlaceholder
                              ? null
                              : flexRender(
                                  header.column.columnDef.header,
                                  header.getContext()
                                )}
                          </th>
                        );
                      })}
                    </tr>
                  ))}
                </thead>
                <tbody className="divide-y divide-gray-100 text-xs">
                  {table.getRowModel().rows.map((row) => (
                    <tr
                      key={row.id}
                      className="hover:bg-gray-50 transition-colors duration-150 cursor-pointer"
                      onClick={() => setSelectedJob(row.original.jobId)}
                      aria-label={`View details for ${row.original.jobTitle} at ${row.original.companyName}`}
                      role="button"
                    >
                      {row.getVisibleCells().map((cell) => {
                        const meta = cell.column.columnDef.meta as
                          | { className?: string }
                          | undefined;
                        return (
                          <td
                            key={cell.id}
                            className={`${
                              meta?.className
                                ? meta.className.replace(
                                    "table-cell",
                                    "block md:table-cell"
                                  )
                                : ""
                            } p-1 md:p-2`}
                          >
                            {flexRender(
                              cell.column.columnDef.cell,
                              cell.getContext()
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Keep your server-side pagination */}
      {totalPages >= 1 && (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={setCurrentPage}
        />
      )}

      {/* Modal */}
      <KnowMoreCard
        isOpen={Boolean(selectedJob)}
        jobId={selectedJob}
        onClose={() => setSelectedJob(null)}
        aria-labelledby="job-details-modal"
      />
    </>
  );
};
