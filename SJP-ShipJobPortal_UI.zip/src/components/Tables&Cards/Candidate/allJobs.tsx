"use client";

import { Empty } from "@/components/common/EmptyMessage/Empty";
import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";
import { JobCard } from "@/components/common/Layout/Modal/CandidateModal/candidateJobCard/page";
import { KnowMoreCard } from "@/components/common/Layout/Modal/CandidateModal/knowMoreCard/knowmore";
import { Pagination } from "@/components/common/Layout/Pagination/pagination";
import { useAllAvailableJobForCandidates } from "@/hooks/listingHooks/useListingHooks";
import { sanitizeInput } from "@/lib/validation";
import { useJobFilterStore } from "@/store/useFilterStore";
import { useSearchStore } from "@/store/useSearchStore";
import { Job } from "@/types/getApiTypes";
import { Briefcase } from "lucide-react";
import React, { useState } from "react";

export const AllJobs = () => {
  const [selectedJob, setSelectedJob] = useState<number | null>(null);
  const { searchValue } = useSearchStore();
  const [currentPage, setCurrentPage] = useState(1);
  const { positionId, vesselTypeId, locationId, durationId } =
    useJobFilterStore();

  const {
    data: jobs,
    isLoading: isJobsLoading,
    error,
  } = useAllAvailableJobForCandidates({
    searchKey: sanitizeInput(searchValue),
    positionId,
    vesselTypeId,
    locationId,
    durationId,
    vacancyId: 0,
    userId: 0,
    pageSize: 40,
    pageNumber: currentPage,
  });

  const jobList = jobs?.jobsList ?? [];
  const handleCloseModal = () => setSelectedJob(null);
  const handleJobSet = (job: Job) => setSelectedJob(job?.jobId);

  const totalPages = jobs?.pagination?.totalPages ?? 1;

  return (
    <>
      {isJobsLoading ? (
        <div className="flex-1 flex items-center justify-center">
          <LoadingSpinner />
        </div>
      ) : error ? (
        <div className="flex-1 flex justify-center items-center">
          <div className="text-center">
            <h3 className="text-lg font-semibold text-red-600 mb-2">
              Error loading jobs
            </h3>
            <p className="text-gray-500">Please try again later</p>
          </div>
        </div>
      ) : jobList.length === 0 ? (
        <div className="flex-1">
          <Empty
            icon={<Briefcase size={24} className="text-blue-600" />}
            title="No Jobs Found"
            description="Try adjusting your search filters."
          />
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto overflow-x-hidden">
          {/* Virtual canvas */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 h-full">
            {jobList.map((job) => (
              <div key={job.jobId} className="h-full">
                <JobCard job={job} onJobSet={handleJobSet} />
              </div>
            ))}

            {/* Pagination Section */}

            {totalPages >= 1 && (
              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={setCurrentPage}
              />
            )}
          </div>
        </div>
      )}
      {/* Job Detail Modal */}
      <KnowMoreCard
        isOpen={Boolean(selectedJob)}
        jobId={selectedJob}
        onClose={handleCloseModal}
      />
    </>
  );
};
