"use client";

import React, { useMemo, useState } from "react";
import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  getSortedRowModel,
  SortingState,
  useReactTable,
} from "@tanstack/react-table";

import { SaveJobs } from "@/app/api/jobsApi/types";
import { Empty } from "@/components/common/EmptyMessage/Empty";
import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";
import { KnowMoreCard } from "@/components/common/Layout/Modal/CandidateModal/knowMoreCard/knowmore";
import { Pagination } from "@/components/common/Layout/Pagination/pagination";
import { useSaveJob } from "@/hooks/actionHooks/saveJobApi";
import { useAllSavedJobsByCandidate } from "@/hooks/listingHooks/useListingHooks";
import { sanitizeInput } from "@/lib/validation";
import { useJobFilterStore } from "@/store/useFilterStore";
import { useSearchStore } from "@/store/useSearchStore";
import {
  Briefcase,
  Calendar,
  Eye,
  MapPin,
  Trash2,
  ArrowUpDown,
} from "lucide-react";

type SavedJobRow = {
  applicationId: number;
  jobId: number;
  jobTitle: string;
  companyName: string;
  nationality?: string | null;
  closeDate: string; // ISO
  noVacancy?: number | null;
};

const AllSavedJobs = () => {
  const { searchValue } = useSearchStore();
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedJob, setSelectedJob] = useState<number | null>(null);
  const saveJobMutation = useSaveJob(() => {});
  const { positionId, vesselTypeId, locationId, durationId } =
    useJobFilterStore();

  const {
    data: jobs,
    isLoading: isJobsLoading,
    error,
  } = useAllSavedJobsByCandidate({
    searchKey: sanitizeInput(searchValue),
    pageNumber: currentPage,
    pageSize: 10,
    positionId,
    vesselTypeId,
    locationId,
    durationId,
  });

  const rows: SavedJobRow[] = Array.isArray(jobs?.jobsList)
    ? jobs.jobsList
    : [];
  const totalPages = jobs?.pagination?.totalPages ?? 1;

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const confirmSave =  (jobId: number) => {
    if (!jobId) return;
    const data: SaveJobs = { jobId, mode: "remove" };
    saveJobMutation.mutate(data);
  };

  const [sorting, setSorting] = useState<SortingState>([
    { id: "closeDate", desc: false },
  ]);

  const columns = useMemo<ColumnDef<SavedJobRow>[]>(
    () => [
      {
        accessorKey: "jobTitle",
        header: ({ column }) => (
          <button
            className="flex items-center gap-1 font-semibold"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            aria-label="Sort by Job Title"
          >
            Job Title <ArrowUpDown className="h-3.5 w-3.5" />
          </button>
        ),
        cell: ({ row }) => (
          <span className="text-[10px] md:text-xs md:font-medium">
            {row.original.jobTitle}
          </span>
        ),
      },
      {
        accessorKey: "companyName",
        header: ({ column }) => (
          <button
            className="flex items-center gap-1 font-semibold"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            aria-label="Sort by Company"
          >
            Company <ArrowUpDown className="h-3.5 w-3.5" />
          </button>
        ),
        cell: ({ row }) => (
          <span className="text-[10px] md:text-xs md:font-medium">
            {row.original.companyName}
          </span>
        ),
      },
      {
        accessorKey: "nationality",
        header: ({ column }) => (
          <button
            className="flex items-center gap-1 font-semibold"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            aria-label="Sort by Location"
          >
            Location <ArrowUpDown className="h-3.5 w-3.5" />
          </button>
        ),
        cell: ({ row }) => (
          <div className="flex items-center text-[10px] md:text-xs md:font-medium">
            <MapPin className="w-4 h-4 mr-2 text-gray-400 hidden md:block" />
            {row.original.nationality || "Remote"}
          </div>
        ),
      },
      {
        accessorKey: "closeDate",
        header: ({ column }) => (
          <button
            className="flex items-center gap-1 font-semibold"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            aria-label="Sort by Close Date"
          >
            Close Date <ArrowUpDown className="h-3.5 w-3.5" />
          </button>
        ),
        cell: ({ row }) => {
          const d = new Date(row.original.closeDate);
          const formatted = d.toLocaleDateString(undefined, {
            year: "numeric",
            month: "short",
            day: "numeric",
          });
          return (
            <div className="flex items-center text-[10px] md:text-xs md:font-medium">
              <Calendar className="w-4 h-4 mr-2 text-gray-400 hidden md:block" />
              {formatted}
            </div>
          );
        },
        sortingFn: (a, b) => {
          const da = new Date(a.original.closeDate).getTime();
          const db = new Date(b.original.closeDate).getTime();
          return da === db ? 0 : da > db ? 1 : -1;
        },
      },
      {
        accessorKey: "noVacancy",
        header: ({ column }) => (
          <button
            className="hidden md:flex items-center gap-1 font-semibold"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            aria-label="Sort by No of Vacancy"
          >
            No of Vacancy <ArrowUpDown className="h-3.5 w-3.5" />
          </button>
        ),
        cell: ({ row }) => (
          <span className="hidden md:block p-2 text-xs md:font-medium">
            {row.original.noVacancy ?? 0}
          </span>
        ),
        // Keep hidden on small screens
        meta: { className: "hidden md:table-cell" },
      },
      {
        id: "actions",
        header: () => <span>Actions</span>,
        cell: ({ row }) => (
          <div className="flex justify-between gap-2">
            <Eye
              className="text-green-600 w-4 h-4 cursor-pointer hover:scale-110"
              onClick={() => setSelectedJob(row.original.jobId)}
              aria-label={`View job ${row.original.jobTitle}`}
            />
            <Trash2
              className="text-red-600 w-4 h-4 cursor-pointer hover:scale-110"
              onClick={() => confirmSave(row.original.jobId)}
              aria-label={`Remove job ${row.original.jobTitle}`}
            />
          </div>
        ),
        enableSorting: false,
      },
    ],
    [confirmSave]
  );

  const table = useReactTable({
    data: rows,
    columns,
    state: { sorting },
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    // We keep pagination server-side via your <Pagination /> below
  });

  const showEmpty =
    !isJobsLoading && !error && table.getRowModel().rows.length === 0;

  return (
    <>
      <div className="h-full overflow-hidden flex flex-col">
        {isJobsLoading ? (
          <LoadingSpinner />
        ) : error ? (
          <div className="flex justify-center items-center min-h-[400px]">
            <div className="text-center">
              <h3 className="text-lg font-semibold text-red-600 mb-2">
                Error loading saved jobs
              </h3>
              <p className="text-gray-500">Please try again later</p>
            </div>
          </div>
        ) : showEmpty ? (
          <Empty
            icon={<Briefcase size={24} className="text-blue-600" />}
            title="No Jobs Found"
            description="Try adjusting your filters."
          />
        ) : (
          <div className="bg-white rounded-md border border-gray-100 flex flex-col overflow-hidden h-full">
            <div className="overflow-auto flex-1">
              <table className="min-w-full table-fixed">
                <thead className="btn-primary text-white sticky top-0 z-10">
                  {table.getHeaderGroups().map((hg) => (
                    <tr key={hg.id}>
                      {hg.headers.map((header) => {
                        const meta = header.column.columnDef.meta as
                          | { className?: string }
                          | undefined;
                        return (
                          <th
                            key={header.id}
                            className={`${
                              meta?.className ?? ""
                            } p-1 md:p-2 text-left text-xs font-semibold uppercase tracking-wider`}
                          >
                            {header.isPlaceholder
                              ? null
                              : flexRender(
                                  header.column.columnDef.header,
                                  header.getContext()
                                )}
                          </th>
                        );
                      })}
                    </tr>
                  ))}
                </thead>
                <tbody className="divide-y divide-gray-100 text-xs">
                  {table.getRowModel().rows.map((row) => (
                    <tr
                      key={row.id}
                      className="hover:bg-gray-50 transition-colors duration-150"
                    >
                      {row.getVisibleCells().map((cell) => {
                        const meta = cell.column.columnDef.meta as
                          | { className?: string }
                          | undefined;
                        const baseTd = "p-1 md:p-2";
                        // preserve hidden-on-small styling for the No of Vacancy column
                        const tdClass = meta?.className
                          ? `${meta.className.replace(
                              "table-cell",
                              "block md:table-cell"
                            )} ${baseTd}`
                          : baseTd;
                        return (
                          <td key={cell.id} className={tdClass}>
                            {flexRender(
                              cell.column.columnDef.cell,
                              cell.getContext()
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {totalPages >= 1 && (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={setCurrentPage}
        />
      )}

      <KnowMoreCard
        isOpen={Boolean(selectedJob)}
        jobId={selectedJob}
        onClose={() => setSelectedJob(null)}
      />
    </>
  );
};

export default AllSavedJobs;
