"use client";

import React, { useState } from "react";
import dynamic from "next/dynamic";
import Image from "next/image";
import { formatDateForInput } from "@/lib/format";
import { sanitizeInput } from "@/lib/validation";
import { useAllCandidateDetails } from "@/hooks/listingHooks/useListingHooks";
import { useSearchStore } from "@/store/useSearchStore";
import { useJobSelectStore } from "@/store/useJobSelectStore";
import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";
import { Pagination } from "@/components/common/Layout/Pagination/pagination";
import {
  Banknote,
  Briefcase,
  Calendar,
  Mail,
  MapPin,
  SquareUser,
  User,
  Users,
} from "lucide-react";

export interface Candidate {
  applicationId: number;
  userId: number;
  firstName: string;
  designation: string | null;
  salaryExpected: number | null;
  email: string;
  dateOfAvailability: string | number;
  jobId: number;
  nationality: string | null;
  address: string | null;
  totalYearsOfExperiance: number | null;
  appliedDate?: string;
  image?: string;
}

const SeafarerProfile = dynamic(
  () => import("@/app/(roles)/recruiters/candidateProfile/candidateProfile"),
  { loading: () => <LoadingSpinner />, ssr: false }
);

interface CandidateCardProps {
  candidate: Candidate;
  onViewProfile: (userId: number) => void;
}

const CandidateCard: React.FC<CandidateCardProps> = ({
  candidate,
  onViewProfile,
}) => {
  return (
    <div
      className="bg-white rounded-md border border-gray-200 shadow-sm hover:scale-[1.02] hover:shadow-md hover:border-blue-200 transition-all duration-200 p-2 relative overflow-hidden"
      role="listitem"
    >
      <div className="flex items-start justify-between mb-2 text-xs">
        <span className="font-medium text-gray-700 truncate flex-1 mr-2">
          {candidate.designation || "Position Not Specified"}
        </span>
      </div>

      <div className="flex items-center gap-2 mb-2">
        <div className="relative">
          {candidate.image ? (
            <Image
              width={100}
              height={100}
              src={candidate.image}
              alt={candidate.firstName}
              className="w-12 h-12 rounded-md object-cover ring-1 ring-gray-200"
            />
          ) : (
            <div className="w-12 h-12 rounded-md bg-gradient-to-br from-blue-100 to-indigo-200 flex items-center justify-center">
              <User size={24} className="text-blue-600" />
            </div>
          )}
        </div>

        <div className="flex-1 min-w-0 space-y-1">
          <div className="flex items-center gap-2 text-xs text-gray-500">
            <SquareUser size={12} />
            <span className="truncate">{candidate.firstName}</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-gray-500">
            <Mail size={12} />
            <span className="truncate">{candidate.email}</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-gray-500 whitespace-nowrap">
            <Calendar size={12} />
            <span>
              Available - {formatDateForInput(candidate.dateOfAvailability)}
            </span>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between mb-2 text-xs">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-gray-600">
            <Briefcase size={12} />
            <span>
              {candidate.totalYearsOfExperiance
                ? `${candidate.totalYearsOfExperiance}y`
                : "N/A"}
            </span>
          </div>
          <div className="flex items-center gap-2 text-gray-600">
            <Banknote size={12} />
            <span>{candidate.salaryExpected ?? "N/A"}</span>
          </div>
        </div>

        {candidate.nationality && (
          <div className="flex items-center gap-2 text-gray-500">
            <MapPin size={12} />
            <span>{candidate.nationality}</span>
          </div>
        )}
      </div>

      <div className="flex gap-2.5">
        <button
          onClick={() => onViewProfile(candidate.userId)}
          className="flex-1 btn-primary cursor-pointer hover:from-blue-700 hover:to-blue-800 text-white text-xs font-medium py-1 px-3 rounded-md transition-all duration-200"
          aria-label={`View profile of ${candidate.firstName}`}
        >
          View Profile
        </button>
      </div>
    </div>
  );
};

const AllAppliedCandidates: React.FC = () => {
  const [showProfile, setShowProfile] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [currentPage, setCurrentPage] = useState(1);

  const { searchValue } = useSearchStore();
  const { selectedJobTitle, selectedJobId } = useJobSelectStore();

  const {
    data: candidatesData,
    isLoading: isCandidateLoading,
    isError: isCandidateError,
  } = useAllCandidateDetails({
    pageNumber: currentPage,
    jobId: selectedJobId, // bound to JobSelect
    searchKey: sanitizeInput(searchValue),
  });

  const totalPages = Number(candidatesData?.pagination?.totalPages ?? 1);

  return (
    <>
      <div className="flex-1 flex flex-col min-h-0">
        <div className="flex-1 overflow-y-auto overflow-x-hidden">
          {isCandidateLoading ? (
            <div className="flex items-center justify-center h-full">
              <LoadingSpinner />
            </div>
          ) : isCandidateError ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-center bg-red-50 border border-red-200 rounded-md p-4 text-red-700">
                Failed to load candidates.
              </div>
            </div>
          ) : candidatesData?.candidatesList?.length ? (
            <div
              className="grid grid-cols-1 md:grid-cols-4 gap-2 pb-4"
              role="list"
            >
              {candidatesData.candidatesList.map((candidate: Candidate) => (
                <CandidateCard
                  key={candidate.applicationId}
                  candidate={candidate}
                  onViewProfile={(userId) => {
                    setSelectedUserId(userId);
                    setShowProfile(true);
                  }}
                />
              ))}
            </div>
          ) : (
            <div className="flex items-center justify-center h-full">
              <div className="text-center space-y-2">
                <Users size={28} className="text-gray-400 mx-auto" />
                <p className="text-gray-600 font-medium">No candidates found</p>
                <p className="text-sm text-gray-500">
                  {selectedJobId
                    ? `No applications for "${selectedJobTitle}" yet.`
                    : "Select a job to view applicants."}
                </p>
              </div>
            </div>
          )}
        </div>

        {totalPages > 1 && (
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
          />
        )}
      </div>

      {showProfile && selectedUserId !== null && (
        <SeafarerProfile
          userId={selectedUserId}
          onClose={() => setShowProfile(false)}
          isOpen={showProfile}
        />
      )}
    </>
  );
};

export default AllAppliedCandidates;
