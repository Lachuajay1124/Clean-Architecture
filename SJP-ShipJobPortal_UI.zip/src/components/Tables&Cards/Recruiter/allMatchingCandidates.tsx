"use client";

import SeafarerProfile from "@/app/(roles)/recruiters/candidateProfile/candidateProfile";
import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";
import { Pagination } from "@/components/common/Layout/Pagination/pagination";
import { useAllMatchingCandidateDetails } from "@/hooks/listingHooks/useListingHooks";
import { sanitizeInput } from "@/lib/validation";
import { useJobSelectStore } from "@/store/useJobSelectStore";
import { useSearchStore } from "@/store/useSearchStore";
import { Candidates } from "@/types/getApiTypes";
import { Download, Search } from "lucide-react";
import React, { useMemo, useState } from "react";

import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  getSortedRowModel,
  SortingState,
  useReactTable,
} from "@tanstack/react-table";

export const AllMatchingCandidates = () => {
  const { searchValue } = useSearchStore();
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedCandidates, setSelectedCandidates] = useState<number[]>([]);

  const [showProfile, setShowProfile] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const { selectedJobId } = useJobSelectStore();

  const {
    data: matchingCandidatesData,
    isLoading: isMatchingCandidateLoading,
    isError: isMatchingCandidatesError,
  } = useAllMatchingCandidateDetails({
    pageNumber: currentPage,
    pageSize: 3,
    jobId: selectedJobId,
    searchKey: sanitizeInput(searchValue),
  });

  const totalPages = Number(
    matchingCandidatesData?.pagination?.totalPages ?? 1
  );

  const handleExportToShiphire = () => {
    const selectedProfiles =
      matchingCandidatesData?.candidates?.filter((profile: Candidates) =>
        selectedCandidates.includes(profile.candidateid)
      ) ?? [];

    alert(
      `Exporting ${
        selectedProfiles.length
      } candidate(s) to Shiphire:\n\n${selectedProfiles
        .map((profile) => `• ${profile.name} (${profile.experience})`)
        .join("\n")}`
    );
  };

  const ApplicationTable = ({
    applications,
  }: {
    applications: Candidates[];
    currentPage: number;
  }) => {
    const handleCheckboxChange = (id: number, checked: boolean) => {
      setSelectedCandidates((prev) =>
        checked ? [...prev, id] : prev.filter((val) => val !== id)
      );
    };

    const isSelected = (id: number) => selectedCandidates.includes(id);

    // -------- TanStack: sorting only --------
    const [sorting, setSorting] = useState<SortingState>([
      { id: "designation", desc: false },
    ]);

    const columns = useMemo<ColumnDef<Candidates>[]>(() => {
      return [
        // Selection column (kept identical UX)
        {
          id: "select",
          header: ({ table }) => {
            const rowsOnPage = table
              .getRowModel()
              .rows.map((r) => (r.original as Candidates).candidateid);
            const allSelected =
              rowsOnPage.length > 0 &&
              rowsOnPage.every((id) => selectedCandidates.includes(id));

            return (
              <input
                type="checkbox"
                className="cursor-pointer"
                checked={allSelected}
                onChange={(e) => {
                  const isChecked = e.target.checked;
                  setSelectedCandidates((prev) => {
                    return isChecked
                      ? [...new Set([...prev, ...rowsOnPage])]
                      : prev.filter((id) => !rowsOnPage.includes(id));
                  });
                }}
                aria-label="Select all candidates on page"
              />
            );
          },
          cell: ({ row }) => (
            <input
              type="checkbox"
              checked={isSelected(row.original.candidateid)}
              onClick={(e) => e.stopPropagation()}
              onChange={(e) =>
                handleCheckboxChange(row.original.candidateid, e.target.checked)
              }
              aria-label={`Select candidate ${row.original.candidateid}`}
            />
          ),
          enableSorting: false,
          size: 40,
        },
        {
          accessorKey: "designation",
          header: () => (
            <span className="p-1 md:p-2 text-left text-xs font-semibold uppercase tracking-wider">
              Designation
            </span>
          ),
          cell: ({ row }) => (
            <p className="p-1 md:p-2 whitespace-nowrap">
              {row.original?.designation ?? "N/A"}
            </p>
          ),
        },
        {
          accessorKey: "education",
          header: () => (
            <span className="p-1 md:p-2 text-left text-xs font-semibold uppercase tracking-wider">
              Education
            </span>
          ),
          cell: ({ row }) => (
            <p className="p-1 md:p-2 whitespace-nowrap">
              {row.original?.education ?? "N/A"}
            </p>
          ),
        },
        {
          accessorKey: "experience",
          header: () => (
            <span className="p-1 md:p-2 text-left text-xs font-semibold uppercase tracking-wider">
              Experience
            </span>
          ),
          cell: ({ row }) => (
            <p className="p-1 md:p-2 whitespace-nowrap">
              {row.original?.experience ?? "N/A"}
            </p>
          ),
        },
        {
          accessorKey: "salaryexpected",
          header: () => (
            <span className="p-1 md:p-2 text-left text-xs font-semibold uppercase tracking-wider">
              Expected Salary
            </span>
          ),
          cell: ({ row }) => (
            <p className="p-1 md:p-2 whitespace-nowrap">
              {row.original?.salaryexpected ?? "N/A"}
            </p>
          ),
          // If you want numeric sorting, convert in a custom sortingFn
        },
        {
          accessorKey: "nationality",
          header: () => (
            <span className="p-1 md:p-2 text-left text-xs font-semibold uppercase tracking-wider">
              Nationality
            </span>
          ),
          cell: ({ row }) => (
            <p className="p-1 md:p-2 whitespace-nowrap">
              {row.original?.nationality ?? "N/A"}
            </p>
          ),
        },
      ];
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selectedCandidates]);

    const table = useReactTable({
      data: applications,
      columns,
      state: { sorting },
      onSortingChange: setSorting,
      getCoreRowModel: getCoreRowModel(),
      getSortedRowModel: getSortedRowModel(),
    });
    // ----------------------------------------

    return (
      <div className="bg-white rounded-md border border-gray-100 shadow-sm flex flex-col overflow-hidden h-full">
        <div className="overflow-x-auto">
          <table className="min-w-full table-fixed overflow-auto">
            <thead className="btn-primary text-white sticky top-0 ">
              {table.getHeaderGroups().map((hg) => (
                <tr key={hg.id}>
                  {hg.headers.map((header) => (
                    <th
                      key={header.id}
                      className="p-1 md:p-2 text-left text-xs font-semibold uppercase tracking-wider"
                    >
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                    </th>
                  ))}
                </tr>
              ))}
            </thead>

            <tbody className="divide-y divide-gray-100 text-xs">
              {table.getRowModel().rows.map((row) => (
                <tr
                  key={(row.original as Candidates).candidateid}
                  onClick={() => {
                    setShowProfile(true);
                    setSelectedUserId(
                      (row.original as Candidates)?.candidateid
                    );
                  }}
                  className="hover:bg-gray-50 transition-colors duration-150 cursor-pointer"
                  role="row"
                  aria-selected={
                    selectedCandidates.includes(
                      (row.original as Candidates).candidateid
                    )
                      ? "true"
                      : "false"
                  }
                >
                  {row.getVisibleCells().map((cell) => (
                    <td key={cell.id} className="p-1 md:p-2 whitespace-nowrap">
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {applications?.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-8 ">
            <p className="text-lg">No applications found</p>
            <p className="text-sm mt-2">Try adjusting your search or filters</p>
          </div>
        ) : null}
      </div>
    );
  };

  return (
    <>
      {/* Table View */}
      {isMatchingCandidateLoading ? (
        <div className="flex items-center justify-center h-full">
          <LoadingSpinner />
        </div>
      ) : isMatchingCandidatesError ? (
        <div className="flex items-center justify-center h-full">
          <div className="text-center bg-red-50 border border-red-200 rounded-md p-4 text-red-700">
            Failed to load jobs: {isMatchingCandidatesError || "Unknown error"}
          </div>
        </div>
      ) : Array.isArray(matchingCandidatesData?.candidates) &&
        matchingCandidatesData.candidates.length > 0 ? (
        <ApplicationTable
          applications={matchingCandidatesData?.candidates}
          currentPage={currentPage}
        />
      ) : (
        <div className="flex flex-col items-center justify-center p-12 ">
          <Search className="h-12 w-12 text-gray-400 mb-2" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            No Jobs found
          </h3>
        </div>
      )}

      {totalPages > 1 && (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={setCurrentPage}
        />
      )}

      {/* Export Button - Only visible when candidates are selected */}
      {selectedCandidates.length > 0 && (
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-blue-800">
              {selectedCandidates.length} candidate
              {selectedCandidates.length > 1 ? "s" : ""} selected
            </span>
          </div>
          <button
            onClick={handleExportToShiphire}
            className="flex items-center cursor-pointer gap-2 px-4 py-2 text-sm font-medium text-white btn-primary hover:bg-blue-700 rounded-md transition-colors"
            aria-label="Export selected candidates to Shiphire"
          >
            <Download className="h-4 w-4" />
            Export to Shiphire
          </button>
        </div>
      )}

      {showProfile && selectedUserId !== null && (
        <SeafarerProfile
          userId={selectedUserId}
          onClose={() => setShowProfile(false)}
          isOpen={showProfile}
        />
      )}
    </>
  );
};
