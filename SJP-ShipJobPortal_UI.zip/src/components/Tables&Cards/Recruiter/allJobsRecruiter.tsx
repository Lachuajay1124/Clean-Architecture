"use client";

import React, { useMemo, useState } from "react";
import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  getSortedRowModel,
  SortingState,
  useReactTable,
} from "@tanstack/react-table";

import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";
import { JobModal } from "@/components/common/Layout/Modal/RecruiterModal/JobCrud/job";
import { useDeleteJob } from "@/components/common/Layout/Modal/RecruiterModal/JobCrud/JobApi";
import { RecruiterJobViewCard } from "@/components/common/Layout/Modal/RecruiterModal/jobViewCard/jobViewCard";
import { Pagination } from "@/components/common/Layout/Pagination/pagination";
import { useAllJobPostedByRecruiter } from "@/hooks/listingHooks/useListingHooks";
import { sanitizeInput } from "@/lib/validation";
import { useJobFilterStore } from "@/store/useFilterStore";
import { useSearchStore } from "@/store/useSearchStore";
import { Job } from "@/types/getApiTypes";
import {
  Briefcase,
  Calendar,
  Eye,
  MapPin,
  Pencil,
  Plus,
  Ship,
  Trash2,
  User,
  ArrowUpDown,
} from "lucide-react";

// Empty state
const EmptyState = ({ onCreateJob }: { onCreateJob: () => void }) => (
  <div className="flex flex-col items-center justify-center py-10 px-4 h-full">
    <div className="relative mb-2">
      <div className="w-12 h-12 bg-gradient-to-br from-blue-50 to-indigo-100 rounded-md flex items-center justify-center">
        <Briefcase size={16} className="text-blue-500" />
      </div>
    </div>
    <h3 className="text-md font-bold text-gray-900 mb-2" id="no-jobs-heading">
      No jobs posted yet
    </h3>
    <p className="text-gray-500 text-sm text-center max-w-md mb-6 leading-relaxed">
      Create your first job posting and start attracting top talent to your
      organization.
    </p>
    <button
      onClick={onCreateJob}
      className="text-sm group btn-primary cursor-pointer hover:from-blue-700 hover:to-indigo-700 text-white px-8 py-2 rounded-md font-semibold transition-all duration-300 transform hover:scale-105 hover:shadow-lg shadow-md flex items-center gap-2"
      aria-label="Create your first job posting"
    >
      <Plus
        size={16}
        className="group-hover:rotate-90 transition-transform duration-300"
      />
      Create Your First Job
    </button>
  </div>
);

const AllJobsRecruiter = () => {
  const { searchValue } = useSearchStore();
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [showKnowJobModal, setShowKnowJobModal] = useState(false);
  const [showCreateJobModal, setShowCreateJobModal] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  const { positionId, vesselTypeId, locationId, durationId } =
    useJobFilterStore();

  const deleteJobMutation = useDeleteJob(() => {
    setSelectedJob(null);
  });

  const handleCloseModal = () => {
    setSelectedJob(null);
    setShowKnowJobModal(false);
  };

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      });
    } catch {
      return "Invalid Date";
    }
  };

  const handleEditJob = (job: Job) => {
    setShowCreateJobModal(true);
    setSelectedJob(job);
  };

  const handleViewJob = (job: Job) => {
    setSelectedJob(job);
    setShowKnowJobModal(true);
  };

  const handleCloseCreateJobModal = () => {
    setShowCreateJobModal(false);
    setSelectedJob(null);
  };

  const {
    data: jobs,
    isLoading,
    error,
  } = useAllJobPostedByRecruiter({
    searchKey: sanitizeInput(searchValue),
    pageNumber: currentPage,
    positionId,
    vesselTypeId,
    locationId,
    durationId,
    companyId: 1,
  });

  const totalPages = jobs?.pagination?.totalPages ?? 1;
  const totalItems = jobs?.pagination?.totalItems ?? 0;

  const handleDelete = (jobId: number) => {
    if (!jobId) return;
    if (confirm("Are you sure you want to delete this job?")) {
      deleteJobMutation.mutate({ jobId });
    }
  };

  const handleCreateJob = () => {
    setShowCreateJobModal(true);
    setSelectedJob(null);
  };

  // ---------- TanStack (sorting only) ----------
  const data = Array.isArray(jobs?.jobsList) ? jobs!.jobsList : [];

  const [sorting, setSorting] = useState<SortingState>([
    { id: "openDate", desc: false },
  ]);

  const columns = useMemo<ColumnDef<Job>[]>(() => {
    return [
      {
        id: "rowIndex",
        header: () => <span>id</span>,
        cell: ({ row }) => (
          <div className="text-[10px] md:text-xs font-normal text-gray-900">
            {row.index}
          </div>
        ),
        enableSorting: false, // mirrors your index column (not jobId)
      },
      {
        accessorKey: "position",
        header: ({ column }) => (
          <button
            className="flex items-center gap-1 font-semibold"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            aria-label="Sort by Position"
          >
            Position <ArrowUpDown className="h-3.5 w-3.5" />
          </button>
        ),
        cell: ({ row }) => (
          <div className="text-[10px] md:text-xs font-normal text-gray-900">
            {row.original.position || "N/A"}
          </div>
        ),
      },
      {
        accessorKey: "nationality",
        header: ({ column }) => (
          <button
            className="flex items-center gap-1 font-semibold"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            aria-label="Sort by Nationality"
          >
            Nationality <ArrowUpDown className="h-3.5 w-3.5" />
          </button>
        ),
        cell: ({ row }) => (
          <div className="text-[10px] md:text-xs font-normal flex items-center gap-2 text-gray-600">
            <MapPin
              size={14}
              className="text-gray-400 flex-shrink-0 hidden md:block"
            />
            <span className="truncate">
              {row.original.nationality || "N/A"}
            </span>
          </div>
        ),
      },
      {
        accessorKey: "vesselType",
        header: ({ column }) => (
          <button
            className="flex items-center gap-1 font-semibold"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            aria-label="Sort by Vessel Type"
          >
            Vessel Type <ArrowUpDown className="h-3.5 w-3.5" />
          </button>
        ),
        cell: ({ row }) => (
          <div className="flex items-center gap-2 text-gray-600 text-[10px] md:text-xs font-normal">
            <Ship
              size={14}
              className="text-gray-400 flex-shrink-0 hidden md:block"
            />
            <span className="truncate">{row.original.vesselType || "N/A"}</span>
          </div>
        ),
      },
      {
        accessorKey: "openDate",
        header: ({ column }) => (
          <button
            className="flex items-center gap-1 font-semibold"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            aria-label="Sort by Open Date"
          >
            Open Date <ArrowUpDown className="h-3.5 w-3.5" />
          </button>
        ),
        cell: ({ row }) => (
          <div className="flex items-center gap-2 text-gray-600 text-[10px] md:text-xs font-normal">
            <Calendar
              size={14}
              className="text-gray-400 flex-shrink-0 hidden md:block"
            />
            <span>{formatDate(row.original.openDate)}</span>
          </div>
        ),
        sortingFn: (a, b) => {
          const da = new Date(a.original.openDate).getTime();
          const db = new Date(b.original.openDate).getTime();
          return da === db ? 0 : da > db ? 1 : -1;
        },
      },
      {
        accessorKey: "closeDate",
        header: ({ column }) => (
          <button
            className="flex items-center gap-1 font-semibold"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            aria-label="Sort by Close Date"
          >
            Close Date <ArrowUpDown className="h-3.5 w-3.5" />
          </button>
        ),
        cell: ({ row }) => (
          <div className="flex items-center gap-2 text-gray-600 text-[10px] md:text-xs font-normal">
            <Calendar
              size={14}
              className="text-gray-400 flex-shrink-0 hidden md:block"
            />
            <span>{formatDate(row.original.closeDate)}</span>
          </div>
        ),
        sortingFn: (a, b) => {
          const da = new Date(a.original.closeDate).getTime();
          const db = new Date(b.original.closeDate).getTime();
          return da === db ? 0 : da > db ? 1 : -1;
        },
      },
      {
        accessorKey: "noVacancy",
        header: ({ column }) => (
          <button
            className="flex items-center gap-1 font-semibold"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            aria-label="Sort by No Of Vacancy"
          >
            No Of Vacancy <ArrowUpDown className="h-3.5 w-3.5" />
          </button>
        ),
        cell: ({ row }) => (
          <div className="flex items-center gap-2 text-gray-600 text-[10px] md:text-xs font-normal">
            <User
              size={14}
              className="text-gray-400 flex-shrink-0 hidden md:block"
            />
            <span>{row.original.noVacancy}</span>
          </div>
        ),
      },
      {
        // You had a column labeled "industry" but rendering vesselType again—kept identical
        id: "industry",
        header: ({ column }) => (
          <button
            className="flex items-center gap-1 font-semibold"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            aria-label="Sort by industry"
          >
            industry <ArrowUpDown className="h-3.5 w-3.5" />
          </button>
        ),
        sortingFn: "alphanumeric",
        cell: ({ row }) => (
          <div className="flex items-center gap-2 text-gray-600 text-[10px] md:text-xs font-normal">
            <Ship
              size={14}
              className="text-gray-400 flex-shrink-0 hidden md:block"
            />
            <span className="truncate">{row.original.vesselType || "N/A"}</span>
          </div>
        ),
      },
      {
        id: "actions",
        header: () => <span>Actions</span>,
        cell: ({ row }) => (
          <div className="flex items-center justify-between gap-1 md:gap-2">
            <button
              onClick={() => handleViewJob(row.original)}
              className="p-1 cursor-pointer text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-all duration-200 hover:scale-110"
              title="View job details"
              aria-label="View job details"
            >
              <Eye size={14} className="text-green-600" />
            </button>
            <button
              onClick={() => handleEditJob(row.original)}
              className="p-1 cursor-pointer text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-md transition-all duration-200 hover:scale-110"
              title="Edit job"
              aria-label="Edit job posting"
            >
              <Pencil size={14} className="text-blue-900" />
            </button>
            <button
              onClick={() => handleDelete(row.original.jobId)}
              className="p-1 cursor-pointer text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-md transition-all duration-200 hover:scale-110"
              title="Delete job"
              aria-label="Delete job posting"
            >
              <Trash2 size={14} color="red" />
            </button>
          </div>
        ),
        enableSorting: false,
      },
    ];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const table = useReactTable({
    data,
    columns,
    state: { sorting },
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
  });
  // --------------------------------------------

  return (
    <>
      {/* Create Job CTA */}
      <div className="flex justify-between items-center">
        <div className="flex gap-2">
          <h2
            className="text-md font-semibold primary-text"
            id="jobs-posted-heading"
          >
            Jobs Posted
          </h2>
          <span className="px-2 bg-blue-100 text-blue-700 rounded-full">
            {totalItems} active
          </span>
        </div>

        <button
          onClick={handleCreateJob}
          className="col-span-1 group flex justify-between items-center gap-2 btn-primary cursor-pointer hover:scale-110 duration-200 transition-all text-sm p-1 px-2 rounded-md"
          aria-label="Create new job posting"
        >
          <Plus
            size={14}
            className="group-hover:rotate-90 transition-transform duration-300"
          />
          Job
        </button>
      </div>

      {/* Jobs Content */}
      {isLoading ? (
        <LoadingSpinner />
      ) : jobs?.jobsList?.length == 0 ? (
        <EmptyState onCreateJob={handleCreateJob} />
      ) : error ? (
        <div
          className="flex justify-center items-center min-h-[400px]"
          aria-live="polite"
        >
          <div className="text-center">
            <h3 className="text-lg font-semibold text-red-600 mb-2">
              Error loading jobs
            </h3>
            <p className="text-gray-500">Please try again later</p>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-md border border-gray-100 shadow-sm flex flex-col overflow-hidden h-full">
          <div className="overflow-x-auto">
            <table className="min-w-full table-fixed overflow-auto">
              <thead className="btn-primary text-white sticky top-0 z-10">
                {table.getHeaderGroups().map((hg) => (
                  <tr key={hg.id}>
                    {hg.headers.map((header) => (
                      <th
                        key={header.id}
                        className="p-1 md:p-2 text-left text-[10px] md:text-xs font-normal md:font-semibold uppercase tracking-wider"
                        scope="col"
                      >
                        {header.isPlaceholder
                          ? null
                          : flexRender(
                              header.column.columnDef.header,
                              header.getContext()
                            )}
                      </th>
                    ))}
                  </tr>
                ))}
              </thead>

              <tbody className="divide-y divide-gray-100 text-xs">
                {table.getRowModel().rows.map((row) => (
                  <tr
                    key={row.original.jobId}
                    className="group hover:bg-blue-50/50 transition-all duration-200"
                    aria-label={`Job posting for ${row.original.position}`}
                  >
                    {row.getVisibleCells().map((cell) => (
                      <td key={cell.id} className="p-1 md:p-2">
                        {flexRender(
                          cell.column.columnDef.cell,
                          cell.getContext()
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            />
          )}
        </div>
      )}

      <RecruiterJobViewCard
        job={selectedJob}
        onClose={handleCloseModal}
        isOpen={showKnowJobModal}
        aria-labelledby="job-details-modal"
      />

      <JobModal
        isOpen={showCreateJobModal}
        onClose={() => handleCloseCreateJobModal()}
        job={selectedJob}
      />
    </>
  );
};

export default AllJobsRecruiter;
