"use client";

import useFCM from "@/hooks/Firebase/UseFCM";

const FCMLogicOnly = () => {
  useFCM();
  return null;
};

export default FCMLogicOnly;
