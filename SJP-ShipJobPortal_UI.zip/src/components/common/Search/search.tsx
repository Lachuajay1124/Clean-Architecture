"use client";

import React, { useEffect, useRef, useState } from "react";
import { Search } from "lucide-react";

interface SearchInputProps {
  value: string;
  onDebouncedChange: (value: string) => void;
  placeholder?: string;
  delay?: number;
}

export const SearchInput: React.FC<SearchInputProps> = ({
  value,
  onDebouncedChange,
  placeholder = "Search...",
  delay = 500,
}) => {
  const [localValue, setLocalValue] = useState(value);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    timeoutRef.current = setTimeout(() => {
      onDebouncedChange(localValue);
    }, delay);

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [localValue, onDebouncedChange, delay]);

  return (
    <div className="relative">
      <Search
        className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
        size={18}
        aria-hidden="true" // Hide from screen readers as it's a decorative icon
      />
      <input
        type="text"
        value={localValue}
        onChange={(e) => setLocalValue(e.target.value)}
        placeholder={placeholder}
        className="pl-10 pr-2 w-full py-1 bg-white border border-gray-200 rounded-md focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all duration-300 shadow-lg hover:shadow-xl"
        aria-label="Search input"
        aria-live="polite"
      />
      {localValue !== value && (
        <div
          className="absolute right-4 top-1/2 -translate-y-1/2"
          role="status"
          aria-live="assertive"
          aria-label="Loading results"
        >
          <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
        </div>
      )}
    </div>
  );
};
