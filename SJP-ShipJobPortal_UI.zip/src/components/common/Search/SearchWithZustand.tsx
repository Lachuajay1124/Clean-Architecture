"use client";

import React, { useEffect, useRef, useState } from "react";
import { usePathname } from "next/navigation";

import { Search } from "lucide-react";
import { useSearchStore } from "@/store/useSearchStore"; // { searchValue, setSearchValue }

type SearchInputProps = {
  placeholder?: string;
  delay?: number; // ms
};

export const SearchInputData: React.FC<SearchInputProps> = ({
  placeholder = "Search...",
  delay = 500,
}) => {
  const { searchValue, setSearchValue } = useSearchStore();
  const [localValue, setLocalValue] = useState(searchValue ?? "");
  const pathname = usePathname(); // Detect route changes

  // Browser-safe typing for setTimeout handle:
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Keep input in sync if store changes elsewhere
  useEffect(() => {
    setLocalValue(searchValue ?? "");
  }, [searchValue]);

  // Clear search on every route change
  useEffect(() => {
    setLocalValue("");
    setSearchValue("");
  }, [pathname, setSearchValue]);

  // Debounce commits to the store
  useEffect(() => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);

    timeoutRef.current = setTimeout(() => {
      if (localValue !== searchValue) setSearchValue(localValue);
    }, delay);

    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, [localValue, delay, searchValue, setSearchValue]);

  return (
    <div className="relative w-full">
      <Search
        className="absolute left-3 top-4.5 -translate-y-1/2 text-gray-400"
        size={18}
        aria-hidden="true"
      />
      <input
        type="text"
        value={localValue}
        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
          setLocalValue(e.target.value)
        }
        placeholder={placeholder}
        className="pl-10 pr-2 w-full py-1.5 bg-white border border-gray-200 rounded-md focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all duration-300 shadow-lg hover:shadow-xl"
        aria-label="Search input"
      />
      {localValue !== searchValue && (
        <div
          className="absolute right-4 top-1/2 -translate-y-1/2"
          role="status"
          aria-live="assertive"
          aria-label="Updating search"
        >
          <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
        </div>
      )}
    </div>
  );
};
