import Lottie from "lottie-react";
import jobAnimation from "../../../../../public/lotties/job-animation.json"; // adjust path as needed

const JobAnimation = () => {
  return (
    <div className="w-full max-w-xl mx-auto">
      <Lottie animationData={jobAnimation} loop={true} />
    </div>
  );
};

export default JobAnimation;
