"use client";

// React core
import React, { memo, useCallback, useEffect, useMemo, useState } from "react";

// Next.js
import { usePathname, useRouter } from "next/navigation";

// Styles (side-effect imports)
import "react-responsive-carousel/lib/styles/carousel.min.css";

// External libraries
import Cookies from "js-cookie";
import Select from "react-select";
import { toast } from "react-toastify";

// Internal modules (@ alias)
import { customSelectStyles } from "@/components/common/Select/select";
import { ReferralModal } from "@/components/common/Refer/refer";
import { useReferJob } from "@/hooks/actionHooks/referFriend";
import {
  useAllContractDurationList,
  useAllCountryList,
  useAllPositionList,
  useAllVesselTypesList,
} from "@/hooks/listingHooks/useListingHooks";
import { useJobFilterStore } from "@/store/useFilterStore";

// Relative modules
import AdsBanner from "../Ads/ads";

// Types (type-only)
import type {
  ContractDuration,
  Country,
  Position,
  VesselType,
} from "@/types/listingApiTypes";
import type { ReferJobs } from "@/app/api/jobsApi/types";

// Optimized select component with memo
const FilterSelect = memo<{
  label: string;
  options: { label: string; value: number }[];
  value: number | null;
  isLoading: boolean;
  onChange: (value: number | null) => void;
  error?: boolean;
  errorMessage?: string;
}>(({ label, options, value, isLoading, onChange, error, errorMessage }) => (
  <div className="space-y-1">
    <Select
      placeholder={label}
      options={options}
      isLoading={isLoading}
      value={value ? options.find((o) => o.value === value) ?? null : null}
      styles={customSelectStyles}
      onChange={(opt) => onChange(opt?.value ?? null)}
      className="text-sm"
      menuPortalTarget={document.body}
      aria-label={label}
      isSearchable
      isClearable
    />
    {error && (
      <div className="text-xs text-red-500 flex items-center gap-1">
        <span role="img" aria-label="warning">
          ⚠️
        </span>
        {errorMessage}
      </div>
    )}
  </div>
));

FilterSelect.displayName = "FilterSelect";

const FilterSideBar: React.FC = () => {
  const path = usePathname();
  const router = useRouter();

  const [isModalOpen, setIsModalOpen] = useState(false);

  const userId = useMemo(() => {
    return typeof window !== "undefined"
      ? Number(Cookies.get("userId")) || 0
      : 0;
  }, []);

  const referJobMutation = useReferJob(() => {
    setIsModalOpen(false);
    toast.success("Referral sent successfully! 🎉");
  });

  const handleReferSubmit = useCallback(
    (name: string, email: string) => {
      if (!userId) {
        toast.error("Please log in to refer a friend.");
        return;
      }

      const data: ReferJobs = {
        userId,
        friendEmail: email,
        friendName: name,
      };

      referJobMutation.mutate(data);
    },
    [userId, referJobMutation]
  );

  const {
    positionId,
    vesselTypeId,
    locationId,
    durationId,
    setFilter,
    clearFilters,
  } = useJobFilterStore();

  const { data: countries = [], isLoading: isCountriesLoading } =
    useAllCountryList();
  const { data: contractDuration = [], isLoading: isContractDurationLoading } =
    useAllContractDurationList();
  const { data: vesselTypes = [], isLoading: isVesselTypeLoading } =
    useAllVesselTypesList();
  const { data: positions = [], isLoading: isPositionLoading } =
    useAllPositionList();

  const hasActiveFilters = useMemo(
    () => !!(positionId || vesselTypeId || locationId || durationId),
    [positionId, vesselTypeId, locationId, durationId]
  );

  const pageTitle = useMemo(() => {
    switch (path) {
      case "/candidates/appliedJobs":
        return "Find Your Applied Job";
      case "/candidates/savedJobs":
        return "Find Your Saved Job";
      default:
        return "Find Your Job";
    }
  }, [path]);

  const filterOptions = useMemo(
    () => ({
      positions: positions.map((p: Position) => ({
        label: p.name,
        value: p.id,
      })),
      vesselTypes: vesselTypes.map((v: VesselType) => ({
        label: v.vesseltype,
        value: v.typeID,
      })),
      countries: countries.map((c: Country) => ({
        label: c.countryName,
        value: c.id,
      })),
      durations: contractDuration.map((d: ContractDuration) => ({
        label: d.contractMonths,
        value: d.durationId,
      })),
    }),
    [positions, vesselTypes, countries, contractDuration]
  );

  const filterHandlers = useMemo(
    () => ({
      position: (value: number | null) => setFilter("positionId", value),
      vesselType: (value: number | null) => setFilter("vesselTypeId", value),
      location: (value: number | null) => setFilter("locationId", value),
      duration: (value: number | null) => setFilter("durationId", value),
    }),
    [setFilter]
  );

  useEffect(() => {
    clearFilters();
  }, [path, clearFilters]);

  return (
    <div className="space-y-5 flex flex-col justify-between h-full">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-md font-semibold text-gray-900 flex items-center gap-2">
          🔍 {pageTitle}
        </h1>
        {hasActiveFilters && (
          <button
            onClick={clearFilters}
            className="cursor-pointer p-1 text-[10px] font-medium text-red-600 bg-red-50 rounded-md hover:bg-red-100 transition-colors flex items-center gap-1"
            aria-label="Clear all filters"
          >
            🗑️ Clear
          </button>
        )}
      </div>

      <div className="flex flex-col space-y-3">
        <FilterSelect
          label="🎯 Select Position"
          options={filterOptions.positions}
          value={positionId}
          isLoading={isPositionLoading}
          onChange={filterHandlers.position}
        />

        {positionId && (
          <FilterSelect
            label="📅 Select Experience"
            options={filterOptions.durations}
            value={durationId}
            isLoading={isContractDurationLoading}
            onChange={filterHandlers.duration}
          />
        )}

        <FilterSelect
          label="🚢 Select Vessel"
          options={filterOptions.vesselTypes}
          value={vesselTypeId}
          isLoading={isVesselTypeLoading}
          onChange={filterHandlers.vesselType}
        />

        <FilterSelect
          label="🌍 Select Location"
          options={filterOptions.countries}
          value={locationId}
          isLoading={isCountriesLoading}
          onChange={filterHandlers.location}
        />
      </div>

      <ReferralModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleReferSubmit}
        isLoading={referJobMutation.isPending}
      />
      <button
        onClick={() => setIsModalOpen(true)}
        className="w-full p-1 text-sm font-bold btn-primary cursor-pointer text-white rounded-md hover:from-purple-700 hover:via-pink-700 hover:to-red-700 transform hover:scale-[1.02] transition-all duration-200 flex items-center justify-center gap-2 shadow-lg"
        aria-label="Refer a friend"
      >
        <span className="animate-bounce text-sm">🎁</span>
        <span>Refer a Friend</span>
        <span className="animate-pulse text-sm">✨</span>
      </button>

      <AdsBanner />

      <button
        onClick={() => router.push("/candidates/profilePage")}
        className="btn-primary p-1 cursor-pointer rounded-md hover:bg-white/30 transition text-black"
        aria-label="User Profile"
      >
        <h1 className="text-md font-semibold text-white justify-center flex items-center gap-2">
          Profile
        </h1>
      </button>
    </div>
  );
};

export default FilterSideBar;
