import React from "react";
import FilterSideBar from "./FilterSideBar";
import { Suspense } from "react";
import { LoadingSpinner } from "../../Loader/loader";

const CandidateSidebar: React.FC = () => {
  return (
    <aside
      className="p-2 h-full flex flex-col justify-between text-black bg-white/50 rounded-md shadow-md "
      aria-labelledby="sidebar-section"
    >
      <Suspense fallback={<LoadingSpinner />}>
        <FilterSideBar aria-label="Filters sidebar" />
      </Suspense>{" "}
    </aside>
  );
};

export default CandidateSidebar;
