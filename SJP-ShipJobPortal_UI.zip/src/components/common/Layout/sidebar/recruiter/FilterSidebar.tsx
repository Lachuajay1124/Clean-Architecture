"use client";

// React core
import React, { memo, useEffect, useMemo } from "react";

// Next.js
import { usePathname, useRouter } from "next/navigation";

// Styles (side-effect)
import "react-responsive-carousel/lib/styles/carousel.min.css";

// External libraries
import Select from "react-select";

// Internal modules (@ alias)
import { customSelectStyles } from "@/components/common/Select/select";
import {
  useAllCountryList,
  useAllPositionList,
  useAllVesselTypesList,
} from "@/hooks/listingHooks/useListingHooks";
import { useJobFilterStore } from "@/store/useFilterStore";

// Relative modules
import AdsBanner from "../Ads/ads";

// Types (type-only)
import type { Country, Position, VesselType } from "@/types/listingApiTypes";

const FilterSelect = memo<{
  label: string;
  options: { label: string; value: number }[];
  value: number | null;
  isLoading: boolean;
  onChange: (value: number | null) => void;
  error?: boolean;
  errorMessage?: string;
}>(({ label, options, value, isLoading, onChange, error, errorMessage }) => (
  <div className="space-y-1">
    <Select
      placeholder={label}
      options={options}
      isLoading={isLoading}
      value={value ? options.find((o) => o.value === value) ?? null : null}
      styles={customSelectStyles}
      onChange={(opt) => onChange(opt?.value ?? null)}
      className="text-sm"
      menuPortalTarget={document.body}
      aria-label={label}
      isSearchable
      isClearable
    />
    {error && (
      <div className="text-xs text-red-500 flex items-center gap-1">
        <span>⚠️</span>
        {errorMessage}
      </div>
    )}
  </div>
));

FilterSelect.displayName = "FilterSelect";

const FilterSideBar: React.FC = () => {
  const path = usePathname();
  const router = useRouter();

  const {
    positionId,
    vesselTypeId,
    locationId,
    durationId,
    setFilter,
    clearFilters,
  } = useJobFilterStore();

  // API hooks
  const {
    data: countries = [],
    isLoading: isCountriesLoading,
    isError: countriesError,
  } = useAllCountryList();

  const {
    data: vesselTypes = [],
    isLoading: isVesselTypeLoading,
    isError: vesselTypesError,
  } = useAllVesselTypesList();

  const {
    data: positions = [],
    isLoading: isPositionLoading,
    isError: positionsError,
  } = useAllPositionList();

  // Memoized computed values
  const hasActiveFilters = useMemo(
    () => !!(positionId || vesselTypeId || locationId || durationId),
    [positionId, vesselTypeId, locationId, durationId]
  );

  const pageTitle = useMemo(() => {
    switch (path) {
      case "/recruiters/appliedCandidates":
        return "Applied Candidates";
      case "/recruiters/matchingCandidates":
        return "Matching Candidates";
      case "/recruiters/myAdvertisement":
        return "Find Your Ads";
      default:
        return "Find Your Candidates";
    }
  }, [path]);

  // Memoized options
  const filterOptions = useMemo(
    () => ({
      positions: positions.map((p: Position) => ({
        label: p.name,
        value: p.id,
      })),
      vesselTypes: vesselTypes.map((v: VesselType) => ({
        label: v.vesseltype,
        value: v.typeID,
      })),
      countries: countries.map((c: Country) => ({
        label: c.countryName,
        value: c.id,
      })),
    }),
    [positions, vesselTypes, countries]
  );

  // Memoized filter handlers
  const filterHandlers = useMemo(
    () => ({
      position: (value: number | null) => setFilter("positionId", value),
      vesselType: (value: number | null) => setFilter("vesselTypeId", value),
      location: (value: number | null) => setFilter("locationId", value),
      duration: (value: number | null) => setFilter("durationId", value),
    }),
    [setFilter]
  );

  // Clear filters when path changes
  useEffect(() => {
    clearFilters();
  }, [path, clearFilters]);

  return (
    <div className="space-y-5 flex flex-col justify-between h-full">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-md font-semibold text-gray-900 flex items-center gap-2">
          🔍 {pageTitle}
        </h1>
        {hasActiveFilters && (
          <button
            onClick={clearFilters}
            className="cursor-pointer px-2 py-1 text-[10px] font-medium text-red-600 bg-red-50 rounded-md hover:bg-red-100 transition-colors flex items-center gap-1"
          >
            🗑️ Clear All
          </button>
        )}
      </div>

      {/* Filter Selects */}
      <div className="flex flex-col space-y-2">
        <FilterSelect
          label="🎯 Select Position"
          options={filterOptions.positions}
          value={positionId}
          isLoading={isPositionLoading}
          onChange={filterHandlers.position}
          error={positionsError}
          errorMessage="Failed to load positions"
        />

        <FilterSelect
          label="🚢 Select Vessel"
          options={filterOptions.vesselTypes}
          value={vesselTypeId}
          isLoading={isVesselTypeLoading}
          onChange={filterHandlers.vesselType}
          error={vesselTypesError}
          errorMessage="Failed to load vessel types"
        />

        <FilterSelect
          label="🌍 Select Nationality"
          options={filterOptions.countries}
          value={locationId}
          isLoading={isCountriesLoading}
          onChange={filterHandlers.location}
          error={countriesError}
          errorMessage="Failed to load locations"
        />
      </div>
      <AdsBanner />

      <button
        onClick={() => router.push("/recruiters/companyProfile")}
        className="btn-primary p-1 font-bold text-sm cursor-pointer rounded-md hover:bg-white/30 transition text-black"
        aria-label="Company Profile"
      >
        <h1 className="text-md font-semibold text-white justify-center flex items-center gap-2">
          Profile
        </h1>
      </button>
    </div>
  );
};

export default FilterSideBar;
