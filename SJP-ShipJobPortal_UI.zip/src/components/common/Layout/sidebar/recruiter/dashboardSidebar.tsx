import React, { Suspense } from "react";
import FilterSidebarForRecruiter from "./FilterSidebar";
import { LoadingSpinner } from "../../Loader/loader";

const CandidateSidebar: React.FC = () => {
  return (
    <aside
      aria-labelledby="sidebar-section"
      className="p-2 h-full flex flex-col justify-between overflow-hidden text-black bg-white/50 rounded-md shadow-md "
    >
      <Suspense fallback={<LoadingSpinner />}>
        <FilterSidebarForRecruiter aria-label="Filters sidebar" />
      </Suspense>
    </aside>
  );
};

export default CandidateSidebar;
