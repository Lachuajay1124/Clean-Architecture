import React from "react";

const AdsBanner = () => {
  return (
    <div className="bg-white h-full justify-between flex flex-col items-center space-y-3 rounded-md shadow-md border-2 border-dashed border-gray-300 hover:border-blue-400 transition-all duration-300 p-2">
      {/* Header */}

      <h2 className="text-lg text-center font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
        Premium Ad Space
      </h2>

      <p className="text-center text-gray-600 text-sm max-w-md mx-auto">
        Bringing seafarers and recruiters together to unlock global maritime
        opportunities
      </p>
      {/* Call to Action */}
      <div className="text-center">
        <button className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-1 rounded-md font-semibold text-sm shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-300">
          Advertise Here
        </button>
      </div>
    </div>
  );
};

export default AdsBanner;
