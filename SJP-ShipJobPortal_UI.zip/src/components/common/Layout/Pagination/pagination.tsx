import React from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

export const Pagination: React.FC<PaginationProps> = ({
  currentPage,
  totalPages,
  onPageChange,
}) => {
  const visiblePages = 5;
  const startPage = Math.max(
    1,
    Math.min(
      currentPage - Math.floor(visiblePages / 2),
      totalPages - visiblePages + 1
    )
  );
  const endPage = Math.min(totalPages, startPage + visiblePages - 1);

  return (
    <div className="flex justify-between text-xs items-center p-1">
      {/* Previous */}
      <button
        disabled={currentPage === 1}
        onClick={() => onPageChange(currentPage - 1)}
        className="group flex items-center gap-2 hover:-translate-x-1 focus:outline-none focus:ring-2 focus:ring-blue-500/20 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:transform-none transition-all duration-200"
        title="Go to previous page"
      >
        <ChevronLeft
          size={16}
          className="group-hover:-translate-x-1 transition-transform duration-200"
        />
        Previous
      </button>

      {/* Page Numbers */}
      <div className="flex items-center space-x-2 ">
        {/* Desktop */}
        <div className="hidden sm:flex items-center space-x-1">
          {Array.from({ length: endPage - startPage + 1 }, (_, i) => {
            const pageNum = startPage + i;
            return (
              <button
                key={pageNum}
                onClick={() => onPageChange(pageNum)}
                className={`w-6 h-6 flex items-center justify-center font-medium rounded-md transition-all duration-200 ${
                  pageNum === currentPage
                    ? "btn-primary text-white scale-110"
                    : "hover:bg-white/80 hover:shadow-lg hover:scale-105"
                }`}
                title={`Go to page ${pageNum}`}
              >
                {pageNum}
              </button>
            );
          })}
        </div>

        {/* Mobile */}
        <div className="sm:hidden bg-white/80 px-2 rounded-md border border-gray-200 shadow-sm">
          <span className="font-medium text-gray-900">{currentPage}</span>
          <span className="text-gray-500 mx-2">of</span>
          <span className="font-medium text-gray-900">{totalPages}</span>
        </div>
      </div>

      {/* Next */}
      <button
        disabled={currentPage >= totalPages}
        onClick={() => onPageChange(currentPage + 1)}
        className="group flex items-center gap-2 text-xs hover:translate-x-1 focus:outline-none focus:ring-2 focus:ring-blue-500/20 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:transform-none transition-all duration-200"
        title="Go to next page"
      >
        Next
        <ChevronRight
          size={16}
          className="group-hover:translate-x-1 transition-transform duration-200"
        />
      </button>
    </div>
  );
};
