import React from "react";

export const LoadingSpinner = () => {
  return (
    <div
      className="flex justify-center items-center min-h-[300px]"
      role="status" // Role to indicate an ongoing status
      aria-live="polite" // Live region to notify screen readers politely
    >
      <div className="relative">
        <div
          className="w-10 h-10 border-4 border-blue-100 border-solid rounded-full animate-spin"
          aria-hidden="true" // Hide from screen readers as it is decorative
        />
        <div
          className="absolute top-0 left-0 w-10 h-10 border-4 border-t-blue-600 border-solid rounded-full animate-spin"
          aria-hidden="true" // Hide from screen readers as it is decorative
        />
      </div>
      <span className="sr-only">Loading...</span>{" "}
    </div>
  );
};
