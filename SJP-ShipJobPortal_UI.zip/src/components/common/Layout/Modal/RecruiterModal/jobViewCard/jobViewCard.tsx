import React from "react";
import Modal from "react-modal";
import {
  Building2,
  Calendar,
  Eye,
  FileText,
  ListChecks,
  MapPin,
  Ship,
  UserCheck,
  Users,
  X,
} from "lucide-react";

// type-only
import type { ForwardRefExoticComponent, RefAttributes } from "react";
import type { LucideProps } from "lucide-react";
import type { Job } from "@/types/getApiTypes";

interface Props {
  job: Job | null;
  onClose: () => void;
  isOpen: boolean;
  onEdit?: () => void;
  onShare?: () => void;
}

export const RecruiterJobViewCard: React.FC<Props> = ({
  job,
  onClose,
  isOpen,
  onEdit,
}) => {
  if (!isOpen || !job) return null;

  const fmtDate = (val?: string) => {
    if (!val) return "Not specified";
    const d = new Date(val);
    return isNaN(d.getTime())
      ? "Not specified"
      : d.toLocaleDateString("en-GB", {
          day: "2-digit",
          month: "short",
          year: "numeric",
        });
  };

  const InfoCard = ({
    icon: Icon,
    label,
    value,
    className = "",
  }: {
    icon: ForwardRefExoticComponent<
      Omit<LucideProps, "ref"> & RefAttributes<SVGSVGElement>
    >;
    label: string;
    value: string | number | null | undefined;
    className?: string;
  }) => (
    <div
      className={`bg-white rounded-md p-2 border border-gray-100 shadow-sm hover:shadow-lg transition-shadow ${className}`}
    >
      <div className="flex items-center gap-2">
        <div className="p-2 bg-blue-50 rounded-md">
          <Icon size={18} className="text-blue-600" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-medium text-gray-500">{label}</p>
          <p className="font-semibold text-gray-900 truncate text-sm">
            {value ?? "Not specified"}
          </p>
        </div>
      </div>
    </div>
  );

  return (
    <Modal
      isOpen={isOpen}
      ariaHideApp={false}
      onRequestClose={onClose}
      shouldCloseOnEsc
      shouldCloseOnOverlayClick
      style={{
        overlay: {
          backgroundColor: "rgba(0, 0, 0, 0.8)",
          zIndex: 50,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: "8px",
        },
        content: {
          position: "relative",
          inset: "auto",
          width: "100%",
          maxWidth: "1000px",
          height: "80vh",
          padding: "0",
          border: "none",
          borderRadius: "8px",
          overflow: "hidden",
        },
      }}
      aria-labelledby="job-details-title"
      aria-describedby="job-details-description"
    >
      <div className="flex flex-col justify-between h-full overflow-auto text-xs">
        {/* Header */}
        <div className="flex items-center justify-between gap-2 p-3 btn-primary">
          <h2
            id="job-details-title"
            className="text-lg font-semibold text-white leading-tight"
          >
            {job.jobTitle ?? `Position #${job.positionId}`}
          </h2>

          <div className="flex items-center gap-2">
            <Building2 size={14} className="text-white/80" />
            <p className="text-blue-100 text-sm" aria-label="Company">
              {job.company ?? `Company #${job.companyId}`}
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 cursor-pointer rounded-full bg-white/10 hover:bg-white/20 transition-all duration-200 hover:scale-105 z-10"
            aria-label="Close job details"
          >
            <X size={18} className="text-white hover:text-red-500" />
          </button>
        </div>

        {/* Main Content */}
        <div className="flex-1 h-full overflow-y-auto bg-gray-50">
          {/* Analytics */}
          <div className="bg-gray-50 p-2">
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-white rounded-md p-2 text-center shadow-md">
                <div className="flex items-center justify-center mb-2">
                  <Eye size={16} className="text-blue-600" />
                </div>
                <p className="text-lg font-bold text-gray-900">
                  {job.viewcount ?? 0}
                </p>
                <p className="text-xs text-black">Total Views</p>
              </div>
              <div className="bg-white rounded-md p-2 text-center shadow-md">
                <div className="flex items-center justify-center mb-2">
                  <UserCheck size={16} className="text-green-600" />
                </div>
                <p className="text-lg font-bold ">{job.appliedcount ?? 0}</p>
                <p className="text-xs ">Applications</p>
              </div>
            </div>
          </div>

          <div className="p-3 space-y-4">
            {/* Key Information */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              <InfoCard
                icon={MapPin}
                label="Nationality"
                value={job.nationality ?? `#${job.nationalityId}`}
              />

              <InfoCard
                icon={Ship}
                label="Vessel Type"
                value={job.vesselType ?? `#${job.vesselTypeId}`}
              />
              <InfoCard icon={Users} label="Vacancies" value={job.noVacancy} />
            </div>

            {/* Timeline */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
              <div className="bg-white rounded-md p-3 border border-gray-100 shadow-sm">
                <h3 className="text-sm font-semibold text-gray-900 mb-2 flex items-center gap-2">
                  <Calendar size={16} />
                  Timeline
                </h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center py-1 border-b border-gray-100">
                    <span className="text-gray-600 font-medium text-xs">
                      Opening Date
                    </span>
                    <span className="font-semibold text-gray-900 text-xs">
                      {fmtDate(job.openDate)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center py-1">
                    <span className="text-gray-600 font-medium text-xs">
                      Closing Date
                    </span>
                    <span className="font-semibold text-gray-900 text-xs">
                      {fmtDate(job.closeDate)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Quick Facts */}
              <div className="bg-white rounded-md p-3 border border-gray-100 shadow-sm">
                <h3 className="text-sm font-semibold text-gray-900 mb-2 flex items-center gap-2">
                  <ListChecks size={16} />
                  Quick Facts
                </h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center py-1">
                    <span className="text-gray-600 font-medium text-xs">
                      Job ID
                    </span>
                    <span className="font-semibold text-gray-900 text-xs">
                      {job.jobId}
                    </span>
                  </div>
                  <div className="flex justify-between items-center py-1">
                    <span className="text-gray-600 font-medium text-xs">
                      Position
                    </span>
                    <span className="font-semibold text-gray-900 text-xs">
                      {job.position ?? `#${job.positionId}`}
                    </span>
                  </div>
                  <div className="flex justify-between items-center py-1">
                    <span className="text-gray-600 font-medium text-xs">
                      Notifications
                    </span>
                    <span className="font-semibold text-gray-900 text-xs">
                      {job.sendNotification ?? "N"}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Long Text Sections */}
            <div className="bg-white rounded-md p-3 border border-gray-100 shadow-sm space-y-3">
              <h3 className="text-sm font-semibold text-gray-900">Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <p className="text-[11px] text-gray-500 mb-1">
                    Company Description
                  </p>
                  <p className="text-sm text-gray-900 whitespace-pre-wrap">
                    {job.companyDescription || "Not provided"}
                  </p>
                </div>
                <div>
                  <p className="text-[11px] text-gray-500 mb-1">
                    What to Expect
                  </p>
                  <p className="text-sm text-gray-900 whitespace-pre-wrap">
                    {job.whatToExpect || "Not provided"}
                  </p>
                </div>
                <div>
                  <p className="text-[11px] text-gray-500 mb-1">Disclaimer</p>
                  <p className="text-sm text-gray-900 whitespace-pre-wrap">
                    {job.disclaimer || "Not provided"}
                  </p>
                </div>
                <div>
                  <p className="text-[11px] text-gray-500 mb-1">Please Note</p>
                  <p className="text-sm text-gray-900 whitespace-pre-wrap">
                    {job.pleaseNote || "Not provided"}
                  </p>
                </div>
              </div>
            </div>

            {/* Requirements (optional) */}
            {Array.isArray(job.requirements) && job.requirements.length > 0 && (
              <div className="bg-white rounded-md p-3 border border-gray-100 shadow-sm">
                <h3 className="text-sm font-semibold text-gray-900 mb-2 flex items-center gap-2">
                  <FileText size={16} />
                  Requirements
                </h3>
                <ul className="list-disc pl-5 space-y-1">
                  {job.requirements.map((r, idx) => (
                    <li key={`${r.positionId}-${idx}`} className="text-sm">
                      Position #{r.positionId} — {r.expYears}y {r.expMonths}m
                      experience
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Documents (optional) */}
            {Array.isArray(job.documents) && job.documents.length > 0 && (
              <div className="bg-white rounded-md p-3 border border-gray-100 shadow-sm">
                <h3 className="text-sm font-semibold text-gray-900 mb-2 flex items-center gap-2">
                  <FileText size={16} />
                  Documents
                </h3>
                <ul className="list-disc pl-5 space-y-1">
                  {job.documents.map((d) => (
                    <li key={d.documentId} className="text-sm">
                      Document #{d.documentId} —{" "}
                      {d.isMandatory ? "Mandatory" : "Optional"}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Footer Actions */}
            <div className="flex items-center justify-end gap-2">
              {onEdit && (
                <button
                  onClick={onEdit}
                  className="px-3 py-2 text-xs rounded-md bg-indigo-600 text-white hover:bg-indigo-700 transition"
                >
                  Edit Job
                </button>
              )}
              <button
                onClick={onClose}
                className="px-3 py-2 text-xs rounded-md bg-gray-200 text-gray-900 hover:bg-gray-300 transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
};
