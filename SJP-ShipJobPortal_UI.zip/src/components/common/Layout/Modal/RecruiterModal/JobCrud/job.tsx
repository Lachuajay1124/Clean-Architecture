"use client";

// React core
import React, { useMemo } from "react";

// External libraries
import Modal from "react-modal";
import Cookies from "js-cookie";
import { X } from "lucide-react";
import { Controller, useForm, useWatch, useFieldArray } from "react-hook-form";
import Select from "react-select";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

// Hooks (keep your real hooks)
import {
  useAllCountryList,
  useAllPositionList,
  useAllVesselTypesList,
  useAllDocumentsList,
} from "@/hooks/listingHooks/useListingHooks";
import { useCreateJob, useUpdateJob } from "./JobApi";
import { Job } from "@/types/getApiTypes";

export type Country = { id: number; countryName: string };
export type Position = { id: number; name: string };
export type VesselType = { typeID: number; vesseltype: string };
type DocumentItem = { id: number; name: string };
// ---------------------------------------------------------------------

// 1) define requirementSchema first
const requirementSchema = z.object({
  positionId: z.coerce.number().min(1, "Position is required"),
  expYears: z.coerce.number().min(0).max(60),
  expMonths: z.coerce.number().min(0).max(11),
});

const documentRequirementSchema = z.object({
  documentId: z.number(),
  isMandatory: z.boolean().default(false).optional(),
});

// 2) schema: arrays are required but have defaults, so resulting type is non-optional arrays
const createJobSchema = z
  .object({
    jobId: z.number().optional(),
    companyId: z.coerce.number().nonnegative(),
    userId: z.coerce.number().nonnegative(),

    jobTitle: z.string().min(1, "Job title is required"),
    positionId: z.coerce.number().min(1, "Position is required"),
    nationalityId: z.coerce.number(),
    noVacancy: z.coerce.number().min(1, "At least one vacancy is required"),
    vesselTypeId: z.coerce.number(),
    openDate: z.string().min(1, "Open date is required"),
    closeDate: z.string().min(1, "Close date is required"),

    companyDescription: z.string().min(1, "Company description is required"),
    whatToExpect: z.string().min(1, "This field is required"),
    disclaimer: z.string().min(1, "Disclaimer is required"),
    pleaseNote: z.string().min(1, "Please note is required"),

    // non-optional with default -> inferred type is `{...}[]` (not undefined)
    requirements: z.array(requirementSchema).default([]).optional(),
    documents: z.array(documentRequirementSchema).default([]).optional(),
  })
  .refine((v) => new Date(v.closeDate) >= new Date(v.openDate), {
    message: "Close date must be on/after Open date",
    path: ["closeDate"],
  });

// 3) use the exact inferred type from the schema
export type CreateJobFormData = z.infer<typeof createJobSchema>;

interface JobModalProps {
  isOpen: boolean;
  onClose: () => void;
  job: Job | null;
}

export const JobModal: React.FC<JobModalProps> = ({ isOpen, onClose, job }) => {
  const today = new Date();
  const todayStr = today.toISOString().split("T")[0];
  const userId = Number(Cookies.get("userId"));

  const {
    register,
    handleSubmit,
    control,
    reset,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<CreateJobFormData>({
    resolver: zodResolver(createJobSchema),
    defaultValues: {
      jobId: job?.jobId,
      companyId: job?.companyId || 1,
      userId: job?.userId || userId,

      // LEFT
      positionId: job?.positionId || 0, // main position
      nationalityId: job?.nationalityId || 0,
      noVacancy: job?.noVacancy || 1,
      vesselTypeId: job?.vesselTypeId || 0,
      openDate: job?.openDate || todayStr,
      closeDate:
        job?.closeDate ||
        new Date(new Date(todayStr).getTime() + 7 * 24 * 60 * 60 * 1000)
          .toISOString()
          .split("T")[0],

      // RIGHT long text
      companyDescription: job?.companyDescription || "",
      whatToExpect: job?.whatToExpect || "",
      disclaimer: job?.disclaimer || "",
      pleaseNote: job?.pleaseNote || "",

      // Multi requirements
      requirements: job?.requirements ?? [],

      // Extras
      documents: job?.documents ?? [],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: "requirements",
  });

  // Mutations
  const createJobMutation = useCreateJob(() => {
    reset();
    onClose();
  });
  const updateJobMutation = useUpdateJob(() => {
    reset();
    onClose();
  });

  // Lists
  const { data: countries, isLoading: isCountriesLoading } =
    useAllCountryList();
  const { data: vesselType, isLoading: isVesselTypeLoading } =
    useAllVesselTypesList();
  const { data: position, isLoading: isPositionLoading } = useAllPositionList();
  const { data: documents, isLoading: isDocumentsLoading } =
    useAllDocumentsList();

  // Watch selected documents to render toggle list
  const selectedDocs = useWatch({ control, name: "documents" });

  const documentOptions = useMemo(
    () =>
      (documents as DocumentItem[] | undefined)?.map((d) => ({
        label: d.name,
        value: d.id,
      })) ?? [],
    [documents]
  );

  const onSubmit = (data: CreateJobFormData) => {
    const payload = {
      ...data,
      locationId: data.nationalityId,
      // requirements already shaped as [{ positionId, expYears, expMonths }]
    };

    if (job) {
      updateJobMutation.mutate({ data, jobId: job.jobId });
    } else {
      createJobMutation.mutate(payload);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={() => !isSubmitting && onClose()}
      shouldCloseOnEsc
      shouldCloseOnOverlayClick
      ariaHideApp={false} // fine if setAppElement used globally
      style={{
        overlay: {
          backgroundColor: "rgba(0,0,0,0.6)",
          zIndex: 1000,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: 8,
        },
        content: {
          inset: "auto",
          padding: 0,
          border: "none",
          borderRadius: 8,
          overflow: "hidden",
          width: "100%",
          maxWidth: 900,
          maxHeight: "85vh",
        },
      }}
    >
      <div className="h-full flex flex-col justify-between bg-white rounded-md w-full mx-auto shadow-md space-y-2 overflow-auto">
        <div className="flex items-center justify-between btn-primary px-2">
          <h3 className="text-lg font-semibold text-white">
            {job ? "Edit Job" : "Create New Job"}
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 cursor-pointer"
            disabled={isSubmitting}
          >
            <X size={20} className="text-red-500 font-bold" />
          </button>
        </div>

        <form
          onSubmit={handleSubmit(onSubmit, (formErrors) => {
            console.error("Form validation failed:", formErrors);
          })}
          className="flex flex-col justify-between text-black h-full p-2"
        >
          <div className="grid grid-cols-6 gap-2">
            {/* Job Title */}

            {/* Open Date */}
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 ">
                Job Title *
              </label>
              <input
                {...register("jobTitle")}
                type="text"
                className={`w-full p-1 border ${
                  errors.jobTitle ? "border-red-500" : "border-gray-300"
                } rounded-md`}
              />
              {errors.jobTitle && (
                <p className="text-red-500 text-xs mt-1">
                  {errors.jobTitle.message}
                </p>
              )}
            </div>

            {/* Main Job Position (single) */}
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 ">
                Position *
              </label>
              <Controller
                name="positionId"
                control={control}
                render={({ field }) => (
                  <Select
                    {...field}
                    options={position?.map((p: Position) => ({
                      label: p.name,
                      value: p.id,
                    }))}
                    isLoading={isPositionLoading}
                    isDisabled={isPositionLoading}
                    placeholder="Select Position"
                    className={`react-select-container text-sm ${
                      errors.positionId ? "react-select-error" : ""
                    }`}
                    classNamePrefix="react-select"
                    onChange={(opt) => field.onChange(opt?.value)}
                    value={
                      position?.find((c: Position) => c.id === field.value)
                        ? {
                            label:
                              position.find(
                                (c: Position) => c.id === field.value
                              )?.name || "",
                            value: field.value,
                          }
                        : null
                    }
                  />
                )}
              />
              {errors.positionId && (
                <p className="text-red-500 text-xs mt-1">
                  {errors.positionId.message}
                </p>
              )}
            </div>

            {/* Nationality */}
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 ">
                Nationality *
              </label>
              <Controller
                name="nationalityId"
                control={control}
                render={({ field }) => (
                  <Select
                    {...field}
                    options={countries?.map((c: Country) => ({
                      label: c.countryName,
                      value: c.id,
                    }))}
                    isLoading={isCountriesLoading}
                    isDisabled={isCountriesLoading}
                    placeholder="Select Nationality"
                    className={`react-select-container text-sm ${
                      errors.nationalityId ? "react-select-error" : ""
                    }`}
                    classNamePrefix="react-select"
                    onChange={(opt) => field.onChange(opt?.value)}
                    value={
                      countries?.find((c: Country) => c.id === field.value)
                        ? {
                            label:
                              countries.find(
                                (c: Country) => c.id === field.value
                              )?.countryName || "",
                            value: field.value,
                          }
                        : null
                    }
                  />
                )}
              />
              {errors.nationalityId && (
                <p className="text-red-500 text-xs mt-1">
                  {errors.nationalityId.message}
                </p>
              )}
            </div>

            {/* Vessel Type */}
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 ">
                Vessel Type *
              </label>
              <Controller
                name="vesselTypeId"
                control={control}
                render={({ field }) => (
                  <Select
                    {...field}
                    options={vesselType?.map((v: VesselType) => ({
                      label: v.vesseltype,
                      value: v.typeID,
                    }))}
                    isLoading={isVesselTypeLoading}
                    isDisabled={isVesselTypeLoading}
                    placeholder="Select Vessel Type"
                    className={`react-select-container text-sm ${
                      errors.vesselTypeId ? "react-select-error" : ""
                    }`}
                    classNamePrefix="react-select"
                    onChange={(opt) => field.onChange(opt?.value)}
                    value={
                      vesselType?.find(
                        (v: VesselType) => v.typeID === field.value
                      )
                        ? {
                            label:
                              vesselType.find(
                                (v: VesselType) => v.typeID === field.value
                              )?.vesseltype || "",
                            value: field.value,
                          }
                        : null
                    }
                  />
                )}
              />
              {errors.vesselTypeId && (
                <p className="text-red-500 text-xs mt-1">
                  {errors.vesselTypeId.message}
                </p>
              )}
            </div>

            {/* No of Vacancy */}
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 ">
                No of Vacancy *
              </label>
              <Controller
                name="noVacancy"
                control={control}
                render={({ field }) => (
                  <Select
                    {...field}
                    options={Array.from({ length: 10 }, (_, i) => ({
                      label: `${i + 1}`,
                      value: i + 1,
                    }))}
                    placeholder="Select number of vacancies"
                    className={`react-select-container text-sm ${
                      errors.noVacancy ? "react-select-error" : ""
                    }`}
                    classNamePrefix="react-select"
                    onChange={(opt) => field.onChange(opt?.value)}
                    value={
                      field.value
                        ? { label: `${field.value}`, value: field.value }
                        : null
                    }
                  />
                )}
              />
              {errors.noVacancy && (
                <p className="text-red-500 text-xs mt-1">
                  {errors.noVacancy.message}
                </p>
              )}
            </div>
            {/* Open Date */}
            <div className="col-span-1">
              <label className="block text-sm font-medium text-gray-700 ">
                Open Date *
              </label>
              <input
                {...register("openDate")}
                type="date"
                className={`w-full p-1 border ${
                  errors.openDate ? "border-red-500" : "border-gray-300"
                } rounded-md`}
              />
              {errors.openDate && (
                <p className="text-red-500 text-xs mt-1">
                  {errors.openDate.message}
                </p>
              )}
            </div>

            {/* Close Date */}
            <div className="col-span-1">
              <label className="block text-sm font-medium text-gray-700 ">
                Close Date *
              </label>
              <input
                {...register("closeDate")}
                type="date"
                className={`w-full p-1 border ${
                  errors.closeDate ? "border-red-500" : "border-gray-300"
                } rounded-md`}
              />
              {errors.closeDate && (
                <p className="text-red-500 text-xs mt-1">
                  {errors.closeDate.message}
                </p>
              )}
            </div>

            {/* Company Description */}
            <div className="col-span-3">
              <label className="block text-sm font-medium text-gray-700">
                Company Description *
              </label>
              <textarea
                {...register("companyDescription")}
                rows={2}
                className={`w-full p-1 border ${
                  errors.companyDescription
                    ? "border-red-500"
                    : "border-gray-300"
                } rounded-md resize-y`}
                placeholder="Enter company description..."
              />
              {errors.companyDescription && (
                <p className="text-red-500 text-xs mt-1">
                  {errors.companyDescription.message}
                </p>
              )}
            </div>

            {/* What to Expect */}
            <div className="col-span-3">
              <label className="block text-sm font-medium text-gray-700">
                What to Expect *
              </label>
              <textarea
                {...register("whatToExpect")}
                rows={2}
                className={`w-full p-1 border ${
                  errors.whatToExpect ? "border-red-500" : "border-gray-300"
                } rounded-md resize-y`}
                placeholder="Describe what applicants can expect..."
              />
              {errors.whatToExpect && (
                <p className="text-red-500 text-xs mt-1">
                  {errors.whatToExpect.message}
                </p>
              )}
            </div>

            {/* Disclaimer */}
            <div className="col-span-3">
              <label className="block text-sm font-medium text-gray-700">
                Disclaimer *
              </label>
              <textarea
                {...register("disclaimer")}
                rows={2}
                className={`w-full p-1 border ${
                  errors.disclaimer ? "border-red-500" : "border-gray-300"
                } rounded-md resize-y`}
                placeholder="Enter disclaimer..."
              />
              {errors.disclaimer && (
                <p className="text-red-500 text-xs mt-1">
                  {errors.disclaimer.message}
                </p>
              )}
            </div>

            {/* Please Note */}
            <div className="col-span-3">
              <label className="block text-sm font-medium text-gray-700">
                Please Note *
              </label>
              <textarea
                {...register("pleaseNote")}
                rows={2}
                className={`w-full p-1 border ${
                  errors.pleaseNote ? "border-red-500" : "border-gray-300"
                } rounded-md resize-y`}
                placeholder="Enter important notes..."
              />
              {errors.pleaseNote && (
                <p className="text-red-500 text-xs mt-1">
                  {errors.pleaseNote.message}
                </p>
              )}
            </div>

            {/* Documents Required */}
            <div className="border border-gray-200 rounded-md p-2 col-span-3">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Documents required from the seafarer
              </label>

              <Controller
                name="documents"
                control={control}
                render={({ field }) => {
                  const currentIds = (field.value ?? []).map(
                    (d) => d.documentId
                  );
                  return (
                    <Select
                      isMulti
                      closeMenuOnSelect={false}
                      options={documentOptions}
                      isLoading={isDocumentsLoading}
                      isDisabled={isDocumentsLoading}
                      placeholder="Select documents"
                      className="react-select-container text-sm"
                      classNamePrefix="react-select"
                      value={documentOptions.filter((o) =>
                        currentIds.includes(o.value)
                      )}
                      onChange={(opts) => {
                        const nextIds = (opts ?? []).map((o) => o.value);
                        const next = nextIds.map((id) => {
                          const found = (field.value ?? []).find(
                            (d) => d.documentId === id
                          );
                          return {
                            documentId: id,
                            isMandatory: found ? found.isMandatory : false,
                          };
                        });
                        field.onChange(next);
                      }}
                    />
                  );
                }}
              />
              {/* Mandatory toggles */}
              {selectedDocs?.length ? (
                <div className="mt-2 col-span-3">
                  <div className="flex text-xs font-semibold text-gray-600 border-b pb-1">
                    <div className="flex-1">Document</div>
                    <div className="w-28 text-center">Mandatory</div>
                  </div>
                  {(
                    selectedDocs as Array<{
                      documentId: number;
                      isMandatory: boolean;
                    }>
                  ).map((s, idx) => {
                    const name =
                      (documents as DocumentItem[] | undefined)?.find(
                        (d) => d.id === s.documentId
                      )?.name ?? `Document ${s.documentId}`;
                    return (
                      <div
                        key={s.documentId}
                        className="flex items-center py-1 border-b last:border-b-0"
                      >
                        <div className="flex-1 text-sm">{name}</div>
                        <div className="w-28 text-center">
                          <input
                            type="checkbox"
                            className="h-4 w-4"
                            checked={s.isMandatory}
                            onChange={(e) => {
                              const next = [...selectedDocs];
                              next[idx] = {
                                ...next[idx],
                                isMandatory: e.target.checked,
                              };
                              setValue("documents", next, {
                                shouldDirty: true,
                                shouldValidate: true,
                              });
                            }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : null}
            </div>

            {/* ------------------ Project Requirements (Multiple) ------------------ */}
            <div className="col-span-3 border border-gray-200 rounded-md p-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-semibold text-gray-700">
                  Project Requirements (Position + Experience)
                </label>
                <button
                  type="button"
                  onClick={() =>
                    append({ positionId: 0, expYears: 0, expMonths: 0 })
                  }
                  className="px-2 py-1 text-xs rounded-md bg-gray-100 hover:bg-gray-200 border"
                >
                  + Add requirement
                </button>
              </div>

              <div className="space-y-2">
                {fields.map((field, idx) => (
                  <div
                    key={field.id}
                    className="grid grid-cols-3 gap-2 items-end"
                  >
                    {/* Requirement Position */}
                    <div className="col-span-3">
                      <label className="block text-xs font-medium text-gray-700">
                        Position *
                      </label>
                      <Controller
                        name={`requirements.${idx}.positionId`}
                        control={control}
                        render={({ field }) => (
                          <Select
                            {...field}
                            options={position?.map((p: Position) => ({
                              label: p.name,
                              value: p.id,
                            }))}
                            isLoading={isPositionLoading}
                            isDisabled={isPositionLoading}
                            placeholder="Select Position"
                            className={`react-select-container text-sm ${
                              errors.requirements?.[idx]?.positionId
                                ? "react-select-error"
                                : ""
                            }`}
                            classNamePrefix="react-select"
                            onChange={(opt) => field.onChange(opt?.value)}
                            value={
                              position?.find(
                                (c: Position) => c.id === field.value
                              )
                                ? {
                                    label:
                                      position.find(
                                        (c: Position) => c.id === field.value
                                      )?.name || "",
                                    value: field.value,
                                  }
                                : null
                            }
                          />
                        )}
                      />
                      {errors.requirements?.[idx]?.positionId && (
                        <p className="text-red-500 text-xs mt-1">
                          {errors.requirements?.[idx]?.positionId?.message}
                        </p>
                      )}
                    </div>

                    {/* Years */}
                    <div className="col-span-1">
                      <label className="block text-xs font-medium text-gray-700">
                        Years *
                      </label>
                      <input
                        type="number"
                        min={0}
                        max={60}
                        {...register(`requirements.${idx}.expYears`, {
                          valueAsNumber: true,
                        })}
                        className={`w-full p-1 border ${
                          errors.requirements?.[idx]?.expYears
                            ? "border-red-500"
                            : "border-gray-300"
                        } rounded-md`}
                        placeholder="e.g., 3"
                      />
                      {errors.requirements?.[idx]?.expYears && (
                        <p className="text-red-500 text-xs mt-1">
                          {errors.requirements?.[idx]?.expYears?.message}
                        </p>
                      )}
                    </div>

                    {/* Months */}
                    <div className="col-span-1">
                      <label className="block text-xs font-medium text-gray-700">
                        Months *
                      </label>
                      <input
                        type="number"
                        min={0}
                        max={11}
                        {...register(`requirements.${idx}.expMonths`, {
                          valueAsNumber: true,
                        })}
                        className={`w-full p-1 border ${
                          errors.requirements?.[idx]?.expMonths
                            ? "border-red-500"
                            : "border-gray-300"
                        } rounded-md`}
                        placeholder="0-11"
                      />
                      {errors.requirements?.[idx]?.expMonths && (
                        <p className="text-red-500 text-xs mt-1">
                          {errors.requirements?.[idx]?.expMonths?.message}
                        </p>
                      )}
                    </div>

                    {/* Remove */}
                    <div className="col-span-1 flex justify-end">
                      <button
                        type="button"
                        onClick={() => remove(idx)}
                        className="p-2 text-xs rounded-md bg-red-50 hover:bg-red-100 border border-red-200 text-red-600"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Buttons */}
          <div className="flex gap-2 mt-2">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="flex-1 bg-gray-200 text-gray-800 cursor-pointer rounded-md py-1 hover:bg-gray-300 text-sm font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={
                isSubmitting ||
                createJobMutation.isPending ||
                updateJobMutation.isPending
              }
              className="flex-1 btn-primary text-white cursor-pointer rounded-md py-1 hover:bg-blue-700 disabled:opacity-50 text-sm font-medium"
            >
              {job
                ? updateJobMutation.isPending
                  ? "Updating..."
                  : "Update Job"
                : createJobMutation.isPending
                ? "Creating..."
                : "Create Job"}
            </button>
          </div>
        </form>
      </div>
    </Modal>
  );
};
