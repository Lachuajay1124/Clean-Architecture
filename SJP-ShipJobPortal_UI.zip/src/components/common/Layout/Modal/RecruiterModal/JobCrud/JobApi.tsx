// External libraries
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";

// Internal modules (@ alias)
import { createJob, deleteJob, updateJob } from "@/app/api/jobsApi/job";

// Types (type-only)
import type { CreateJobFormData } from "./job";

export const useCreateJob = (onSuccessCallback: () => void) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: CreateJobFormData) => createJob(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["jobByRecruiter"] });

      toast.success("Job created successfully");
      onSuccessCallback();
    },
    onError: (error: unknown) => {
      const err = error as Error;
      toast.error(`Failed to create job: ${err.message}`);
    },
  });
};

export const useUpdateJob = (onSuccessCallback: () => void) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ data, jobId }: { data: CreateJobFormData; jobId: number }) =>
      updateJob(data, jobId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["jobByRecruiter"] });
      toast.success("Job updated successfully");
      onSuccessCallback();
    },
    onError: (error: unknown) => {
      const err = error as Error;
      toast.error(`Failed to update job: ${err.message}`);
    },
  });
};

export const useDeleteJob = (onSuccessCallback: () => void) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ jobId }: { jobId: number }) => deleteJob(jobId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["jobByRecruiter"] });
      toast.success("Job Deleted successfully");
      onSuccessCallback();
    },
    onError: (error: unknown) => {
      const err = error as Error;
      toast.error(`Failed to delete job: ${err.message}`);
    },
  });
};
