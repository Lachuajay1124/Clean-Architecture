"use client";
import {
  ExperienceFormData,
  upsertExperiences,
} from "@/app/api/UserApi/UserCrud";
import React, { useEffect, useMemo, useState } from "react";

const defaultExperienceFormData: ExperienceFormData = {
  experianceId: "0",
  vesselName: "",
  vesselType: "",
  rank: "",
  companyName: "",
  duration: "",
  dwt: "",
  period: "",
  position: "",
  route: "",
  gt: "",
  fromDate: "",
  engineType: "",
  ias: "",
  kw: "",
  toDate: "",
};

const blankRow = (): ExperienceFormData => ({ ...defaultExperienceFormData });

interface ExperienceUpsertModalProps {
  open: boolean;
  onClose: () => void;
  initialExperiences?: ExperienceFormData[];
  onAfterSave?: () => void;
  title?: string;
}

interface TextFieldProps {
  label: string;
  value: string | number | null;
  onChange: (v: string | null) => void;
  type?: React.HTMLInputTypeAttribute;
}

function TextField({ label, value, onChange, type = "text" }: TextFieldProps) {
  return (
    <label className="flex flex-col gap-1">
      <span className="text-xs font-medium text-gray-600">{label}</span>
      <input
        type={type}
        value={value ?? ""}
        onChange={(e) => {
          const v = e.target.value;
          if (type === "number") {
            onChange(v === "" ? "" : v);
          } else {
            onChange(v);
          }
        }}
        className="rounded-md border border-gray-300 p-1 text-sm outline-none focus:ring-2 focus:ring-blue-200"
        aria-label={label}
      />
    </label>
  );
}

export function ExperienceUpsertModal({
  open,
  onClose,
  initialExperiences = [],
  onAfterSave,
  title = "Add / Edit Experience",
}: ExperienceUpsertModalProps) {
  const [rows, setRows] = useState<ExperienceFormData[]>(
    initialExperiences.length
      ? initialExperiences.map((r) => ({ ...defaultExperienceFormData, ...r }))
      : [blankRow()]
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    setRows(
      initialExperiences.length
        ? initialExperiences.map((r) => ({
            ...defaultExperienceFormData,
            ...r,
          }))
        : [blankRow()]
    );
    setError(null);
    setSaving(false);
  }, [open, initialExperiences]);

  const rowHasAnyData = (r: ExperienceFormData) =>
    Object.entries(r).some(([k, v]) => {
      if (k === "experienceId") return false;
      const s = (v ?? "").toString().trim();
      return s.length > 0;
    });

  const canSave = useMemo(() => rows.some(rowHasAnyData), [rows]);

  function handleChange<K extends keyof ExperienceFormData>(
    index: number,
    field: K,
    value: ExperienceFormData[K]
  ) {
    setRows((prev) =>
      prev.map((r, i) => (i === index ? { ...r, [field]: value } : r))
    );
  }

  function addRow() {
    setRows((prev) => [...prev, blankRow()]);
  }

  function removeRow(index: number) {
    setRows((prev) => prev.filter((_, i) => i !== index));
  }

  async function handleSave() {
    if (!canSave || saving) return;
    try {
      setSaving(true);
      setError(null);

      const results = await upsertExperiences(rows);
      const firstFail = results.find((r) => !r?.success);
      if (firstFail) {
        throw new Error(firstFail.message || "One or more rows failed");
      }

      onAfterSave?.();
      onClose();
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Failed to save experiences");
    } finally {
      setSaving(false);
    }
  }

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <button
        className="absolute inset-0 bg-black/50"
        onClick={() => !saving && onClose()}
        aria-label="Close modal"
        disabled={saving}
      />

      {/* Modal */}
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="experience-modal-title"
        className="relative z-10 w-[95vw] max-w-6xl max-h-[90vh] overflow-hidden rounded-md bg-white shadow-md"
      >
        {/* Header */}
        <div className="btn-primary flex items-center justify-between p-2">
          <h2 id="experience-modal-title" className="text-md font-semibold">
            {title}
          </h2>
          <button
            className="rounded-full px-2 py-1 text-red-400 hover:bg-red-100"
            onClick={onClose}
            disabled={saving}
            aria-label="Close"
          >
            ✕
          </button>
        </div>

        {/* Body */}
        <div className="p-2">
          {error && (
            <div
              role="alert"
              className="rounded-md bg-red-50 p-3 text-sm text-red-700"
            >
              {error}
            </div>
          )}

          {/* Rows container - scrollable */}
          <div className="max-h-[60vh] md:max-h-[60vh] overflow-y-auto">
            {rows.map((row, idx) => (
              <fieldset
                key={idx}
                className="mb-2 rounded-md border border-gray-300 p-2"
                aria-labelledby={`experience-legend-${idx}`}
              >
                <legend
                  id={`experience-legend-${idx}`}
                  className="px-2 text-sm font-medium text-gray-600"
                >
                  Experience #{idx + 1}
                </legend>

                <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
                  <TextField
                    label="Experience ID"
                    type="number"
                    value={row.experianceId ?? "0"}
                    onChange={(v) => handleChange(idx, "experianceId", v)}
                  />
                  <TextField
                    label="Vessel Name"
                    value={row.vesselName ?? ""}
                    onChange={(v) => handleChange(idx, "vesselName", v)}
                  />
                  <TextField
                    label="Vessel Type"
                    value={row.vesselType ?? ""}
                    onChange={(v) => handleChange(idx, "vesselType", v)}
                  />
                  <TextField
                    label="Rank"
                    value={row.rank ?? ""}
                    onChange={(v) => handleChange(idx, "rank", v)}
                  />
                  <TextField
                    label="Company Name"
                    value={row.companyName ?? ""}
                    onChange={(v) => handleChange(idx, "companyName", v)}
                  />
                  <TextField
                    label="Duration"
                    value={row.duration ?? ""}
                    onChange={(v) => handleChange(idx, "duration", v)}
                  />
                  <TextField
                    label="DWT"
                    value={row.dwt ?? ""}
                    onChange={(v) => handleChange(idx, "dwt", v)}
                  />
                  <TextField
                    label="Period"
                    value={row.period ?? ""}
                    onChange={(v) => handleChange(idx, "period", v)}
                  />
                  <TextField
                    label="Position"
                    value={row.position ?? ""}
                    onChange={(v) => handleChange(idx, "position", v)}
                  />
                  <TextField
                    label="Route"
                    value={row.route ?? ""}
                    onChange={(v) => handleChange(idx, "route", v)}
                  />
                  <TextField
                    label="GT"
                    value={row.gt ?? ""}
                    onChange={(v) => handleChange(idx, "gt", v)}
                  />
                  <TextField
                    label="From Date"
                    type="date"
                    value={row.fromDate ?? ""}
                    onChange={(v) => handleChange(idx, "fromDate", v)}
                  />
                  <TextField
                    label="Engine Type"
                    value={row.engineType ?? ""}
                    onChange={(v) => handleChange(idx, "engineType", v)}
                  />
                  <TextField
                    label="IAS"
                    value={row.ias ?? ""}
                    onChange={(v) => handleChange(idx, "ias", v)}
                  />
                  <TextField
                    label="KW"
                    value={row.kw ?? ""}
                    onChange={(v) => handleChange(idx, "kw", v)}
                  />
                  <TextField
                    label="To Date"
                    type="date"
                    value={row.toDate ?? ""}
                    onChange={(v) => handleChange(idx, "toDate", v)}
                  />
                </div>

                <div className="mt-2 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => removeRow(idx)}
                    className="rounded-md border p-2 text-sm hover:bg-gray-50"
                    disabled={rows.length === 1 || saving}
                    aria-label={`Remove experience ${idx + 1}`}
                  >
                    Remove
                  </button>
                  {idx === rows.length - 1 && (
                    <button
                      type="button"
                      onClick={addRow}
                      className="rounded-md bg-gray-900 p-2 text-sm text-white hover:bg-black"
                      disabled={saving}
                      aria-label="Add another experience"
                    >
                      + Add another
                    </button>
                  )}
                </div>
              </fieldset>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 px-2 pb-2">
          <button
            className="rounded-md border p-1 text-sm hover:bg-gray-50"
            onClick={onClose}
            disabled={saving}
            aria-label="Cancel and close"
          >
            Cancel
          </button>
          <button
            className="rounded-md btn-primary p-1 text-sm font-medium text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-60"
            onClick={handleSave}
            disabled={!canSave || saving}
            aria-label="Save all experiences"
          >
            {saving ? "Saving..." : "Save All"}
          </button>
        </div>
      </div>
    </div>
  );
}
