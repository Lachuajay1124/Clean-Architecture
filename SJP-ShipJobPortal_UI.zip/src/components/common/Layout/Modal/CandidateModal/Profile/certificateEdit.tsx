"use client";

import {
  CertificateFormData,
  upsertCertificates,
} from "@/app/api/UserApi/UserCrud";
import React, { useEffect, useMemo, useState } from "react";

const defaultCertificateFormData: CertificateFormData = {
  certificateId: "0", // string as requested
  certificateName: "",
  issuedDate: "", // YYYY-MM-DD
  issuedCountry: "",
  expiryDate: "", // YYYY-MM-DD
  status: "",
  documentNumber: "",
};

const blankRow = (): CertificateFormData => ({ ...defaultCertificateFormData });

// ==========================
// Modal Props
// ==========================
interface CertificateUpsertModalProps {
  open: boolean;
  onClose: () => void;
  /** Prefill rows for edit; leave empty for a single blank row */
  initialCertificates?: CertificateFormData[];
  /** Called after all rows have been successfully saved */
  onAfterSave?: () => void;
  /** Optional title */
  title?: string;
}

interface TextFieldProps {
  label: string;
  value: string | number | null;
  onChange: (v: string | null) => void;
  type?: React.HTMLInputTypeAttribute;
}

// ==========================
// TextField Component
// ==========================
function TextField({ label, value, onChange, type = "text" }: TextFieldProps) {
  return (
    <label className="flex flex-col gap-1">
      <span className="text-xs font-medium text-gray-600">{label}</span>
      <input
        type={type}
        value={value ?? ""}
        onChange={(e) => onChange(e.target.value)}
        className="rounded-md border border-gray-300 p-1 text-sm outline-none focus:ring-2 focus:ring-blue-200"
        aria-label={label}
      />
    </label>
  );
}

// ==========================
// Component
// ==========================
export function CertificateUpsertModal({
  open,
  onClose,
  initialCertificates = [],
  onAfterSave,
  title = "Add / Edit Certificates",
}: CertificateUpsertModalProps) {
  const [rows, setRows] = useState<CertificateFormData[]>(
    initialCertificates.length
      ? initialCertificates.map((r) => ({
          ...defaultCertificateFormData,
          ...r,
        }))
      : [blankRow()]
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    setRows(
      initialCertificates.length
        ? initialCertificates.map((r) => ({
            ...defaultCertificateFormData,
            ...r,
          }))
        : [blankRow()]
    );
    setError(null);
    setSaving(false);
  }, [open, initialCertificates]);

  const rowHasAnyData = (r: CertificateFormData) =>
    Object.entries(r).some(([k, v]) => {
      if (k === "certificateId") return false; // don't count id as data
      const s = (v ?? "").toString().trim();
      return s.length > 0;
    });

  const canSave = useMemo(() => rows.some(rowHasAnyData), [rows]);

  function handleChange<K extends keyof CertificateFormData>(
    index: number,
    field: K,
    value: CertificateFormData[K]
  ) {
    setRows((prev) =>
      prev.map((r, i) => (i === index ? { ...r, [field]: value } : r))
    );
  }

  function addRow() {
    setRows((prev) => [...prev, blankRow()]);
  }

  function removeRow(index: number) {
    setRows((prev) => prev.filter((_, i) => i !== index));
  }

  async function handleSave() {
    if (!canSave || saving) return;
    try {
      setSaving(true);
      setError(null);

      const results = await upsertCertificates(rows);
      const firstFail = results.find((r) => !r?.success);
      if (firstFail) {
        throw new Error(firstFail.message || "One or more rows failed");
      }

      onAfterSave?.();
      onClose();
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Failed to save certificates");
    } finally {
      setSaving(false);
    }
  }

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <button
        className="absolute inset-0 bg-black/50"
        onClick={() => !saving && onClose()}
        aria-label="Close modal"
        disabled={saving}
      />

      {/* Modal */}
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="certificate-modal-title"
        className="relative z-10 w-[95vw] max-w-6xl max-h-[90vh] overflow-hidden rounded-md bg-white shadow-md"
      >
        {/* Header */}
        <div className="btn-primary flex items-center justify-between p-2">
          <h2 id="certificate-modal-title" className="text-md font-semibold">
            {title}
          </h2>
          <button
            className="rounded-full px-2 py-1 text-red-400 hover:bg-red-100"
            onClick={onClose}
            disabled={saving}
            aria-label="Close"
          >
            ✕
          </button>
        </div>

        {/* Body */}
        <div className="p-2">
          {error && (
            <div
              role="alert"
              className="rounded-md bg-red-50 p-3 text-sm text-red-700"
            >
              {error}
            </div>
          )}

          {/* Rows container - scrollable */}
          <div className="max-h-[60vh] md:max-h-[60vh] overflow-y-auto">
            {rows.map((row, idx) => (
              <fieldset
                key={idx}
                className="mb-2 rounded-md border border-gray-300 p-2"
                aria-labelledby={`certificate-legend-${idx}`}
              >
                <legend
                  id={`certificate-legend-${idx}`}
                  className="px-2 text-sm font-medium text-gray-600"
                >
                  Certificate #{idx + 1}
                </legend>

                <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
                  <TextField
                    label="Certificate ID"
                    value={row.certificateId ?? "0"}
                    onChange={(v) => handleChange(idx, "certificateId", v)}
                    type="text" // keep as string
                  />
                  <TextField
                    label="Certificate Name"
                    value={row.certificateName ?? ""}
                    onChange={(v) => handleChange(idx, "certificateName", v)}
                  />
                  <TextField
                    label="Issued Date"
                    type="date"
                    value={row.issuedDate ?? ""}
                    onChange={(v) => handleChange(idx, "issuedDate", v)}
                  />
                  <TextField
                    label="Issued Country"
                    value={row.issuedCountry ?? ""}
                    onChange={(v) => handleChange(idx, "issuedCountry", v)}
                  />
                  <TextField
                    label="Expiry Date"
                    type="date"
                    value={row.expiryDate ?? ""}
                    onChange={(v) => handleChange(idx, "expiryDate", v)}
                  />
                  <TextField
                    label="Status"
                    value={row.status ?? ""}
                    onChange={(v) => handleChange(idx, "status", v)}
                  />
                  <TextField
                    label="Document Number"
                    value={row.documentNumber ?? ""}
                    onChange={(v) => handleChange(idx, "documentNumber", v)}
                  />
                </div>

                <div className="mt-2 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => removeRow(idx)}
                    className="rounded-md border p-2 text-sm hover:bg-gray-50"
                    disabled={rows.length === 1 || saving}
                    aria-label={`Remove certificate ${idx + 1}`}
                  >
                    Remove
                  </button>
                  {idx === rows.length - 1 && (
                    <button
                      type="button"
                      onClick={addRow}
                      className="rounded-md bg-gray-900 p-2 text-sm text-white hover:bg-black"
                      disabled={saving}
                      aria-label="Add another certificate"
                    >
                      + Add another
                    </button>
                  )}
                </div>
              </fieldset>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 px-2 pb-2">
          <button
            className="rounded-md border p-1 text-sm hover:bg-gray-50"
            onClick={onClose}
            disabled={saving}
            aria-label="Cancel and close"
          >
            Cancel
          </button>
          <button
            className="rounded-md btn-primary p-1 text-sm font-medium text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-60"
            onClick={handleSave}
            disabled={!canSave || saving}
            aria-label="Save all certificates"
          >
            {saving ? "Saving..." : "Save All"}
          </button>
        </div>
      </div>
    </div>
  );
}
