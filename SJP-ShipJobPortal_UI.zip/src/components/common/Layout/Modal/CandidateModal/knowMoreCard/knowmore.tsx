// React core
import React, {
  memo,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

// Next/externals
import Cookies from "js-cookie";
import Modal from "react-modal";
import { toast } from "react-toastify";
import {
  ArrowRightIcon,
  Building2,
  Calendar,
  CheckCircleIcon,
  FileText,
  Heart,
  MapPin,
  Ship,
  User,
  UserCheck,
  X,
  Zap,
} from "lucide-react";

// Internal modules (@ alias)
import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";
import { ReferralModal } from "@/components/common/Refer/refer";
import { useAllAvailableJobForCandidates } from "@/hooks/listingHooks/useListingHooks";
import { useApplyJob } from "@/hooks/actionHooks/jobApi";
import { useReferJob } from "@/hooks/actionHooks/referFriend";
import { useSaveJob } from "@/hooks/actionHooks/saveJobApi";
import { useJobViewCount } from "@/hooks/actionHooks/viewCount";

// Types (type-only)
import type { ForwardRefExoticComponent, RefAttributes } from "react";
import type { LucideProps } from "lucide-react";
import type { Job } from "@/types/getApiTypes";
import type {
  JobApplicationPayload,
  ReferJobs,
  SaveJobs,
} from "@/app/api/jobsApi/types";

// InfoCard component
interface InfoCardProps {
  icon: ForwardRefExoticComponent<
    Omit<LucideProps, "ref"> & RefAttributes<SVGSVGElement>
  >;
  label: string;
  value: string | null | number | undefined;
  className?: string;
}

const InfoCard = memo<InfoCardProps>(
  ({ icon: Icon, label, value, className = "" }) => (
    <div
      className={`bg-white rounded-md p-2 border border-gray-100 shadow-sm hover:shadow-md transition-all duration-200 ${className}`}
    >
      <div className="flex items-start gap-2">
        <div className="p-2 bg-blue-50 rounded-md shrink-0">
          <Icon size={20} className="text-blue-600" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-gray-600">{label}</p>
          <p className="font-semibold text-gray-900 text-xs leading-tight">
            {value || "Not specified"}
          </p>
        </div>
      </div>
    </div>
  )
);

InfoCard.displayName = "InfoCard";

// Confirmation Modal component
const ConfirmationModal = memo<{
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  isLoading?: boolean;
}>(({ isOpen, onClose, onConfirm, isLoading = false }) => (
  <Modal
    isOpen={isOpen}
    onRequestClose={onClose}
    ariaHideApp={false}
    shouldCloseOnEsc={!isLoading}
    shouldCloseOnOverlayClick={!isLoading}
    className="fixed inset-0 flex items-center justify-center p-4 z-50"
    overlayClassName="fixed inset-0 bg-black/60 z-40"
    role="dialog"
    aria-labelledby="confirmation-modal-title"
    aria-describedby="confirmation-modal-description"
  >
    <div className="bg-white rounded-md p-2 max-w-md w-full mx-4 shadow-md">
      <h2
        id="confirmation-modal-title"
        className="text-lg font-semibold text-gray-900 mb-3"
      >
        Confirm Application
      </h2>
      <p id="confirmation-modal-description" className="text-gray-600 mb-6">
        Are you sure you want to apply for this position?
      </p>
      <div className="flex justify-end gap-3">
        <button
          onClick={onClose}
          disabled={isLoading}
          className="cursor-pointer p-2 text-gray-700 bg-gray-100 hover:bg-gray-200 disabled:opacity-50 rounded-md font-medium transition-colors"
          aria-label="Cancel application"
        >
          Cancel
        </button>
        <button
          onClick={onConfirm}
          disabled={isLoading}
          className="cursor-pointer p-2 btn-primary hover:bg-blue-700 disabled:opacity-50 text-white rounded-md font-medium transition-colors flex items-center gap-2"
          aria-label="Confirm application"
        >
          {isLoading ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-white/30 border-t-white"></div>
              Applying...
            </>
          ) : (
            <>
              <Zap size={16} />
              Yes, Apply
            </>
          )}
        </button>
      </div>
    </div>
  </Modal>
));

ConfirmationModal.displayName = "ConfirmationModal";

// Props interface for KnowMoreCard
interface Props {
  jobId: number | null;
  onClose: () => void;
  isOpen: boolean;
}

// Main component
export const KnowMoreCard: React.FC<Props> = ({ jobId, onClose, isOpen }) => {
  const [showConfirm, setShowConfirm] = useState(false);
  const [pendingJobId, setPendingJobId] = useState<number | null>(null);
  const [isReferralModalOpen, setIsReferralModalOpen] = useState(false);

  const userId = useMemo(() => Number(Cookies.get("userId")), []);

  // Mutations
  const viewJobMutation = useJobViewCount(() => {});
  const applyJobMutation = useApplyJob(onClose);
  const saveJobMutation = useSaveJob(() => {});
  const referJobMutation = useReferJob(() => {
    setIsReferralModalOpen(false);
  });

  // Fetch job data
  const { data: jobs, isLoading: isJobsLoading } =
    useAllAvailableJobForCandidates({
      vacancyId: jobId,
    });

  const job = useMemo(() => jobs?.jobsList?.[0] || null, [jobs]);

  // Use a ref to ensure the effect runs only once
  const didViewJobRef = useRef(false);

  // Track job view
  useEffect(() => {
    if (jobId && userId && isOpen && !didViewJobRef.current) {
      const data: SaveJobs = {
        jobId: jobId,
      };
      viewJobMutation.mutate(data);
      didViewJobRef.current = true; // Mark as done after the first mutation
    }
  }, [jobId, userId, isOpen, viewJobMutation]);

  // Event handlers
  const handleApply = useCallback((jobId: number) => {
    setPendingJobId(jobId);
    setShowConfirm(true);
  }, []);

  const confirmApply = useCallback(() => {
    if (pendingJobId) {
      const data: JobApplicationPayload = {
        userId: userId,
        jobId: pendingJobId,
        coverLetter: "",
        resumeFile: "",
        notes: "",
      };
      applyJobMutation.mutate(data);
    }
    setShowConfirm(false);
    setPendingJobId(null);
  }, [pendingJobId, userId, applyJobMutation]);

  const handleSave = (job: Job | null) => {
    if (!job || !userId || !job.jobId) return;

    const data: SaveJobs = {
      jobId: job.jobId,
      mode: job.isSaved == 1 ? "remove" : "save",
    };
    saveJobMutation.mutate(data);
  };

  const handleReferSubmit = useCallback(
    (name: string, email: string) => {
      if (!userId) {
        toast.error("User not logged in.");
        return;
      }

      const data: ReferJobs = {
        userId,
        friendEmail: email,
        friendName: name,
      };

      referJobMutation.mutate(data);
    },
    [userId, referJobMutation]
  );

  const handleClose = useCallback(() => {
    setShowConfirm(false);
    setPendingJobId(null);
    setIsReferralModalOpen(false);
    onClose();
  }, [onClose]);

  // Memoized info cards data
  const infoCards = useMemo(
    () => [
      { icon: Building2, label: "Company", value: job?.company },
      { icon: MapPin, label: "Location", value: job?.nationality },
      { icon: Ship, label: "Vessel Type", value: job?.vesselType },
      { icon: User, label: "Vacancy", value: job?.noVacancy },
      { icon: Calendar, label: "Closing Date", value: job?.closeDate },
    ],
    [job]
  );

  if (!isOpen || !jobId) return null;

  if (isJobsLoading) {
    return (
      <Modal
        isOpen={isOpen}
        onRequestClose={onClose}
        ariaHideApp={false}
        className="fixed inset-0 flex items-center justify-center p-2"
        overlayClassName="fixed inset-0 bg-black/60 "
        role="dialog"
        aria-labelledby="loading-modal-title"
        aria-describedby="loading-modal-description"
      >
        <div className="bg-white rounded-md p-8">
          <LoadingSpinner />
        </div>
      </Modal>
    );
  }

  return (
    <>
      <Modal
        isOpen={isOpen}
        ariaHideApp={false}
        onRequestClose={handleClose}
        shouldCloseOnEsc={true}
        shouldCloseOnOverlayClick={true}
        className="fixed inset-4 md:inset-8 lg:inset-16 flex items-center justify-center"
        overlayClassName="fixed inset-0 bg-black/60 z-30"
        role="dialog"
        aria-labelledby="know-more-card-title"
        aria-describedby="know-more-card-description"
      >
        <div className="bg-white rounded-md shadow-2xl w-full h-full max-w-6xl max-h-[90vh] flex flex-col overflow-hidden">
          {/* Enhanced Header */}
          <div className="btn-primary text-white p-2">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1 min-w-0">
                <h1
                  id="know-more-card-title"
                  className="text-2xl font-semibold leading-tight"
                >
                  {job?.position || "Position not specified"}
                </h1>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => setIsReferralModalOpen(true)}
                  className="cursor-pointer px-4 py-1 bg-white/10 hover:bg-white/20  rounded-md transition-all duration-200 flex items-center gap-2 text-sm font-medium"
                  aria-label="Refer a friend"
                >
                  <UserCheck size={16} />
                  Refer
                </button>

                <button
                  onClick={() => handleSave(job)}
                  className={`cursor-pointer p-1 rounded-md transition-all duration-200 ${
                    job?.isSaved === 1
                      ? "bg-red-500/20 text-red-200 scale-110"
                      : "bg-white/10 hover:bg-white/20 text-white hover:text-red-200"
                  }`}
                  aria-label={
                    job?.isSaved === 1 ? "Remove from saved" : "Save job"
                  }
                >
                  <Heart size={20} fill={job?.isSaved == 1 ? "red" : "none"} />
                </button>

                <button
                  onClick={handleClose}
                  className="cursor-pointer p-1 bg-white/10 hover:bg-white/20 rounded-md transition-all duration-200 hover:scale-105"
                  aria-label="Close modal"
                >
                  <X size={20} />
                </button>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 overflow-y-auto bg-gray-50">
            <div className="p-2 space-y-2">
              {/* Key Information Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-2">
                {infoCards.map((card, index) => (
                  <InfoCard
                    key={index}
                    icon={card.icon}
                    label={card.label}
                    value={card.value}
                  />
                ))}
              </div>

              <div className="bg-white rounded-md p-3 border border-gray-100 shadow-sm space-y-3">
                <h3 className="text-sm font-semibold text-gray-900">Details</h3>
                <div className="grid grid-cols-1 gap-3">
                  <div>
                    <p className="text-[11px] text-gray-500 mb-1">
                      Company Description
                    </p>
                    <p className="text-sm text-gray-900 whitespace-pre-wrap">
                      {job?.companyDescription || "Not provided"}
                    </p>
                  </div>
                  <div>
                    <p className="text-[11px] text-gray-500 mb-1">
                      What to Expect
                    </p>
                    <p className="text-sm text-gray-900 whitespace-pre-wrap">
                      {job?.whatToExpect || "Not provided"}
                    </p>
                  </div>
                  <div>
                    <p className="text-[11px] text-gray-500 mb-1">Disclaimer</p>
                    <p className="text-sm text-gray-900 whitespace-pre-wrap">
                      {job?.disclaimer || "Not provided"}
                    </p>
                  </div>
                  <div>
                    <p className="text-[11px] text-gray-500 mb-1">
                      Please Note
                    </p>
                    <p className="text-sm text-gray-900 whitespace-pre-wrap">
                      {job?.pleaseNote || "Not provided"}
                    </p>
                  </div>
                </div>
              </div>

              {/* Requirements (optional) */}
              {Array.isArray(job?.requirements) &&
                job.requirements.length > 0 && (
                  <div className="bg-white rounded-md p-3 border border-gray-100 shadow-sm">
                    <h3 className="text-sm font-semibold text-gray-900 mb-2 flex items-center gap-2">
                      <FileText size={16} />
                      Requirements
                    </h3>
                    <ul className="list-disc pl-5 space-y-1">
                      {job.requirements.map((r, idx) => (
                        <li key={`${r.positionId}-${idx}`} className="text-sm">
                          Position #{r.positionId} — {r.expYears}y {r.expMonths}
                          m experience
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

              {/* Documents (optional) */}
              {Array.isArray(job?.documents) && job?.documents.length > 0 && (
                <div className="bg-white rounded-md p-3 border border-gray-100 shadow-sm">
                  <h3 className="text-sm font-semibold text-gray-900 mb-2 flex items-center gap-2">
                    <FileText size={16} />
                    Documents
                  </h3>
                  <ul className="list-disc pl-5 space-y-1">
                    {job.documents.map((d) => (
                      <li key={d.documentId} className="text-sm">
                        Document #{d.documentId} —{" "}
                        {d.isMandatory ? "Mandatory" : "Optional"}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="border-t border-gray-200 bg-white p-2">
            <div className="flex flex-col sm:flex-row justify-between items-center gap-2">
              <div className="text-sm text-blue-500">
                Ready to take the next step in your career?
              </div>
              <div className="flex gap-3">
                <button
                  onClick={handleClose}
                  className="cursor-pointer p-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md font-medium transition-colors"
                >
                  Close
                </button>

                <button
                  type="button"
                  onClick={() => handleApply(Number(job?.jobId))}
                  disabled={job?.isApplied == 1}
                  className={`${
                    job?.isApplied != 1
                      ? "btn-primary hover:bg-blue-500"
                      : "bg-blue-900 hover:bg-blue-800"
                  } w-full cursor-pointer text-white font-medium p-1 md:py-1 md:px-4 rounded-md transition-all duration-200 ease-in-out hover:scale-[1.02] active:scale-100 shadow hover:shadow-md`}
                >
                  <span className="flex items-center justify-center gap-2 text-sm">
                    {job?.isApplied == 1 ? (
                      <>
                        <CheckCircleIcon className="w-4 h-4" />
                        Applied
                      </>
                    ) : (
                      <>
                        <ArrowRightIcon className="w-4 h-4" />
                        Apply Now
                      </>
                    )}
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </Modal>

      {/* Confirmation Modal */}
      <ConfirmationModal
        isOpen={showConfirm}
        onClose={() => setShowConfirm(false)}
        onConfirm={confirmApply}
      />

      {/* Referral Modal */}
      <ReferralModal
        isOpen={isReferralModalOpen}
        onClose={() => setIsReferralModalOpen(false)}
        onSubmit={handleReferSubmit}
      />
    </>
  );
};
