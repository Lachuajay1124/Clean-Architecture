// React core
import React, { useRef } from "react";

// External libraries
import { ArrowRightIcon, CheckCircleIcon, Heart } from "lucide-react";

// Internal modules (@ alias)
import { useSaveJob } from "@/hooks/actionHooks/saveJobApi";

// Types (type-only)
import type { Job } from "@/types/getApiTypes";
import type { SaveJobs } from "@/app/api/jobsApi/types";

interface Props {
  job: Job;
  onJobSet: (job: Job) => void;
}

const FALLBACK_NA = "N/A";
const FALLBACK_COMPANY = "Unknown Company";

export const JobCard: React.FC<Props> = ({ job, onJobSet }) => {
  const debounceRef = useRef<NodeJS.Timeout | null>(null);

  const saveJobMutation = useSaveJob(() => {});
  const confirmSave = (job: Job) => {
    if (!job?.jobId) return;

    const data: SaveJobs = {
      jobId: job?.jobId,
      mode: job?.isSaved == 1 ? "remove" : "save",
    };
    saveJobMutation.mutate(data);

    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {}, 250);
  };

  return (
    <div
      className="bg-white rounded-md border border-gray-200 shadow-sm hover:scale-102 hover:shadow-md hover:border-blue-200 transition-all duration-200 p-2 relative overflow-hidden group"
      role="article" // Define the card as an article for better semantic understanding
    >
      <div className="relative z-10 ">
        <div className="flex justify-between items-start">
          <div className="flex-1 pr-4">
            <div className="flex items-center gap-2">
              <div className="flex flex-col w-full">
                <div className="flex justify-between items-center w-full">
                  <p className="font-bold text-xs md:text-sm text-gray-900">
                    {job.position ?? FALLBACK_NA}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Save Job Button */}
          <button
            type="button"
            onClick={() => confirmSave(job)}
            aria-label={`Like ${job.jobTitle}`}
            className={`p-1 rounded-full transition-all duration-200 mb-2 ${
              job.isSaved == 1
                ? "bg-red-100 text-red-500 scale-110"
                : "bg-gray-100 text-gray-400 hover:bg-red-50 hover:text-red-400"
            }`}
            role="button"
          >
            <Heart
              size={14}
              fill={job.isSaved == 1 ? "currentColor" : "none"}
            />
          </button>
        </div>

        {/* Job Details */}
        <div className="grid grid-cols-2 gap-2 mb-2">
          <div className="flex items-center gap-2 p-1 bg-blue-50 rounded-md">
            <div>
              <p className="text-[10px] md:text-xs text-black">Company</p>
              <p className="font-medium text-gray-900 text-[10px] md:text-xs">
                {job?.company ?? FALLBACK_COMPANY}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 p-1 bg-red-50 rounded-md">
            <div>
              <p className="text-[10px] md:text-xs text-black">Vessel</p>
              <p className="font-medium text-gray-900 text-[10px] md:text-xs">
                {job.vesselType ?? FALLBACK_NA}
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 mb-2">
          <div className="flex items-center gap-2 p-1 bg-amber-50 rounded-md">
            <div>
              <p className="text-[10px] md:text-xs text-black">Posted Date</p>
              <p className="font-medium text-gray-900 text-[10px] md:text-xs">
                {job.openDate ?? FALLBACK_NA}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 p-1 bg-green-50  rounded-md">
            <div>
              <p className="text-[10px] md:text-xs text-black">Close Date</p>
              <p className="font-medium text-gray-900 text-[10px] md:text-xs">
                {job.closeDate ?? FALLBACK_NA}
              </p>
            </div>
          </div>
        </div>

        {/* Apply / View Job Button */}
        <button
          type="button"
          onClick={() => onJobSet(job)}
          aria-label={
            job?.isApplied == 1
              ? `View details for ${job?.jobTitle}`
              : `Apply for ${job?.jobTitle}`
          }
          className={`${
            job?.isApplied != 1
              ? "btn-primary hover:bg-blue-500"
              : "bg-blue-900 hover:bg-blue-800"
          } w-full cursor-pointer text-white font-medium p-1 md:py-1 md:px-4 rounded-md `}
        >
          <span className="flex items-center justify-center gap-2 text-[10px] md:text-sm hover:scale-110 ease-in-out transition-all duration-200">
            {job?.isApplied == 1 ? (
              <>
                <CheckCircleIcon className="w-4 h-4" />
                Applied
              </>
            ) : (
              <>
                <ArrowRightIcon className="w-4 h-4" />
                Apply Now
              </>
            )}
          </span>
        </button>
      </div>
    </div>
  );
};
