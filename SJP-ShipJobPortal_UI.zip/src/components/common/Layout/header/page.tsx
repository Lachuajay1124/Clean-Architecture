"use client";

import { useEffect, useMemo, useState } from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import Cookies from "js-cookie";
import { Bell, CircleXIcon, Menu } from "lucide-react";
import Modal from "react-modal";
import { toast } from "react-toastify";

import { useAuth } from "@/hooks/useAuth";
import { logoutUser } from "@/app/api/UserApi/UserCrud";

type NavItem = { name: string; path: string };
type UserRole = "Seafarer" | "Recruiter" | null | undefined;

const PUBLIC_PATHS = new Set(["/login", "/register", "/unauthorized"]);
const HIDE_SIDEBAR_PATHS = new Set([
  "/recruiters/companyProfile",
  "/candidates/profilePage",
]);

const HeaderComponent = () => {
  const pathname = usePathname();
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);
  const [showLogoutModal, setShowLogoutModal] = useState(false);

  const { user, loading } = useAuth() ?? {};
  const isPublic = PUBLIC_PATHS.has(pathname);
  const visibleFrame = !isPublic;

  // Close mobile drawer on route change
  useEffect(() => {
    setMenuOpen(false);
  }, [pathname]);

  // Boolean, not a function
  const shouldShowSidebar = visibleFrame && !HIDE_SIDEBAR_PATHS.has(pathname);

  const SidebarComp = useMemo<React.ComponentType | null>(() => {
    const role = user as UserRole;
    if (role === "Seafarer") {
      return dynamic(
        () =>
          import(
            "@/components/common/Layout/sidebar/candidate/CandidateSideBar"
          ),
        { ssr: false, loading: () => null }
      );
    }
    if (role === "Recruiter") {
      return dynamic(
        () =>
          import(
            "@/components/common/Layout/sidebar/recruiter/dashboardSidebar"
          ),
        { ssr: false, loading: () => null }
      );
    }
    return null;
  }, [user]);

  // Parse navigation once
  const navList: NavItem[] = useMemo(() => {
    try {
      const nav = Cookies.get("navigation");
      return nav ? JSON.parse(nav) : [];
    } catch {
      return [];
    }
  }, []);

  const logout = async () => {
    try {
      const result = await logoutUser();
      // Clear cookies regardless of API response
      Cookies.remove("SjpJwtToken");
      Cookies.remove("SjpJwtRefreshToken");
      Cookies.remove("user");
      Cookies.remove("userEmail");
      Cookies.remove("navigation");
      Cookies.remove("allowedRoutes");
      Cookies.remove("userId");

      router.push("/login");
      setShowLogoutModal(false);
      toast.success("Logout successful!");

      if (!result?.success) {
        toast.error(result?.message || "Logout failed. Please try again.");
      }
    } catch {
      // Also clear on error
      Cookies.remove("SjpJwtToken");
      Cookies.remove("SjpJwtRefreshToken");
      Cookies.remove("user");
      Cookies.remove("userEmail");
      Cookies.remove("navigation");
      Cookies.remove("allowedRoutes");
      Cookies.remove("userId");

      router.push("/login");
      setShowLogoutModal(false);
      toast.success("Logout successful!");
      toast.error("An error occurred during logout.");
    }
  };

  if (loading) return null;

  return (
    <header className="header relative bg-white/50" role="banner">
      <div className="flex items-center justify-between p-0 md:p-2">
        {/* Mobile Menu Toggle */}
        <div className="md:hidden">
          <button
            type="button"
            aria-label="Toggle menu"
            onClick={() => setMenuOpen((v) => !v)}
            className="p-2 rounded-md bg-white/20 border border-white/30 cursor-pointer text-black hover:bg-white/30 transition"
          >
            {menuOpen ? <CircleXIcon size={20} /> : <Menu size={20} />}
          </button>
        </div>

        <div className="flex justify-between gap-6">
          <div className="logo hidden md:block">⚓ SJP</div>

          {/* Top nav */}
          <nav className="flex gap-2 md:gap-6 items-center" role="navigation">
            {navList.map((item) => (
              <Link
                key={item.path}
                href={item.path}
                className={`capitalize text-sm font-medium px-2 py-1 rounded-md transition-all duration-200 relative ${
                  pathname === item.path
                    ? "btn-primary shadow-md"
                    : "text-black hover:text-blue-500"
                }`}
                aria-current={pathname === item.path ? "page" : undefined}
              >
                <div className="relative flex items-center gap-2 text-[10px] md:text-sm">
                  {item.name}
                </div>
              </Link>
            ))}
          </nav>
        </div>

        {/* Right Icons */}
        <div className="flex items-center gap-2">
          {user === "Seafarer" && (
            <button
              className="relative p-1 cursor-pointer hover:bg-white/30 transition text-black"
              aria-label="Notifications"
            >
              <Bell size={18} />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full border border-white"></span>
            </button>
          )}

          {/* Logout */}
          <button
            onClick={() => setShowLogoutModal(true)}
            className="btn-primary cursor-pointer hover:scale-110 duration-200 transition-all text-[10px] md:text-sm p-1 px-2 rounded-md"
            aria-label="Logout"
          >
            Logout
          </button>
        </div>
      </div>

      {/* Mobile Sidebar Drawer */}
      {menuOpen && shouldShowSidebar && SidebarComp && (
        <div className="fixed inset-0 z-[100] md:hidden">
          {/* backdrop */}
          <div
            className="absolute inset-0 bg-black/50 z-[100]"
            onClick={() => setMenuOpen(false)}
            aria-hidden="true"
          />
          {/* panel */}
          <div className="absolute left-0 top-0 h-full w-72 max-w-[85%] bg-white shadow-md p-2 overflow-y-auto z-[110]">
            <button
              onClick={() => setMenuOpen(false)}
              className="mb-3 p-2 rounded bg-gray-100"
              aria-label="Close sidebar"
            >
              Close
            </button>
            <SidebarComp />
          </div>
        </div>
      )}

      {/* Logout Modal */}
      {showLogoutModal && (
        <Modal
          isOpen={showLogoutModal}
          onRequestClose={() => setShowLogoutModal(false)}
          ariaHideApp={false}
          shouldCloseOnEsc
          shouldCloseOnOverlayClick
          style={{
            overlay: {
              backgroundColor: "rgba(0, 0, 0, 0.8)",
              zIndex: 50,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              padding: "8px",
            },
            content: {
              position: "relative",
              inset: "auto",
              width: "100%",
              maxWidth: "500px",
              minHeight: "10vh",
              padding: "0",
              border: "none",
              borderRadius: "8px",
              overflow: "hidden",
              zIndex: 1000,
            },
          }}
        >
          <div className="rounded-md p-2 text-center h-full flex flex-col justify-between">
            <h2 className="text-xl font-semibold mb-4">Confirm Logout</h2>
            <p className="text-sm text-gray-600 mb-6">
              Are you sure you want to logout?
            </p>
            <div className="flex justify-between gap-2">
              <button
                onClick={logout}
                className="w-full py-2 cursor-pointer bg-red-600 text-white rounded-md hover:bg-red-700"
              >
                Logout
              </button>
              <button
                onClick={() => setShowLogoutModal(false)}
                className="w-full py-2 cursor-pointer bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400"
              >
                Cancel
              </button>
            </div>
          </div>
        </Modal>
      )}
    </header>
  );
};

export default HeaderComponent;
