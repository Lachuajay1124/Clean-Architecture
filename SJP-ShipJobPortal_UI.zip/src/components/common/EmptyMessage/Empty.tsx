import React, { FC, ReactNode } from "react";
import { Briefcase } from "lucide-react";

interface EmptyProps {
  icon?: ReactNode; // Can pass any icon component
  title: string;
  description?: string;
}

export const Empty: FC<EmptyProps> = ({ icon, title, description }) => {
  return (
    <div className="flex flex-col justify-center items-center space-y-2 h-full">
      {icon ?? <Briefcase size={24} className="text-indigo-600" />}
      <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
      {description && (
        <p className="text-gray-500 text-sm max-w-lg mx-auto">{description}</p>
      )}
    </div>
  );
};
