import { StylesConfig, GroupBase } from "react-select";

type OptionType = {
  value: number;
  label: string;
};

export const customSelectStyles: StylesConfig<
  OptionType,
  false,
  GroupBase<OptionType>
> = {
  control: (base) => ({
    ...base,
    minHeight: "36px",
    fontSize: "0.85rem", // smaller font
    border: "1px solid #e5e7eb",
    borderRadius: "6px",
    boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1)",
    "&:hover": {
      borderColor: "#3b82f6",
    },
  }),
  singleValue: (base) => ({
    ...base,
    fontSize: "0.85rem", // smaller font
  }),
  input: (base) => ({
    ...base,
    fontSize: "0.85rem", // smaller font when typing
  }),
  option: (base, state) => ({
    ...base,
    fontSize: "0.85rem", // smaller font
    backgroundColor: state.isFocused ? "#dbeafe" : "white",
    color: "#374151",
    "&:hover": {
      backgroundColor: "#dbeafe",
    },
  }),
  menu: (base) => ({
    ...base,
    zIndex: 100000,
  }),
  menuPortal: (base) => ({ ...base, zIndex: 100000 }),
};
