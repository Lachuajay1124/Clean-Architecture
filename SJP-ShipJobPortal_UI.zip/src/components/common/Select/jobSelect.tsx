// JobSelect.tsx
"use client";

import React, { useEffect, useMemo, useCallback } from "react";
import Select, { SingleValue } from "react-select";
import Cookies from "js-cookie";
import { usePathname } from "next/navigation";
import { useJobFilterStore } from "@/store/useFilterStore";
import { useAllJobPostedByRecruiterFilteredList } from "@/hooks/listingHooks/useListingHooks";
import { useJobSelectStore } from "@/store/useJobSelectStore";
import { LoadingSpinner } from "../Layout/Loader/loader";
import { customSelectStyles } from "./select";

export type JobSummary = { jobId: number; jobTitle: string };
type Option = { value: number; label: string };

export const JobSelect: React.FC = () => {
  const pathname = usePathname();

  // Cookie may be missing on first render; fall back to 0
  const rawUserId = Cookies.get("userId");
  const userId = Number.isFinite(Number(rawUserId)) ? Number(rawUserId) : 0;

  const { positionId, vesselTypeId, locationId, durationId } =
    useJobFilterStore();
  const { selectedJobId, setSelectedJob } = useJobSelectStore();

  const {
    data: allJobsTitle,
    isLoading: isJobsLoading,
    isError: isJobError,
  } = useAllJobPostedByRecruiterFilteredList({
    positionId,
    vesselTypeId,
    locationId,
    durationId,
    userId,
  });

  const summaries: JobSummary[] = useMemo(
    () =>
      (allJobsTitle ?? []).map((j: JobSummary) => ({
        jobId: j.jobId,
        jobTitle: j.jobTitle,
      })),
    [allJobsTitle]
  );

  const options: Option[] = useMemo(
    () => summaries.map((s) => ({ value: s.jobId, label: s.jobTitle })),
    [summaries]
  );

  // If nothing selected yet but we have data, default to the first job
  useEffect(() => {
    if (!selectedJobId && summaries.length > 0) {
      setSelectedJob(summaries[0].jobId, summaries[0].jobTitle);
    }
  }, [selectedJobId, summaries, setSelectedJob]);

  // 🔁 On route change, always reset to the first job from the current API data
  useEffect(() => {
    if (summaries.length > 0) {
      const first = summaries[0];
      if (selectedJobId !== first.jobId) {
        setSelectedJob(first.jobId, first.jobTitle);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname, summaries]); // summaries included so it works when data refetches on new route

  const selectedOption: Option | null = useMemo(() => {
    const match = summaries.find((s) => s.jobId === selectedJobId);
    return match ? { value: match.jobId, label: match.jobTitle } : null;
  }, [summaries, selectedJobId]);

  const handleChange = useCallback(
    (opt: SingleValue<Option>) => {
      if (opt) {
        setSelectedJob(opt.value, opt.label);
      } else if (summaries[0]) {
        setSelectedJob(summaries[0].jobId, summaries[0].jobTitle);
      }
    },
    [setSelectedJob, summaries]
  );

  if (isJobsLoading)
    return (
      <p className="text-sm text-gray-600">
        <LoadingSpinner />
      </p>
    );
  if (isJobError)
    return <p className="text-sm text-red-600">Failed to load jobs.</p>;
  if (!summaries.length) return null;

  return (
    <div className="w-full">
      <Select
        options={options}
        onChange={handleChange}
        styles={customSelectStyles}
        // ensure the UI reflects the forced-first selection after route change
        value={selectedOption ?? options[0] ?? null}
        menuPortalTarget={
          typeof window !== "undefined" ? document.body : undefined
        }
        placeholder="Select Job Position"
        className="react-select-container text-sm"
        classNamePrefix="react-select"
        aria-label="Select job position filter"
      />
    </div>
  );
};
