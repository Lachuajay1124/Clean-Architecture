"use client";
import { useEffect } from "react";

export default function ServiceWorkerRegister() {
  useEffect(() => {
    if (
      process.env.NODE_ENV === "development" ||
      !("serviceWorker" in navigator)
    ) {
      console.warn("❌ Skipping SW in development or unsupported browser.");
      return;
    }

    navigator.serviceWorker
      .register("/sw.js", { scope: "/" })
      .then((registration) => {
        console.log("✅ SW registered successfully:", registration.scope);

        registration.onupdatefound = () => {
          const installingWorker = registration.installing;
          installingWorker?.addEventListener("statechange", () => {
            if (installingWorker.state === "installed") {
              if (navigator.serviceWorker.controller) {
                console.log("🔄 New content is available, please refresh.");
              } else {
                console.log("🎉 Content is cached for offline use.");
              }
            }
          });
        };
      })
      .catch((error) => {
        console.error("❌ SW registration failed:", error);
      });
  }, []);
  return null;
}
