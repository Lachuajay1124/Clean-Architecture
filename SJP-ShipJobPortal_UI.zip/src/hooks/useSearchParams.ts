"use client";

import { useSearchParams } from "next/navigation";

export const useSafeSearchParams = () => {
  const searchParams = useSearchParams();
  const getParam = (key: string) => searchParams?.get(key) ?? null;
  const hasParam = (key: string) => searchParams?.has(key);

  return {
    searchParams,
    getParam,
    hasParam,
  };
};
