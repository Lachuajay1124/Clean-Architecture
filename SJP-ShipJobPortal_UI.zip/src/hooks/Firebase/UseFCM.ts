// hooks/useFCM.js
import { useEffect, useState } from "react";
import {
  getMessaging,
  getToken,
  onMessage,
  isSupported,
} from "firebase/messaging";
import { firebaseApp } from "../../lib/firebase-config";

const useFCM = () => {
  const [token, setToken] = useState("");
  const [notificationPermission, setNotificationPermission] =
    useState("default");

  useEffect(() => {
    const retrieveToken = async () => {
      const supported = await isSupported();
      if (!supported) {
        console.warn("Firebase Messaging is not supported in this browser.");
        return;
      }

      try {
        const messaging = getMessaging(firebaseApp);

        const permission = await Notification.requestPermission();
        setNotificationPermission(permission);

        if (permission === "granted") {
          const registration = await navigator.serviceWorker.register(
            "/firebase-messaging-sw.js"
          );

          const currentToken = await getToken(messaging, {
            vapidKey: process.env.NEXT_PUBLIC_FIREBASE_TOKEN,
            serviceWorkerRegistration: registration,
          });

          if (currentToken) {
            setToken(currentToken);
          } else {
          }
        }
      } catch (err) {
        console.error("Error retrieving FCM token:", err);
      }
    };

    if (
      typeof window !== "undefined" &&
      "Notification" in window &&
      "serviceWorker" in navigator
    ) {
      retrieveToken();
    }
  }, []);

  useEffect(() => {
    const setupOnMessage = async () => {
      const supported = await isSupported();
      if (!supported) return;

      const messaging = getMessaging(firebaseApp);

      const unsubscribe = onMessage(messaging, (payload) => {
        alert(payload.notification?.title || "New Notification");
      });

      return unsubscribe;
    };

    setupOnMessage();
  }, []);

  return { token, notificationPermission };
};

export default useFCM;
