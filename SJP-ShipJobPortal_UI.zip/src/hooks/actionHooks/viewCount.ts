import { useMutation } from "@tanstack/react-query";

import type { SaveJobs } from "@/app/api/jobsApi/types";
import { jobViewCountUpdate } from "@/app/api/ListingApi/listingApiForTablesEtc";

export const useJobViewCount = (onSuccessCallback: () => void) => {
  return useMutation({
    mutationFn: (data: SaveJobs) => jobViewCountUpdate(data),
    onSuccess: () => {
      onSuccessCallback();
    },
    onError: () => {},
  });
};
