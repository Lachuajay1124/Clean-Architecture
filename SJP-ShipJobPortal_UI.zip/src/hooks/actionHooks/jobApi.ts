import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";

import { applyJob } from "@/app/api/jobsApi/job";
import type { JobApplicationPayload } from "@/app/api/jobsApi/types";

export const useApplyJob = (onSuccessCallback: () => void) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: JobApplicationPayload) => applyJob(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["jobsForCandidates"] });
      toast.success("Job Applied successfully");
      onSuccessCallback();
    },
    onError: (error: unknown) => {
      const err = error as Error;
      toast.error(`Failed to Apply job: ${err.message}`);
    },
  });
};
