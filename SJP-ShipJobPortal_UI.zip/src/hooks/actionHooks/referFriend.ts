import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";

import { referJob } from "@/app/api/jobsApi/job";
import type { ReferJobs } from "@/app/api/jobsApi/types";

export const useReferJob = (onSuccessCallback: () => void) => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: ReferJobs) => referJob(data),
    onSuccess: (response) => {
      queryClient.invalidateQueries({ queryKey: ["jobsForCandidates"] });
      toast.success(response?.message ?? "Referred Successfully");
      onSuccessCallback();
    },
    onError: (error: unknown) => {
      const err = error as Error;
      toast.error(`Failed to Refer: ${err.message}`);
    },
  });
};
