import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";

import { saveJob } from "@/app/api/jobsApi/job";
import type { SaveJobs } from "@/app/api/jobsApi/types";

export const useSaveJob = (onSuccessCallback: () => void) => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: SaveJobs) => saveJob(data),
    onSuccess: (response) => {
      const successMessage =
        response?.message || "Job Status Changed successfully";
      queryClient.invalidateQueries({ queryKey: ["jobsForCandidates"] });
      queryClient.invalidateQueries({ queryKey: ["allSavedJobsByCandidate"] });
      toast.success(successMessage);
      onSuccessCallback();
    },
    onError: (error: unknown) => {
      const err = error as Error;
      toast.error(`Failed to change job status: ${err.message}`);
    },
  });
};
