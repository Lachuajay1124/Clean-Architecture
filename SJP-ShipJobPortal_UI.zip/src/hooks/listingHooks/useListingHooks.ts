// React Query
import { keepPreviousData, useQuery } from "@tanstack/react-query";

/* ------------------ API Imports ------------------ */

// 📌 Dropdown Listing APIs
import {
  getAllCompany,
  getAllContractDuration,
  getAllCountries,
  getAllPosition,
  getAllVesselType,
} from "@/app/api/ListingApi/ListingApiForDropdown";

// 📌 General Listing & Profile APIs
import {
  getAllAppliedCandidateProfile,
  getAllAppliedCandidates,
  getAllJobAppliedByCandidate,
  getAllJobForCandidates,
  getAllJobFromRecruiter,
  getAllJobFromRecruiterAfterFilter,
  getAllMatchingCandidates,
  getAllSavedJobByCandidate,
  getCompanyProfile,
} from "@/app/api/ListingApi/listingApiForTablesEtc";

// 📌 Candidate Job APIs

/* ------------------ Type Definitions ------------------ */

// 📌 Dropdown Listing Types
import type {
  Company,
  ContractDuration,
  Country,
  Position,
  VesselType,
} from "@/types/listingApiTypes";

// 📌 General Listing & Profile Types
import type {
  AppliedJobByCandidate,
  CandidateFilterParams,
  CandidateList,
  Job,
  JobFilterParams,
  JobResponse,
  MatchingCandidateList,
  SeafarerProfileData,
  recruiterCompanyProfileData,
  videoResume,
} from "@/types/getApiTypes";
import { UserResumeVideoGet } from "@/app/api/UserApi/UserCrud";

// Reference data (rarely changes) — long-lived cache, no focus refetchs
export const useAllCompanyList = () =>
  useQuery<Company[]>({
    queryKey: ["companies"],
    queryFn: getAllCompany,
    staleTime: 1000 * 60 * 60,
    gcTime: 1000 * 60 * 60 * 12,
    refetchOnWindowFocus: false,
    retry: 1,
  });

export const useAllContractDurationList = () =>
  useQuery<ContractDuration[]>({
    queryKey: ["ContractDuration"],
    queryFn: getAllContractDuration,
    staleTime: 1000 * 60 * 60,
    gcTime: 1000 * 60 * 60 * 12,
    refetchOnWindowFocus: false,
    retry: 1,
  });

export const useAllCountryList = () =>
  useQuery<Country[]>({
    queryKey: ["countries"],
    queryFn: getAllCountries,
    staleTime: 1000 * 60 * 60,
    gcTime: 1000 * 60 * 60 * 24,
    refetchOnWindowFocus: false,
    retry: 1,
  });

export const useAllVesselTypesList = () =>
  useQuery<VesselType[]>({
    queryKey: ["VesselType"],
    queryFn: getAllVesselType,
    staleTime: 1000 * 60 * 60,
    gcTime: 1000 * 60 * 60 * 12,
    refetchOnWindowFocus: false,
    retry: 1,
  });

export const useAllPositionList = () =>
  useQuery<Position[]>({
    queryKey: ["Position"],
    queryFn: getAllPosition,
    staleTime: 1000 * 60 * 60,
    gcTime: 1000 * 60 * 60 * 12,
    refetchOnWindowFocus: false,
    retry: 1,
  });

// Lists with filters — avoid flicker and needless refetches
export const useAllJobPostedByRecruiter = (params: JobFilterParams) =>
  useQuery<JobResponse>({
    queryKey: ["jobByRecruiter", params],
    queryFn: () => getAllJobFromRecruiter(params),
    staleTime: 1000 * 30,
    gcTime: 1000 * 60 * 30,
    placeholderData: keepPreviousData,
    refetchOnWindowFocus: false,
    retry: 1,
  });

export const useAllAvailableJobForCandidates = (
  params: CandidateFilterParams
) =>
  useQuery<JobResponse>({
    queryKey: ["jobsForCandidates", params],
    queryFn: () => getAllJobForCandidates(params),
    staleTime: 1000 * 30,
    gcTime: 1000 * 60 * 30,
    placeholderData: keepPreviousData,
    refetchOnWindowFocus: false,
    retry: 1,
  });

export const useAllJobPostedByRecruiterFilteredList = (
  params: JobFilterParams
) =>
  useQuery<Job[]>({
    queryKey: ["jobByRecruiterForFilter", params],
    queryFn: () => getAllJobFromRecruiterAfterFilter(params),
    staleTime: 1000 * 30,
    gcTime: 1000 * 60 * 30,
    placeholderData: keepPreviousData,
    refetchOnWindowFocus: false,
    retry: 1,
  });

export const useAllCandidateDetails = (params: CandidateFilterParams) =>
  useQuery<CandidateList>({
    queryKey: ["appliedCandidateData", params],
    queryFn: () => getAllAppliedCandidates(params),
    staleTime: 1000 * 20,
    gcTime: 1000 * 60 * 30,
    placeholderData: keepPreviousData,
    refetchOnWindowFocus: false,
    enabled: params.jobId !== undefined && params.jobId !== null,
    retry: 1,
  });

export const useAllMatchingCandidateDetails = (params: CandidateFilterParams) =>
  useQuery<MatchingCandidateList>({
    queryKey: ["matchingCandidateData", params],
    queryFn: () => getAllMatchingCandidates(params),
    staleTime: 1000 * 20,
    gcTime: 1000 * 60 * 30,
    placeholderData: keepPreviousData,
    refetchOnWindowFocus: false,
    enabled: params.jobId !== undefined && params.jobId !== null,
    retry: 1,
  });

export const useAllAppliedJobsByCandidate = (params: CandidateFilterParams) =>
  useQuery<AppliedJobByCandidate>({
    queryKey: ["allAppliedJobsByCandidate", params],
    queryFn: () => getAllJobAppliedByCandidate(params),
    staleTime: 1000 * 30,
    gcTime: 1000 * 60 * 30,
    placeholderData: keepPreviousData,
    refetchOnWindowFocus: false,
    retry: 1,
  });

export const useAllSavedJobsByCandidate = (params: CandidateFilterParams) =>
  useQuery<AppliedJobByCandidate>({
    queryKey: ["allSavedJobsByCandidate", params],
    queryFn: () => getAllSavedJobByCandidate(params),
    staleTime: 1000 * 30,
    gcTime: 1000 * 60 * 30,
    placeholderData: keepPreviousData,
    refetchOnWindowFocus: false,
    retry: 1,
  });

export const useAllJobAppliedCandidatesProfile = (
  params: CandidateFilterParams
) =>
  useQuery<SeafarerProfileData>({
    queryKey: ["AppliedCandidateProfile", params],
    queryFn: () => getAllAppliedCandidateProfile(params),
    staleTime: 1000 * 60,
    gcTime: 1000 * 60 * 60,
    refetchOnWindowFocus: false,
    retry: 1,
  });

export const useCompanyProfile = (params: CandidateFilterParams) =>
  useQuery<recruiterCompanyProfileData>({
    queryKey: ["CompanyProfile", params],
    queryFn: () => getCompanyProfile(params),
    staleTime: 1000 * 60,
    gcTime: 1000 * 60 * 60,
    refetchOnWindowFocus: false,
    retry: 1,
  });

export const useVideoResume = (userId: number, enabled = true) =>
  useQuery<videoResume>({
    queryKey: ["videoResumeUser", userId],
    queryFn: () => UserResumeVideoGet(userId),
    staleTime: 1000 * 60 * 5,
    gcTime: 1000 * 60 * 30,
    refetchOnWindowFocus: false,
    enabled: !!userId && enabled,
    retry: 1,
  });

// Documents (reference-ish)
export const useAllDocumentsList = () =>
  useQuery<Document[]>({
    queryKey: ["allDocumentsList"],
    placeholderData: keepPreviousData,
    staleTime: 1000 * 60 * 60,
    gcTime: 1000 * 60 * 60 * 12,
    refetchOnWindowFocus: false,
    retry: 1,
  });
