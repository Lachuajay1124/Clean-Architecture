"use client";

import { useEffect, useState } from "react";
import Cookies from "js-cookie";
import { usePathname } from "next/navigation";

//For development purposes, this hook simulates authentication state
//In a real application, you would replace this with actual authentication logic
//such as checking JWT tokens from your backend through api.

export function useAuth() {
  const pathname = usePathname();
  const [role, setRole] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const token = Cookies.get("SjpJwtToken");
    const storedRole = Cookies.get("user");

    if (token) {
      setIsAuthenticated(true);
    } else {
      setIsAuthenticated(false);
    }

    setRole(storedRole || "Seafarer");
    setLoading(false);
  }, [pathname]);

  return {
    user: role,
    isAuthenticated,
    loading,
  };
}

// Example of token validation with backend   For future use
// const verifyTokenWithBackend = async (token) => {
//   const response = await api.post("/api/verify-token", {
//     method: "POST",
//     headers: {
//       "Content-Type": "application/json",
//       Authorization: `Bearer ${token}`, // Send the token to the backend for validation
//     },
//   });

//   const data = await response.json();
//   if (data.isValid) {
//     setIsAuthenticated(true); // Token is valid
//   } else {
//     setIsAuthenticated(false); // Token is invalid
//   }
// };
