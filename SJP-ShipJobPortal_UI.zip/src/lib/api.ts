import api from "./axios";

// GET
export const getData = async <T>(url: string) => {
  const res = await api.get<T>(url);
  return res.data;
};

// POST
export const postData = async <T, B>(url: string, body: B) => {
  const res = await api.post<T>(url, body);
  return res.data;
};

// PUT
export const putData = async <T, B>(url: string, body: B) => {
  const res = await api.put<T>(url, body);
  return res.data;
};

// PATCH
export const patchData = async <T, B>(url: string, body: B) => {
  const res = await api.patch<T>(url, body);
  return res.data;
};

// DELETE
export const deleteData = async <T>(url: string) => {
  const res = await api.delete<T>(url);
  return res.data;
};
