import { initializeApp, getApps, FirebaseApp } from "firebase/app";
import { getMessaging, Messaging, isSupported } from "firebase/messaging";

const firebaseConfig = {
  apiKey: "AIzaSyBJ3URPLryTdvAY4WHGMAhEhkK-GYGn--U",
  authDomain: "sjp-prototype.firebaseapp.com",
  projectId: "sjp-prototype",
  storageBucket: "sjp-prototype.firebasestorage.app",
  messagingSenderId: "65675015070",
  appId: "1:65675015070:web:dbc6f1bd8a90b2880fdc8f",
  measurementId: "G-T3GX0WDB09",
};

// Singleton app instance
const firebaseApp: FirebaseApp =
  getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];

// Safe export of messaging (only in browser, and if supported)
const getFirebaseMessaging = async (): Promise<Messaging | null> => {
  if (typeof window === "undefined") return null;

  const supported = await isSupported();
  if (!supported) {
    console.warn("Firebase Messaging is not supported in this browser.");
    return null;
  }

  return getMessaging(firebaseApp);
};

export { firebaseApp, getFirebaseMessaging };
