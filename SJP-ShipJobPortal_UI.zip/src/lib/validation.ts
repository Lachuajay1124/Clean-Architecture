import { JobFilterParams } from "@/types/getApiTypes";
import { z } from "zod";

export const validateJobFilterParams = (
  params: Partial<JobFilterParams>
): JobFilterParams => {
  return {
    jobId: params?.jobId ?? 0,
    userId: params.userId ?? 0,
    companyId: params.companyId ?? 0,
    pageNumber: params.pageNumber ?? 1,
    positionId: params.positionId ?? 0,
    vesselTypeId: params.vesselTypeId ?? 0,
    locationId: params.locationId ?? 0,
    durationId: params.durationId ?? 0,
    candidateId: params.candidateId ?? 0,
    vacancyId: params.vacancyId ?? 0,
    pageSize: params.pageSize ?? 8,
    ...(params.searchKey ? { searchKey: params.searchKey.trim() } : {}),
  };
};

export const loginSchema = z.object({
  firstName: z.string().optional(),
  lastName: z.string().optional(),
  email: z
    .string()
    .min(1, "Email is required")
    .email("Please enter a valid email address"),
  password: z
    .string()
    .min(1, "Password is required")
    .min(6, "Password must be at least 6 characters long"),
  userRole: z.enum(["Seafarer", "Recruiter"], {
    required_error: "Please select a role",
  }),
  loginType: z.string(),
  oauthToken: z.string().optional(),
});

export type LoginFormData = z.infer<typeof loginSchema>;

export const sanitizeInput = (input: string) =>
  input.replace(/[^a-zA-Z0-9\s]/g, "");
