// src/lib/dal/apiClient.ts
import axios, { AxiosError } from "axios";

const Api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_BASE_URL,
  withCredentials: true, // default for everything
  timeout: 30000,
});

// Optional: central 401 handling (backend is source of truth)
Api.interceptors.response.use(
  (res) => res,
  async (err: AxiosError) => {
    if (err.response?.status === 401 && typeof window !== "undefined") {
      window.location.href = "/login";
    }
    throw err;
  }
);

export default Api;
