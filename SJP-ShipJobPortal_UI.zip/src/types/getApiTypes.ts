import { CertificateFormData } from "@/app/api/UserApi/UserCrud";

export interface Job {
  jobId: number;
  jobTitle: string;
  userId: number;
  companyId: number;
  company?: string;
  noVacancy: number;
  nationalityId: number;
  nationality?: string;
  openDate: string; // Format: YYYY-MM-DD
  closeDate: string; // Format: YYYY-MM-DD
  positionId: number;
  position?: string;
  sendNotification?: "Y" | "N";
  vesselTypeId: number;
  vesselType?: string | null;
  isSaved?: number | string;
  isApplied?: number | string;
  appliedcount?: number | string;
  viewcount?: number | string;

  // Long text fields
  companyDescription?: string;
  whatToExpect?: string;
  disclaimer?: string;
  pleaseNote?: string;

  // Multi requirements (position + experience)
  requirements?: Array<{
    positionId: number;
    expYears: number;
    expMonths: number;
  }>;

  // Extra / optional
  documents?: Array<{ documentId: number; isMandatory: boolean }>;
}

interface pagination {
  totalItems: number;
  totalPages: number;
  currentPage: number;
  itemsPerPage: number;
}

export interface JobResponse {
  pagination: pagination;
  jobsList: Job[];
}

export interface JobApplication {
  applicationId: number;
  jobId: number;
  jobTitle: string;
  nationalityId: number;
  nationality: string;
  jobStatus: string;
  companyId: number;
  companyName: string;
  appliedDate: string;
  closeDate: string;
  noVacancy?: number;
  email?: string;
}

export interface AppliedJobByCandidate {
  pagination: pagination;
  jobsList: JobApplication[];
}

export interface JobFilterParams {
  jobId?: number | null;
  userId?: number | null;
  candidateId?: number | null;
  companyId?: number | null;
  positionId?: number | null;
  vesselTypeId?: number | null;
  locationId?: number | null;
  durationId?: number | null;
  searchKey?: string | null;
  pageNumber?: number | null;
  pageSize?: number | null;
  vacancyId?: number | null;
}

export interface CandidateFilterParams {
  pageSize?: number | null;
  pageNumber?: number | null;
  jobId?: number | null;
  searchKey?: string | null;
  userId?: number | null;
  candidateId?: number | null;
  positionId?: number | null;
  vesselTypeId?: number | null;
  locationId?: number | null;
  durationId?: number | null;
  vacancyId?: number | null;
}

export interface Candidate {
  applicationId: number;
  userId: number;
  firstName: string;
  designation: string | null;
  salaryExpected: number | null;
  email: string;
  dateOfAvailability: string | number;
  jobId: number;
  nationality: string | null;
  address: string | null;
  totalYearsOfExperiance: number | null;
  appliedDate?: string;
  image?: string;
  avatar?: string;
}
export interface CandidateList {
  pagination: pagination;
  candidatesList: Candidate[];
}

export interface Candidates {
  candidateid: number;
  name: string;
  email: string;
  experience: string;
  salaryexpected: string;
  education: string;
  selected?: boolean;
  designation: string;
  nationality?: string;
}
export interface MatchingCandidateList {
  pagination: pagination;
  candidates: Candidates[];
}

export interface SeafarerProfileData {
  userid: number | null;
  name: string;
  age: number | null;
  avatar: string | null;
  email: string | null;
  phoneNumber: string | null;
  rank: string | null;
  rating: string | null;
  nationality: string | null;
  location: string | null;
  totalSeaTime: string | null;
  lastVessel: string | null;
  dateofAvailability: string | null;
  certificates: CertificateFormData[];
  experiances: ExperienceFormData[];
}

export interface recruiterCompanyProfileData {
  city: string;
  companyaddress: string;
  companyid: number;
  companyname: string;
  contactnumber: string;
  country: string;
  email: string;
  postalcode: string;
  state: string;
  website: string;
}

export interface videoResume {
  data: string;
}

export interface ExperienceFormData {
  experianceId: string | null; // null or 0 => add, >0 => edit
  vesselName: string | null;
  vesselType: string | null;
  rank: string | null;
  companyName: string | null;
  duration: string | null;
  dwt: string | null;
  period: string | null;
  position: string | null;
  route: string | null;
  gt: string | null;
  fromDate: string | null; // 'YYYY-MM-DD'
  engineType: string | null;
  ias: string | null;
  kw: string | null;
  toDate: string | null; // 'YYYY-MM-DD'
}
