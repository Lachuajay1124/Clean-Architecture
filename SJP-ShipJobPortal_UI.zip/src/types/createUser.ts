import { z } from "zod";

export interface ApplicantData {
  [key: string]: string;
}

export interface DocumentData {
  [key: string]: string;
}

export interface ExperienceData {
  [key: string]: string;
}

export interface ResumeData {
  userId: number;
  applicant: ApplicantData;
  documents: DocumentData[];
  sea_experience: ExperienceData[];
}

export interface ParsedResult {
  filename: string;
  parsed_result: ResumeData;
}

export const seafarerSchema = z.object({
  firstName: z
    .string()
    .min(2, "First name must be at least 2 characters")
    .max(50, "First name must be less than 50 characters")
    .regex(/^[a-zA-Z\s]+$/, "Only letters and spaces are allowed"),

  lastName: z
    .string()
    .max(50, "Last name must be less than 50 characters")
    .regex(/^[a-zA-Z\s]*$/, "Only letters and spaces are allowed"),

  email: z.string().email("Invalid email format").min(1, "Email is required"),

  role: z.union([z.literal("Seafarer"), z.literal("Recruiter"), z.string()]),

  companyName: z
    .string()
    .min(2, "Company name must be at least 2 characters")
    .max(50, "Company name must be less than 50 characters")
    .regex(/^[a-zA-Z\s]+$/, "Only letters and spaces are allowed")
    .optional(),

  loginType: z.union([
    z.literal("portal"),
    z.literal("google"),
    z.literal("facebook"),
    z.literal("linkedin"),
    z.string(),
  ]),

  password: z
    .string()
    .min(8, "Password must be at least 8 characters")
    .regex(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])/,
      "Password must include uppercase, lowercase, number, and special character"
    )
    .optional(),

  oauthToken: z.string().optional(),
});

export type SeafarerFormData = z.infer<typeof seafarerSchema>;
