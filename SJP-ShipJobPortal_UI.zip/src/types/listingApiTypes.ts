export interface Company {
  companyID: number;
  companyName: string;
}

export interface Country {
  id: number;
  code: string;
  countryName: string;
  //id
}

export interface ContractDuration {
  durationId: number;
  value: number;
  contractMonths: string;
  //contract
}

export interface VesselType {
  typeID: number;
  vesselCode: string;
  vesseltype: string;
  //type
}

export interface Position {
  id: number;
  name: string;
  //id
}
