import "./globals.css";
import "react-toastify/dist/ReactToastify.css";

import { Suspense } from "react";
import { Inter } from "next/font/google";
import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";
import ReactQueryProvider from "./(roles)/Wrapper/reactQuerry";
import type { Metadata, Viewport } from "next";
import ServiceWorkerRegister from "@/hooks/PWA/usePWA";
import dynamic from "next/dynamic";
import { ToastContainer } from "react-toastify";

const FCMTest = dynamic(() => import("@/components/FCMTest"));

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#0ea5e9",
};

export const metadata: Metadata = {
  manifest: "/manifest.json",
  metadataBase: new URL("http://10.60.120.76:3006"),
  title: { default: "SJP", template: "%s | SJP" },
  description: "SJP is a job portal website.",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-snippet": -1,
      "max-image-preview": "large",
      "max-video-preview": -1,
    },
  },
  icons: {
    icon: "/images/Seahire1.avif",
    shortcut: "/images/Seahire1.avif",
    apple: "/images/Seahire1.avif",
  },
  openGraph: {
    title: "SJP",
    description: "SJP is a job portal website.",
    url: "/",
    siteName: "SJP",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en"
      className={`${inter.variable} scroll-smooth`}
      suppressHydrationWarning
    >
      <body className="font-sans text-black antialiased min-h-screen bg-white">
        <ToastContainer
          position="top-right"
          autoClose={3000}
          hideProgressBar={false}
          newestOnTop
          closeOnClick
          pauseOnHover
          draggable
          theme="light"
          className="rounded-md"
          aria-live="assertive"
        />
        <ServiceWorkerRegister />
        <FCMTest aria-live="polite" />

        <Suspense fallback={<LoadingSpinner />}>
          <ReactQueryProvider>{children}</ReactQueryProvider>
        </Suspense>
      </body>
    </html>
  );
}
