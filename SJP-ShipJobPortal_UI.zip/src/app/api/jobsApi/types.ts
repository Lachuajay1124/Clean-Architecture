export interface ReferJobs {
  userId: number;
  friendEmail: string;
  friendName: string;
}

export interface JobApplicationPayload {
  userId: number;
  jobId: number;
  coverLetter?: string;
  resumeFile?: string;
  notes?: string;
}

export interface SaveJobs {
  jobId: number;
  mode?: string;
}
