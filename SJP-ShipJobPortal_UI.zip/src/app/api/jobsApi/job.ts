import { JobApplicationPayload, ReferJobs, SaveJobs } from "./types";
import api from "@/lib/axios";
import { CreateJobFormData } from "@/components/common/Layout/Modal/RecruiterModal/JobCrud/job";

/**
 * Create new job vacancy
 */
export const createJob = async (data: CreateJobFormData) => {
  try {
    const response = await api.post(`/JobPost/createJobVacancy`, data, {});
    return response.data;
  } catch (error) {
    throw error;
  }
};

/**
 * Update an existing job vacancy
 */
export const updateJob = async (data: CreateJobFormData, vacancyId: number) => {
  try {
    const response = await api.patch(
      `/JobPost/editJobVacancy?jobId=${encodeURIComponent(vacancyId)}`,
      data,
      {}
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

/**
 * Delete a job vacancy by ID
 */
export const deleteJob = async (vacancyId: number) => {
  try {
    const response = await api.post(`/JobPost/delete/${vacancyId}`, {});
    return response.data;
  } catch (error) {
    throw error;
  }
};

/**
 * Apply for a job
 */
export const applyJob = async (data: JobApplicationPayload) => {
  try {
    const response = await api.post(`/JobApply/apply-job`, data, {});
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const saveJob = async (data: SaveJobs) => {
  try {
    const response = await api.post(`/JobApply/favouriteJob`, data, {});
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const editJobCandidate = async (vacancyId: number) => {
  try {
    const response = await api.patch(
      `/JobPost/editJobVacancy?vacancyId=${(encodeURIComponent(vacancyId), {})}`
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const referJob = async (data: ReferJobs) => {
  try {
    const response = await api.post(`/Profile/refer`, data, {});
    return response.data;
  } catch (error) {
    throw error;
  }
};
