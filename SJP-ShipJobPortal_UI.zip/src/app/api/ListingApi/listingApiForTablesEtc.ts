import {
  CandidateFilterParams,
  CandidateList,
  Job,
  JobFilterParams,
  JobResponse,
  MatchingCandidateList,
  recruiterCompanyProfileData,
  SeafarerProfileData,
  AppliedJobByCandidate,
} from "@/types/getApiTypes";

import Cookies from "js-cookie";
import api from "@/lib/axios";
import { validateJobFilterParams } from "@/lib/validation";
import { SaveJobs } from "../jobsApi/types";

/**
 * Get all job listings created by a recruiter (full response)
 */
export const getAllJobFromRecruiter = async (
  params: JobFilterParams
): Promise<JobResponse> => {
  const userId = Number(Cookies.get("userId")) ?? "";
  const safeParams = validateJobFilterParams({
    ...params,
    userId: userId,
  });

  try {
    const response = await api.get(`/JobPost/getJobsbyUser`, {
      params: safeParams,
    });

    return response.data?.data;
  } catch (error) {
    throw error;
  }
};

/**
 * Get job listings by recruiter, but only the jobsList array (used for filters/search)
 */
export const getAllJobFromRecruiterAfterFilter = async (
  params: JobFilterParams
): Promise<Job[]> => {
  const safeParams = validateJobFilterParams({
    ...params,
    companyId: 1,
  });
  try {
    const response = await api.get(`/JobPost/getJobsbyUser`, {
      params: safeParams,
    });

    return response.data.data.jobsList || [];
  } catch (error) {
    throw error;
  }
};

/**
 * Get all jobs visible to candidates (vacancy list)
 */
export const getAllJobForCandidates = async (
  params: CandidateFilterParams
): Promise<JobResponse> => {
  const userId = Number(Cookies.get("userId")) || 0; // read directly from cookie

  const safeParams = validateJobFilterParams({
    ...params,
    candidateId: userId,
  });
  try {
    const response = await api.get(`/JobPost/getJobVacancy`, {
      params: safeParams,
    });

    return response.data.data;
  } catch (error) {
    throw error;
  }
};

/**
 * Get all applied candidates for a job
 */
export const getAllAppliedCandidates = async (
  params: CandidateFilterParams
): Promise<CandidateList> => {
  const safeParams = validateJobFilterParams({
    ...params,
    jobId: params.jobId,
    companyId: 1,
    pageNumber: params.pageNumber ?? 1,
    pageSize: params.pageSize ?? 8,
  });
  try {
    const response = await api.get(`/JobApply/applied-candidates`, {
      params: safeParams,
    });

    return response.data.data;
  } catch (error) {
    throw error;
  }
};

export const getAllMatchingCandidates = async (
  params: CandidateFilterParams
): Promise<MatchingCandidateList> => {
  const safeParams = validateJobFilterParams({
    ...params,
    jobId: params.jobId,
    companyId: 1,
    pageNumber: params.pageNumber ?? 1,
    pageSize: params.pageSize ?? 8,
  });

  try {
    const response = await api.get(`/Matching/matchingCandidate`, {
      params: safeParams,
    });
    return response.data.data;
  } catch (error) {
    throw error;
  }
};

export const getAllAppliedCandidateProfile = async (
  params: CandidateFilterParams
): Promise<SeafarerProfileData> => {
  const safeParams = validateJobFilterParams({
    ...params,
    jobId: params.userId,
  });
  try {
    const response = await api.get(`/Profile/seafarer-profile`, {
      params: safeParams,
    });
    return response.data.data;
  } catch (error) {
    throw error;
  }
};

export const getCompanyProfile = async (
  params: CandidateFilterParams
): Promise<recruiterCompanyProfileData> => {
  const userId = Number(Cookies.get("userId")) ?? "";
  const safeParams = validateJobFilterParams({
    ...params,
    jobId: params.userId,
    userId: userId,
  });
  try {
    const response = await api.get(`/Profile/companyprofile?companyId=1`, {
      params: safeParams,
    });

    return response.data.data;
  } catch (error) {
    throw error;
  }
};

export const getAllSavedJobByCandidate = async (
  params: JobFilterParams
): Promise<AppliedJobByCandidate> => {
  const userId = Number(Cookies.get("userId")) || 0; // read directly from cookie

  const safeParams = validateJobFilterParams({
    ...params,
    userId: userId,
  });
  try {
    const response = await api.get(`/JobApply/savedJobs`, {
      params: safeParams,
    });

    return response?.data?.data;
  } catch (error) {
    throw error;
  }
};

export const getAllJobAppliedByCandidate = async (
  params: JobFilterParams
): Promise<AppliedJobByCandidate> => {
  const userId = Number(Cookies.get("userId")) || 0; // read directly from cookie

  const safeParams = validateJobFilterParams({
    ...params,
    userId: userId,
  });
  try {
    const response = await api.get(`/JobApply/applied-Jobs`, {
      params: safeParams,
    });

    return response.data?.data;
  } catch (error) {
    throw error;
  }
};

export const jobViewCountUpdate = async (data: SaveJobs) => {
  try {
    const response = await api.post(`/JobPost/jobcount`, data, {});
    return response.data;
  } catch (error) {
    throw error;
  }
};
