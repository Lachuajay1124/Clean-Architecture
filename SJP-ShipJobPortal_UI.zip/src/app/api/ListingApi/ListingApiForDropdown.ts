import api from "@/lib/axios";

/**
 * Generic GET handler for API endpoints
 */
const apiGet = async (endpoint: string) => {
  try {
    const response = await api.get(`${endpoint}`, {});
    return response.data.data;
  } catch (error) {
    throw error;
  }
};

/**
 * Get all contract durations
 */
export const getAllContractDuration = () =>
  apiGet("/GetList/getAllContractduration");

/**
 * Get all companies
 */
export const getAllCompany = () => apiGet("/Company/getAllCompanies");

/**
 * Get all countries
 */
export const getAllCountries = () => apiGet("/GetList/getAllCountries");

/**
 * Get all vessel types
 */
export const getAllVesselType = () => apiGet("/GetList/getAllVesseltype");

/**
 * Get all positions (for a given companyId)
 */
export const getAllPosition = () =>
  apiGet(`/GetList/getAllposition?companyId=1`);
