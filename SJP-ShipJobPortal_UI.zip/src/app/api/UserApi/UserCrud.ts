import api from "@/lib/axios";
import { ResumeData } from "@/types/createUser";

export interface createUserType {
  role: string;
  firstName: string;
  surname: string;
  email: string;
  password: string;
  lastName: string;
  loginType: string;
}

export interface createUserResumeType {
  userId: number;
  resumeFile: string;
  imageFile: string;
  imageUrl: string;
}
export interface createUserResumeVideo {
  userId: number | string;
  file: File;
}

export interface UserRegistrationOtp {
  email: string;
}

export interface UserRegistrationOtpVerify {
  emailid: string;
  otp: string;
  ipAddress: "";
}

export interface UserRegistrationPayload {
  firstName: string;
  lastName: string;
  email: string;
  role: "Seafarer" | "Recruiter" | string;
  loginType: "portal" | string;
  password?: string;
  oauthToken?: string;
  companyName?: string;
}

type ApiResponse<T = unknown> = {
  success: boolean;
  data: T | null;
  message: string;
  errorCode?: string | null;
};

export interface ExperienceFormData {
  experianceId: string | null;
  vesselName: string | null;
  vesselType: string | null;
  rank: string | null;
  companyName: string | null;
  duration: string | null;
  dwt: string | null;
  period: string | null;
  position: string | null;
  route: string | null;
  gt: string | null;
  fromDate: string | null;
  engineType: string | null;
  ias: string | null;
  kw: string | null;
  toDate: string | null;
}

export interface CertificateFormData {
  certificateId: string | null; // null or 0 => add, >0 => edit
  certificateName: string | null;
  issuedDate: string | null; // 'YYYY-MM-DD'
  issuedCountry: string | null;
  expiryDate: string | null; // 'YYYY-MM-DD'
  status: string | null;
  documentNumber: string | null;
}
export const otpSentForEmail = async (data: UserRegistrationOtp) => {
  try {
    const response = await api.post(`/Login/otpSent`, data, {});

    if (response.data?.success === false) {
      throw new Error(response.data?.message || "Otp sending failed.");
    }

    return response.data;
  } catch (error) {
    throw error;
  }
};

export const otpVerifyForEmail = async (data: UserRegistrationOtpVerify) => {
  try {
    const response = await api.post(`/Login/userOtpVerify`, data, {});

    if (response.data?.success === false) {
      throw new Error(response.data?.message || "Otp verification failed.");
    }

    return response.data;
  } catch (error) {
    throw error;
  }
};

export const registerUser = async (data: UserRegistrationPayload) => {
  try {
    const response = await api.post("/Login/register", data, {});

    if (response.data?.success === false) {
      throw new Error(response.data?.message || "Registration failed.");
    }

    return response.data;
  } catch (error) {
    throw error;
  }
};

export const createUser = async (data: UserRegistrationPayload) => {
  try {
    const response = await api.post(`/Login/login-Para`, data, {});

    if (response.data?.success === false) {
      throw new Error(response.data?.message || "Login failed.");
    }

    return response.data;
  } catch (error) {
    throw error;
  }
};

export const createUserForAuth = async (data: UserRegistrationPayload) => {
  try {
    const response = await api.post(`/Login/OauthUser`, data, {});

    if (response.data?.success === false) {
      throw new Error(response.data?.message || "Login failed.");
    }

    return response.data;
  } catch (error) {
    throw error;
  }
};

export const createUserResume = async (data: ResumeData) => {
  const response = await api.post(`/Profile/profileCreation`, data, {});
  return response.data;
};

export const createUserResumeFile = async (data: createUserResumeType) => {
  try {
    const response = await api.post(`/Profile/applicantSaveFiles`, data);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const createUserResumeVideo = async (data: createUserResumeVideo) => {
  const formData = new FormData();
  formData.append("userId", String(data.userId));
  formData.append("resumefile", data.file); // Append only the file to FormData

  // Send userId as a query parameter
  try {
    const response = await api.post(`/Profile/videoresume`, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });

    return response.data;
  } catch (error) {
    throw error;
  }
};

export const UserResumeVideoGet = async (userId: number) => {
  // Send userId as a query parameter
  try {
    const response = await api.get(`/Profile/videoresume/base64/${userId}`);

    return response.data;
  } catch (error) {
    throw error;
  }
};

export const logoutUser = async () => {
  try {
    const response = await api.post(`/Login/logout`);

    return response.data;
  } catch (error) {
    throw error;
  }
};

// Single row upsert (add or edit)
export async function upsertExperience(data: ExperienceFormData) {
  const payload = { ...data, experienceId: data.experianceId ?? "0" };

  try {
    const res = await api.post<ApiResponse>(
      `/Profile/updateExperience`,
      payload,
      { withCredentials: true }
    );
    return res.data;
  } catch (error) {
    throw error;
  }
}
export async function upsertExperiences(rows: ExperienceFormData[]) {
  try {
    const results = await Promise.all(rows.map((r) => upsertExperience(r)));
    return results;
  } catch (error) {
    throw error;
  }
}

// Optional default row you can reuse in UI forms
export const defaultCertificateFormData: CertificateFormData = {
  certificateId: "0",
  certificateName: "",
  issuedDate: "",
  issuedCountry: "",
  expiryDate: "",
  status: "",
  documentNumber: "",
};

// Normalize payload to what backend expects (empty strings allowed)
function toPayload(data: CertificateFormData) {
  return {
    certificateId: data.certificateId ?? "0",
    certificateName: data.certificateName ?? "",
    issuedDate: data.issuedDate ?? "",
    issuedCountry: data.issuedCountry ?? "",
    expiryDate: data.expiryDate ?? "",
    status: data.status ?? "",
    documentNumber: data.documentNumber ?? "",
  };
}

// Single row upsert (add/edit via PATCH)
export async function upsertCertificate(data: CertificateFormData) {
  const payload = toPayload(data);
  try {
    const res = await api.patch<ApiResponse>(
      `/Profile/updateCertificates`,
      payload,
      { withCredentials: true }
    );
    return res.data;
  } catch (error) {
    throw error;
  }
}

// Multiple rows upsert in parallel
export async function upsertCertificates(rows: CertificateFormData[]) {
  try {
    const results = await Promise.all(rows.map((r) => upsertCertificate(r)));
    return results;
  } catch (error) {
    throw error;
  }
}
