"use client";

import React, { useState } from "react";

// Next.js
import { useRouter } from "next/navigation";

// External libraries
import Cookies from "js-cookie";
import { zodResolver } from "@hookform/resolvers/zod";
import { Lock, Mail, User } from "lucide-react";
import { useForm, type UseFormRegister } from "react-hook-form";
import { toast } from "react-toastify";

// Internal modules (@ alias)
import {
  otpSentForEmail,
  otpVerifyForEmail,
  registerUser,
  type UserRegistrationPayload,
} from "@/app/api/UserApi/UserCrud";
import { seafarerSchema, type SeafarerFormData } from "@/types/createUser";

export default function SeafarerRegistration() {
  const router = useRouter();
  const role = Cookies.get("user");

  const [isOtpSent, setIsOtpSent] = useState(false); // To track OTP sent state
  const [isOtpVerified, setIsOtpVerified] = useState(false); // To track OTP verification state
  const [otp, setOtp] = useState("");

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    reset,
    getValues,
  } = useForm<UserRegistrationPayload>({
    resolver: zodResolver(seafarerSchema),
    mode: "onChange",
    defaultValues: {
      role: (role as "Seafarer" | "Recruiter" | undefined) ?? "Seafarer",
      loginType: "register",
      oauthToken: "",
    },
  });

  // ✅ On submit
  const onSubmit = async (data: UserRegistrationPayload) => {
    try {
      const userPayload = {
        ...data,
        companyName: getValues("companyName"), // Capture company name for recruiters
      };

      const response = await registerUser(userPayload);
      const userId = response?.data;

      if (userId) {
        Cookies.set("userId", userId.toString(), {
          expires: 7, // days
          path: "/",
        });
      }
      toast.success("Registration successful!");
      reset();
      router.push("/login?NextRoute=Resume");
    } catch {
      toast.error("Registration failed. Please try again.");
    }
  };

  // Step 1: Send OTP
  const sendOtp = async () => {
    const email = getValues("email"); // Get email value from form
    try {
      await otpSentForEmail({ email });

      setIsOtpSent(true); // Enable OTP verification once OTP is sent
      toast.success("OTP sent to your email.");
    } catch {
      // Handle error from OTP function
      toast.error("Error sending OTP.");
    }
  };

  // Step 1: Send OTP
  const verifyOtp = async () => {
    const emailid = getValues("email");
    const ipAddress = "";
    try {
      await await otpVerifyForEmail({ emailid, otp, ipAddress });

      setIsOtpVerified(true); // Enable OTP verification once OTP is sent
      toast.success("OTP verified successfully.");
    } catch {
      // Handle error from OTP function
      toast.error("Error verifying OTP.");
    }
  };

  // Dummy data for the select dropdown
  const companyOptions = [
    { label: "Company A", value: "companyA" },
    { label: "Company B", value: "companyB" },
    { label: "Company C", value: "companyC" },
    { label: "Company D", value: "companyD" },
    { label: "Company E", value: "companyE" },
  ];

  return (
    <div className="h-full bg-gradient-to-br from-blue-900 to-slate-800 flex items-center justify-center ">
      <div className="w-full max-w-md text-sm">
        <h1 className="text-3xl font-bold text-center my-4 text-white">
          Welcome
        </h1>

        <form
          onSubmit={handleSubmit(onSubmit)}
          className="bg-white text-black rounded-md p-3 shadow-md border border-white/20 space-y-3"
        >
          {/* First & Surname */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            <FormField
              label="First Name"
              icon={<User className="h-5 w-5 " />}
              id="firstName"
              error={errors.firstName?.message}
              register={register("firstName")}
            />
            <FormField
              label="Last name"
              icon={<User className="h-5 w-5 " />}
              id="lastName"
              error={errors.lastName?.message}
              register={register("lastName")}
            />
          </div>

          <div className="flex justify-between gap-2">
            {/* Email */}
            <div className="w-full">
              <FormField
                label="Email Address"
                icon={<Mail className="h-5 w-5 " />}
                id="email"
                error={errors.email?.message}
                register={register("email")}
                type="email"
              />
              {!isOtpVerified && (
                <button
                  type="button"
                  onClick={sendOtp}
                  className="w-full mt-2 cursor-pointer btn-primary text-white p-2 rounded-md"
                >
                  Send OTP
                </button>
              )}
            </div>
            <div className="w-full">
              <FormField
                label="Seaman Book Number"
                icon={<User className="h-5 w-5 " />}
                id="lastName"
                error={errors.lastName?.message}
                register={register("lastName")}
              />
            </div>
          </div>

          {role === "Recruiter" && isOtpSent && !isOtpVerified && (
            <div className="w-full mt-4">
              {/* Company Name Select Dropdown for Recruiters */}
              <div className="relative">
                <label
                  htmlFor="companyName"
                  className="block text-sm font-medium text-black mb-2"
                >
                  Company Name
                </label>
                <select
                  {...register("companyName")}
                  id="companyName"
                  className="w-full text-black p-2 pl-10 pr-4 bg-white/20 border-2 border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all duration-200 appearance-none"
                >
                  <option value="" disabled className="text-gray-500">
                    Select your company
                  </option>
                  {companyOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
                {errors.companyName && (
                  <p className="mt-2 text-sm text-red-500">
                    {errors.companyName?.message}
                  </p>
                )}
              </div>
            </div>
          )}

          {isOtpSent && !isOtpVerified && (
            <div className="w-full mt-4">
              <label
                htmlFor="otp"
                className="block text-sm font-medium text-black mb-2"
              >
                Enter OTP
              </label>
              <input
                id="otp"
                type="text"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                className="w-full p-2 border-2 border-gray-300 rounded-md"
                placeholder="Enter OTP"
              />
              <button
                type="button"
                onClick={verifyOtp}
                className="w-full mt-2 cursor-pointer bg-green-600 text-white p-2 rounded-md"
              >
                Verify OTP
              </button>
            </div>
          )}

          {/* Password */}
          <FormField
            label="Password"
            icon={<Lock className="h-5 w-5 " />}
            id="password"
            required
            error={errors.password?.message}
            register={register("password")}
            type="password"
            hint="Password must include uppercase, lowercase, number, special char"
          />

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting || !isOtpVerified}
            className="w-full btn-primary text-white font-semibold p-2 px-6 rounded-md hover:from-blue-700 hover:to-teal-700 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 focus:ring-offset-blue-900 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98]"
          >
            {isSubmitting ? (
              <div className="flex items-center justify-center">
                <div className="w-5 h-5 border-2 cursor-pointer border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                Creating Account...
              </div>
            ) : (
              "Create Account"
            )}
          </button>
        </form>

        {/* Login Link */}
        <p className="text-center text-white text-sm my-6">
          Already have an account?{" "}
          <span
            onClick={() => router.push("/login")}
            className="text-blue-600 cursor-pointer font-medium hover:underline transition-all duration-200"
          >
            Sign in here
          </span>
        </p>

        <p className="text-center text-blue-300 text-xs mb-6">
          By creating an account, you agree to our Terms of Service and Privacy
          Policy
        </p>
      </div>
    </div>
  );
}

interface FormFieldProps {
  label: string;
  id: string;
  register: ReturnType<UseFormRegister<SeafarerFormData>>;
  error?: string;
  icon: React.ReactNode;
  type?: string;
  required?: boolean;
  hint?: string;
}

function FormField({
  label,
  id,
  register,
  error,
  icon,
  type = "text",
  hint,
  required,
}: FormFieldProps) {
  return (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-black mb-2">
        {label}
      </label>
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          {icon}
        </div>
        <input
          {...register}
          id={id}
          type={type}
          required={required}
          className="w-full pl-10 text-black pr-4 p-2 bg-white/20 border-2 border-gray-200 rounded-md placeholder-black focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all duration-200"
          placeholder={`Enter your ${label.toLowerCase()}`}
        />
      </div>
      {error && <p className="mt-2 text-sm text-red-500">{error}</p>}
      {hint && <p className="mt-2 text-xs ">{hint}</p>}
    </div>
  );
}
