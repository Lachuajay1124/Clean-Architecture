import React, { useState } from "react";
import {
  Award,
  Briefcase,
  Calendar,
  ChevronDown,
  ChevronUp,
  Edit3,
  FileText,
  Mail,
  MapPin,
  Phone,
  Save,
  User,
} from "lucide-react";
import {
  ApplicantData,
  DocumentData,
  ExperienceData,
  ResumeData,
} from "@/types/createUser";
import { formatDateForInput } from "@/lib/format";

interface CompactResumeDisplayProps {
  data: ResumeData;
  handleChange: (
    key: string,
    value: string,
    arrayType?: string,
    itemIndex?: number
  ) => void;
  onSave: (data: ResumeData) => void;
  file: File | null;
}

// Final normalized resume
const normalizeDateFields = (data: ResumeData): ResumeData => {
  return {
    ...data,
    applicant: data.applicant,
    documents: (data.documents || []).map((doc) => doc),
    sea_experience: (data.sea_experience || []).map((exp) => exp),
  };
};

const CompactResumeDisplay: React.FC<CompactResumeDisplayProps> = ({
  data,
  handleChange,
  onSave,
}) => {
  const [expandedSections, setExpandedSections] = useState<{
    [key: string]: boolean;
  }>({
    personal: true,
    documents: true,
    experience: true,
  });

  const [editMode, setEditMode] = useState<{ [key: string]: boolean }>({});

  const toggleSection = (section: string) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const toggleEdit = (key: string) => {
    setEditMode((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const labels: { [key: string]: string } = {
    address: "Address",
    addresscity: "City",
    addresscountry: "Country",
    countrycode: "Country Code",
    dateofbirth: "Date of Birth",
    email: "Email",
    firstname: "First Name",
    mobilenumber: "Mobile Number",
    nationality: "Nationality",
    seamanbooknumber: "Seaman Book Number",
    surname: "Surname",
    certificateordocumentexpirydate: "Expiry Date",
    certificateordocumentissuedate: "Issued Date",
    certificateordocumentissuingcountry: "Issuing Country",
    certificateordocumentname: "Document Name",
    certificateordocumentnumber: "Document Number",
    company: "Company",
    duration: "Duration",
    fromdate: "From Date",
    todate: "To Date",
    position: "Position",
    vesselname: "Vessel Name",
    vesseltype: "Vessel Type",
  };

  const getIcon = (key: string): React.ReactNode => {
    const iconMap: { [key: string]: React.ReactNode } = {
      firstname: <User className="w-3 h-3" />,
      surname: <User className="w-3 h-3" />,
      email: <Mail className="w-3 h-3" />,
      mobilenumber: <Phone className="w-3 h-3" />,
      address: <MapPin className="w-3 h-3" />,
      addresscity: <MapPin className="w-3 h-3" />,
      dateofbirth: <Calendar className="w-3 h-3" />,
      position: <Briefcase className="w-3 h-3" />,
      company: <Briefcase className="w-3 h-3" />,
      certificateordocumentname: <Award className="w-3 h-3" />,
    };
    return iconMap[key] || <FileText className="w-3 h-3" />;
  };

  const renderField = (
    key: string,
    value: string | number,
    level: number = 0,
    arrayType?: string,
    itemIndex?: number
  ) => {
    const fieldKey =
      arrayType && itemIndex !== undefined
        ? `${arrayType}_${itemIndex}_${key}`
        : key;
    const isEditing = editMode[fieldKey];
    const fieldLabel =
      labels[key] ||
      key.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase());

    return (
      <div
        key={fieldKey}
        className={`group relative ${level > 0 ? "ml-2" : ""}`}
      >
        <div className="flex items-center justify-between p-2 bg-gray-50 hover:bg-gray-100 rounded-md transition-colors">
          <div className="flex items-center space-x-2 flex-1 min-w-0">
            <div className="text-blue-600 flex-shrink-0">{getIcon(key)}</div>
            <div className="flex-1 min-w-0">
              <label className="block text-xs font-medium text-gray-600 mb-2">
                {fieldLabel}
              </label>
              {isEditing ? (
                <input
                  type={key.toLowerCase().includes("date") ? "date" : "text"}
                  value={
                    key.toLowerCase().includes("date") && value
                      ? formatDateForInput(value)
                      : String(value)
                  }
                  onChange={(e) => {
                    const sanitizedValue = e.target.value
                      .replace(/<.*?script.*?>.*?<\/.*?script.*?>/gi, "")
                      .trim();

                    handleChange(key, sanitizedValue, arrayType, itemIndex);
                  }}
                  className="w-full p-1 text-sm border border-blue-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-transparent"
                  onBlur={() => toggleEdit(fieldKey)}
                  onKeyDown={(e) => e.key === "Enter" && toggleEdit(fieldKey)}
                  autoFocus
                />
              ) : (
                <p className="text-sm text-gray-900 font-medium truncate">
                  {key.toLowerCase().includes("date") && value
                    ? formatDateForInput(value)
                    : value || "Not specified"}
                </p>
              )}
            </div>
          </div>
          <button
            onClick={() => toggleEdit(fieldKey)}
            className="opacity-0 group-hover:opacity-100 p-1 text-gray-400 hover:text-blue-600 transition-all flex-shrink-0"
          >
            {isEditing ? (
              <Save className="w-3 h-3" />
            ) : (
              <Edit3 className="w-3 h-3" />
            )}
          </button>
        </div>
      </div>
    );
  };

  const renderSection = (
    title: string,
    data: ApplicantData | DocumentData[] | ExperienceData[],
    sectionKey: string,
    icon: React.ReactNode
  ) => {
    const isExpanded = expandedSections[sectionKey];

    return (
      <div className="bg-white rounded-md shadow-sm text-black border border-gray-200 min-h-0 max-h-[50vh] overflow-auto">
        <button
          onClick={() => toggleSection(sectionKey)}
          className="w-full p-3 flex items-center justify-between bg-gradient-to-r from-blue-50 to-indigo-50 hover:from-blue-100 hover:to-indigo-100 transition-all"
        >
          <div className="flex items-center space-x-2">
            <div className="text-blue-600">{icon}</div>
            <h3 className="text-sm font-semibold text-gray-900">{title}</h3>
          </div>
          {isExpanded ? (
            <ChevronUp className="w-4 h-4 text-gray-500" />
          ) : (
            <ChevronDown className="w-4 h-4 text-gray-500" />
          )}
        </button>

        {isExpanded && (
          <div className="p-2 space-y-2">
            {Array.isArray(data)
              ? data.map((item, index) => (
                  <div
                    key={index}
                    className="border-l-2 border-blue-200 pl-2 space-y-1"
                  >
                    <h4 className="font-medium text-gray-700 text-xs uppercase tracking-wide">
                      Item {index + 1}
                    </h4>
                    {Object.entries(item).map(([key, value]) =>
                      typeof value !== "object" && value !== null
                        ? renderField(
                            key,
                            value as string | number,
                            1,
                            sectionKey,
                            index
                          )
                        : null
                    )}
                  </div>
                ))
              : Object.entries(data).map(([key, value]) =>
                  typeof value !== "object" && value !== null
                    ? renderField(key, value as string | number, 0)
                    : null
                )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div>
      <div className="grid grid-cols-3 gap-2">
        {/* Personal Information */}
        {renderSection(
          "Personal Information",
          data.applicant || {},
          "personal",
          <User className="w-4 h-4" />
        )}

        {/* Documents */}
        {data.documents &&
          renderSection(
            "Documents & Certificates",
            data.documents,
            "documents",
            <Award className="w-4 h-4" />
          )}

        {/* Experience */}
        {data.sea_experience &&
          renderSection(
            "Sea Experience",
            data.sea_experience,
            "experience",
            <Briefcase className="w-4 h-4" />
          )}
      </div>
      {/* Save Button */}
      <div className="flex justify-end mt-3">
        <button
          onClick={() => {
            const normalizedData = normalizeDateFields(data);
            onSave(normalizedData);
          }}
          className="flex items-center cursor-pointer space-x-2 p-2 btn-primary text-white rounded-md text-sm font-medium hover:from-blue-700 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all shadow-md hover:shadow-lg"
        >
          <Save className="w-3 h-3" />
          <span>Save Changes</span>
        </button>
      </div>
    </div>
  );
};

export default CompactResumeDisplay;
