"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

import Cookies from "js-cookie";
import { toast } from "react-toastify";
import { Upload, FileText, CheckCircle, X, Loader2 } from "lucide-react";

import CompactResumeDisplay from "./resumeDisplay";
import { ParsedResult, ResumeData } from "@/types/createUser";
import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";

import {
  createUserResume,
  createUserResumeFile,
} from "@/app/api/UserApi/UserCrud";

// Main Compact Resume Upload Component
const CompactResumeUpload: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [error, setError] = useState("");
  const [dragActive, setDragActive] = useState(false);
  const [resumeData, setResumeData] = useState<ParsedResult[] | null>(null);
  const [resume64, setResume64] = useState("");
  const userId = Number(Cookies.get("userId"));
  const user = Cookies.get("userId");
  const allowedTypes = [
    "application/pdf",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ];

  const validateFile = (file: File): string | null => {
    if (!allowedTypes.includes(file.type)) {
      return "Please upload a PDF or Word document";
    }
    if (file.size > 5 * 1024 * 1024) {
      return "File size must be less than 5MB";
    }
    return null;
  };

  const handleFileSelect = async (selectedFile: File | null) => {
    if (selectedFile === null) {
      return; // If no file is selected, do nothing
    }

    const validationError = validateFile(selectedFile);
    if (validationError) {
      setError(validationError);
      return;
    }

    setFile(selectedFile);
    setError("");
    setUploadSuccess(false);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      await handleFileSelect(selectedFile);
    }
  };

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragActive(false);

    const droppedFile = e.dataTransfer.files?.[0];
    if (droppedFile) {
      await handleFileSelect(droppedFile);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragActive(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragActive(false);
  };

  const convertToBase64 = (file: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });
  };

  const router = useRouter();

  const uploadResume = async () => {
    if (!file) return;

    setUploading(true);
    setError("");

    try {
      const base64String = await convertToBase64(file);
      const base64Content = base64String.split(",")[1];
      setResume64(base64Content);
      const uploadData = {
        files: [
          {
            filename: file.name,
            content: base64Content,
          },
        ],
      };

      // Send to backend using fetch API
      const response = await fetch("http://10.60.120.76:5016/upload_multiple", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(uploadData),
      });

      if (response.ok) {
        const data = await response.json();
        setUploadSuccess(true);
        setResumeData(data);
        setFile(null);
      } else {
        throw new Error("Upload failed");
      }
    } catch {
      setError("Failed to upload resume. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  const handleChange = (
    key: string,
    value: string,
    arrayType?: string,
    itemIndex?: number
  ) => {
    setResumeData((prevData) => {
      if (!prevData) return null;

      return prevData.map((resume) => {
        const updatedResume = { ...resume };

        if (arrayType && itemIndex !== undefined) {
          // Handle array data (documents, sea_experience)
          if (
            arrayType === "documents" &&
            updatedResume.parsed_result.documents
          ) {
            updatedResume.parsed_result.documents =
              updatedResume.parsed_result.documents.map((doc, idx) => {
                if (idx === itemIndex) {
                  return { ...doc, [key]: value };
                }
                return doc;
              });
          } else if (
            arrayType === "experience" &&
            updatedResume.parsed_result.sea_experience
          ) {
            updatedResume.parsed_result.sea_experience =
              updatedResume.parsed_result.sea_experience.map((exp, idx) => {
                if (idx === itemIndex) {
                  return { ...exp, [key]: value };
                }
                return exp;
              });
          }
        } else {
          // Handle single object data (applicant)
          if (updatedResume.parsed_result.applicant) {
            updatedResume.parsed_result.applicant = {
              ...updatedResume.parsed_result.applicant,
              [key]: value,
            };
          }
        }

        return updatedResume;
      });
    });
  };

  const handleSave = async (resumeData: ResumeData) => {
    try {
      const userPayload = {
        ...resumeData,
        userId: userId,
      };

      // 1️⃣ First API call — create resume
      const resumeResponse = await createUserResume(userPayload);

      if (!resumeResponse || !resumeResponse.success) {
        throw new Error("Resume creation failed");
      }

      // 2️⃣ Second API call — upload file only if first succeeded
      const fileUploadPayload = {
        userId: userId,
        resumeFile: resume64,
        imageFile: "",
        imageUrl: "string",
      };

      const secondResponse = await createUserResumeFile(fileUploadPayload);

      if (!secondResponse || !secondResponse.success) {
        throw new Error("Resume file upload failed");
      }
      // ✅ All success
      toast.success("Resume uploaded successfully! Please login to continue");
      setTimeout(() => {
        router.replace("/login");
      }, 1500);
    } catch {
      toast.error("Registration failed. Please try again.");
    }
  };

  const removeFile = () => {
    setFile(null);
    setError("");
    setUploadSuccess(false);
  };

  const resetUpload = () => {
    setFile(null);
    setUploadSuccess(false);
    setResumeData(null);
    setError("");
  };

  useEffect(() => {
    if (user == null) {
      toast.error("User not found — please login again");
      router.replace("/login");
    }
  }, [user, router]);

  // 3. While redirect is pending, render nothing
  if (user == null) {
    return <LoadingSpinner />;
  }

  const goBack = () => {
    toast.info("Please finish your resume upload before logging in.");
    router.push("/login");
  };

  return (
    <div className="h-full bg-white p-4">
      <div className="max-w-5xl mx-auto">
        {!resumeData ? (
          <div className="max-w-lg mx-auto">
            {/* Header */}
            <div className="text-center mb-2">
              <div className="inline-flex items-center justify-center w-8 h-8 btn-primary rounded-full mb-2">
                <Upload className="w-4 h-4 text-white" />
              </div>
              <h1 className="text-lg font-bold text-gray-900 mb-2">
                Upload Resume
              </h1>
              <p className="text-sm text-gray-600">
                Extract and manage professional information
              </p>
            </div>

            {/* Upload Card */}
            <div className="bg-white rounded-md shadow-md p-3 border border-gray-200">
              {!file && (
                <div
                  className={`border-2 border-dashed rounded-md p-3 text-center transition-all duration-300 ${
                    dragActive
                      ? "border-blue-500 bg-blue-50"
                      : "border-gray-300 hover:border-blue-400 hover:bg-gray-50"
                  }`}
                  onDrop={handleDrop}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                >
                  <input
                    type="file"
                    id="resume-upload"
                    accept=".pdf,.doc,.docx"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <label htmlFor="resume-upload" className="cursor-pointer">
                    <div className="flex flex-col items-center space-y-3">
                      <div className="p-3 bg-gradient-to-r from-blue-100 to-indigo-100 rounded-full">
                        <Upload className="h-4 w-4 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-gray-700 mb-2">
                          Click to upload or drag & drop
                        </p>
                        <p className="text-xs text-gray-500">
                          PDF, DOC, or DOCX files up to 5MB
                        </p>
                      </div>
                    </div>
                  </label>
                </div>
              )}

              {file && !uploadSuccess && (
                <div className="space-y-3">
                  <div className="flex items-center space-x-3 p-3 bg-gradient-to-r from-gray-50 to-blue-50 rounded-md border border-gray-200">
                    <div className="p-2 bg-blue-100 rounded-full">
                      <FileText className="h-4 w-4 text-blue-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-900 truncate">
                        {file.name}
                      </p>
                      <p className="text-xs text-gray-500">
                        {(file.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                    </div>
                    <button
                      onClick={removeFile}
                      className="p-1 hover:bg-gray-200 rounded-full transition-colors"
                    >
                      <X className="h-3 w-3 text-gray-500" />
                    </button>
                  </div>

                  <button
                    onClick={uploadResume}
                    disabled={uploading}
                    className="w-full cursor-pointer  btn-primary text-white p-3 rounded-md text-sm font-semibold hover:from-blue-700 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-md"
                  >
                    {uploading ? (
                      <div className="flex items-center justify-center space-x-2">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        <span>
                          Don&apos;t worry It will take some time, please be
                          patient...
                        </span>
                      </div>
                    ) : (
                      "Upload & Parse Resume"
                    )}
                  </button>
                </div>
              )}

              {uploadSuccess && !resumeData && (
                <div className="text-center space-y-3">
                  <div className="flex justify-center">
                    <div className="p-3 bg-green-100 rounded-full">
                      <CheckCircle className="h-8 w-8 text-green-500" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      Upload Successful!
                    </h3>
                    <p className="text-sm text-gray-600">
                      Your resume has been processed successfully.
                    </p>
                  </div>
                  <button
                    onClick={resetUpload}
                    className="text-blue-600 cursor-pointer  hover:text-blue-700 text-sm font-semibold underline"
                  >
                    Upload Another Resume
                  </button>
                </div>
              )}

              {error && (
                <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-md">
                  <div className="flex items-center space-x-2">
                    <X className="h-4 w-4 text-red-500" />
                    <p className="text-red-700 text-sm font-medium">{error}</p>
                  </div>
                </div>
              )}
            </div>

            <div className="mt-4 text-center">
              <p className="text-xs text-gray-500">
                Your resume data is processed securely and can be edited after
                upload.
              </p>

              <button
                onClick={goBack}
                className="btn-primary cursor-pointer text-white p-2 my-4 rounded-md"
              >
                Go Back to Login
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Header with Back Button */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div>
                <h1 className="text-xl font-bold text-gray-900">
                  Resume Details
                </h1>
                <p className="text-sm text-gray-600">
                  Review and edit your extracted resume information
                </p>
              </div>
              <button
                onClick={resetUpload}
                className="flex items-center cursor-pointer space-x-2 px-3 py-2 text-sm text-gray-600 hover:text-gray-800 border border-gray-300 rounded-md hover:bg-gray-50 transition-colors"
              >
                <Upload className="w-3 h-3" />
                <span>Upload New Resume</span>
              </button>
            </div>

            {/* Resume Data Display */}
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-2">
              {resumeData?.map((resume, index: number) => (
                <div key={index} className="lg:col-span-2 xl:col-span-3">
                  <div className="bg-white rounded-md shadow-sm border border-gray-200 p-3 mb-2">
                    <div className="flex items-center space-x-2">
                      <FileText className="w-4 h-4 text-blue-600" />
                      <h2 className="text-md font-semibold text-gray-900 truncate">
                        {resume.filename}
                      </h2>
                    </div>
                  </div>

                  <CompactResumeDisplay
                    data={resume.parsed_result}
                    handleChange={handleChange}
                    onSave={(data) => handleSave(data)}
                    file={file}
                  />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CompactResumeUpload;
