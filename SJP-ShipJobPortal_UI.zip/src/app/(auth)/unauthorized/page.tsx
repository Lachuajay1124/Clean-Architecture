"use client";

// React core
import { useCallback, useEffect } from "react";

// Next.js
import { useRouter } from "next/navigation";

// External libraries
import Cookies from "js-cookie";

import { toast } from "react-toastify";
import { ArrowLeft, ShieldOff } from "lucide-react";
import { logoutUser } from "@/app/api/UserApi/UserCrud";

export default function UnauthorizedPage() {
  const router = useRouter();

  // Auto redirect after 3 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      router.push("/");
    }, 3000);

    return () => clearTimeout(timer);
  }, [router]);

  // Manual logout handler
  const handleLogout = async () => {
    if (!window.confirm("Are you sure you want to logout?")) return;
    Cookies.remove("SjpJwtToken");
    Cookies.remove("SjpJwtRefreshToken");
    Cookies.remove("user");
    Cookies.remove("navigation");
    Cookies.remove("allowedRoutes");
    Cookies.remove("userId");
    await logoutUser();
    toast.success("Logout successful!");
  };

  // Go back to previous page
  const handleGoBack = useCallback(() => {
    router.back();
  }, [router]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4 py-12">
      <div className="max-w-md w-full bg-white p-8 rounded-md shadow-lg text-center">
        <div className="flex justify-center mb-4">
          <div className="bg-red-100 p-3 rounded-full">
            <ShieldOff className="text-red-600 w-6 h-6" />
          </div>
        </div>
        <h1 className="text-xl font-bold text-gray-900 mb-2">
          Unauthorized Access
        </h1>
        <p className="text-sm text-gray-600 mb-4">
          You do not have permission to access this page.
        </p>

        <div className="flex flex-col gap-3 items-center">
          <button
            onClick={handleGoBack}
            className="flex items-center gap-2 text-sm text-blue-600 hover:underline"
          >
            <ArrowLeft className="w-4 h-4" /> Go Back to Previous Page
          </button>

          <button
            onClick={handleLogout}
            className="bg-blue-600 text-white px-4 py-2 text-sm rounded-md hover:bg-blue-700 transition"
          >
            Go Back & Login In Your Role
          </button>
        </div>
      </div>
    </div>
  );
}
