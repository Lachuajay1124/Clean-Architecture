"use client";

import React, { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from "react-responsive-carousel";
import type { CarouselProps } from "react-responsive-carousel";
import { toast } from "react-toastify";

interface JobAd {
  company: string;
  role: string;
  vesselType: string;
  location: string;
  salaryRange: string;
  duration: string;
  urgent: boolean;
  companyLogo: string;
  rating?: number;
  perks?: string[];
}

const chunkArray = <T,>(array: T[], size: number): T[][] => {
  const result: T[][] = [];
  for (let i = 0; i < array.length; i += size) {
    result.push(array.slice(i, i + size));
  }
  return result;
};

const ShipJobsAd: React.FC = () => {
  const router = useRouter();
  const [currentSlide, setCurrentSlide] = useState(0);

  const ads: JobAd[] = React.useMemo(
    () =>
      Array.from({ length: 16 }, (_, i) => ({
        company: `Maritime ${i + 1}`,
        role: [
          "Captain",
          "Chief Engineer",
          "Deck Officer",
          "Marine Engineer",
          "Electrician",
          "Cook",
        ][i % 6],
        vesselType: ["Cruise", "Cargo", "Tanker", "Yacht", "Fishing"][i % 5],
        location: ["Singapore", "Rotterdam", "Dubai", "Shanghai", "Miami"][
          i % 5
        ],
        salaryRange: `$${(2000 + i * 100).toLocaleString()}–$${(
          3000 +
          i * 150
        ).toLocaleString()}`,
        duration: `${3 + (i % 4)} Months`,
        urgent: i % 3 === 0,
        companyLogo: "🚢",
        rating: 3.5 + (i % 3),
        perks: ["Flight covered", "Insurance", "Bonus", "Training"][i % 4]
          ? [["Flight covered", "Insurance", "Bonus", "Training"][i % 4]]
          : [],
      })),
    []
  );

  const groupedAds = useMemo(() => chunkArray(ads, 8), [ads]);

  const handleLogin = () => router.replace("/login");
  const handleRefer = () => {
    toast.info("Referral feature is coming soon! Stay tuned for updates.");
  };

  const renderArrowPrev: CarouselProps["renderArrowPrev"] = (
    onClickHandler,
    hasPrev
  ) =>
    hasPrev && (
      <button
        type="button"
        onClick={onClickHandler}
        className="absolute bottom-4 z-20 btn-primary hover:bg-blue-900 rounded-full p-2 transition-all duration-200 hover:scale-105"
        aria-label="Previous slide"
      >
        <svg className="w-4 h-4 text-white" viewBox="0 0 24 24">
          <path
            fill="currentColor"
            d="M15.41 16.59L10.83 12l4.58-4.59L14 6l-6 6 6 6 1.41-1.41z"
          />
        </svg>
      </button>
    );

  const renderArrowNext: CarouselProps["renderArrowNext"] = (
    onClickHandler,
    hasNext
  ) =>
    hasNext && (
      <button
        type="button"
        onClick={onClickHandler}
        className="absolute right-0 bottom-4 z-20 btn-primary hover:bg-blue-900 rounded-full p-2 transition-all duration-200 hover:scale-105"
        aria-label="Next slide"
      >
        <svg className="w-4 h-4 text-white" viewBox="0 0 24 24">
          <path
            fill="currentColor"
            d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"
          />
        </svg>
      </button>
    );

  const renderIndicator: CarouselProps["renderIndicator"] = (
    onClickHandler,
    isSelected,
    index
  ) => (
    <li
      className={`inline-block w-2 h-2 mx-1 rounded-full transition-all ${
        isSelected ? "btn-primary w-4" : "bg-gray-300"
      }`}
      aria-label={`Slide ${index + 1}`}
      onClick={onClickHandler}
      onKeyDown={onClickHandler}
      value={index}
      key={index}
      role="button"
      tabIndex={0}
    />
  );

  return (
    <div className="text-gray-900 overflow-y-auto h-full p-4">
      <header className="text-center mb-2">
        <div className="inline-flex items-center gap-2">
          <h1 className="text-2xl font-bold bg-clip-text text-white">
            Premium Maritime Careers
          </h1>
        </div>
      </header>

      <div className="h-[72vh] overflow-y-hidden">
        <Carousel
          autoPlay
          infiniteLoop
          interval={8000}
          showThumbs={false}
          showStatus={false}
          showArrows={true}
          onChange={setCurrentSlide}
          selectedItem={currentSlide}
          renderArrowPrev={renderArrowPrev}
          renderArrowNext={renderArrowNext}
          renderIndicator={renderIndicator}
          swipeable={true}
          emulateTouch={true}
          aria-live="polite"
          aria-label="Job Advertisement Carousel"
        >
          {groupedAds.map((group, groupIndex) => (
            <div
              key={`group-${groupIndex}`}
              className="grid grid-cols-2 lg:grid-cols-4 gap-2 mx-auto pb-14"
            >
              {group.map((ad, index) => (
                <div
                  key={`ad-${groupIndex}-${index}`}
                  className={`group relative bg-white p-3 rounded-md transition-all duration-300 hover:-translate-y-1 `}
                  role="region"
                  aria-labelledby={`job-${groupIndex}-${index}`}
                >
                  {ad.urgent && (
                    <span className="absolute top-2 right-2 bg-red-500 text-white text-xs px-2 py-1 rounded-md font-bold">
                      Hot
                    </span>
                  )}

                  <div className="flex flex-col h-full">
                    <div className="flex justify-start gap-2 items-start mb-2">
                      <div className="text-start bg-blue-200 p-1 rounded-md">
                        {ad.companyLogo}
                      </div>
                      <div>
                        <h3
                          id={`job-${groupIndex}-${index}`}
                          className="text-start text-xs font-bold text-gray-900 group-hover:text-blue-700 transition-colors"
                        >
                          {ad.role}
                        </h3>
                        <p className="text-xs text-start text-gray-500">
                          {ad.company}
                        </p>
                      </div>
                    </div>

                    <div className="mb-2 flex-1">
                      <div className="flex justify-between items-center">
                        <span className="text-xs text-blue-800 rounded font-medium">
                          {ad.vesselType}
                        </span>
                        <span className="text-xs font-bold text-green-700">
                          {ad.salaryRange}
                        </span>
                      </div>

                      <div className="text-xs text-gray-600 space-y-1 mt-2">
                        <div className="flex items-center">
                          <svg
                            className="w-3 h-3 mr-1 text-gray-500"
                            fill="currentColor"
                            viewBox="0 0 20 20"
                          >
                            <path
                              fillRule="evenodd"
                              d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z"
                              clipRule="evenodd"
                            />
                          </svg>
                          {ad.location}
                        </div>
                        <div className="flex items-center">
                          <svg
                            className="w-3 h-3 mr-1 text-gray-500"
                            fill="currentColor"
                            viewBox="0 0 20 20"
                          >
                            <path
                              fillRule="evenodd"
                              d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z"
                              clipRule="evenodd"
                            />
                          </svg>
                          {ad.duration}
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={handleLogin}
                      className="w-full mt-auto btn-primary hover:from-blue-700 hover:to-blue-900 text-white text-xs font-semibold py-1 rounded-md transition-all duration-200 shadow hover:shadow-md"
                      aria-label={`Apply for ${ad.role} at ${ad.company}`}
                    >
                      Apply Now
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </Carousel>

        <div className="flex justify-center">
          <div className="bg-gray-800 text-white px-4 py-1 rounded-full text-xs font-medium shadow-md">
            {currentSlide + 1} / {groupedAds.length}
          </div>
        </div>
      </div>

      <div className="text-center">
        <div className="flex justify-center gap-2">
          <button
            onClick={handleRefer}
            className="cursor-pointer bg-blue-900 hover:from-blue-800 hover:to-blue-700 text-white text-sm font-semibold py-2 px-6 rounded-full transition-all duration-200 hover:scale-[1.02] shadow-md hover:shadow-lg flex items-center"
            aria-label="Refer a friend"
          >
            <svg
              className="w-4 h-4 mr-2"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"
              />
            </svg>
            Refer a friend
          </button>
          <button
            onClick={handleLogin}
            className="cursor-pointer btn-primary hover:from-green-700 hover:to-green-800 text-white text-sm font-semibold py-2 px-6 rounded-full transition-all duration-200 hover:scale-[1.02] shadow-md hover:shadow-lg flex items-center"
            aria-label="Sign In"
          >
            <svg
              className="w-4 h-4 mr-2"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"
              />
            </svg>
            Sign In
          </button>
        </div>
      </div>
    </div>
  );
};

export default ShipJobsAd;
