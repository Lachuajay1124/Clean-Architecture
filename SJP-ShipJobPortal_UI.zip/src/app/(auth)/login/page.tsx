"use client";

import React, { Suspense, useCallback, useMemo } from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
import { useRouter } from "next/navigation";
import Cookies from "js-cookie";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "react-toastify";

import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";
import { useSafeSearchParams } from "@/hooks/useSearchParams";
import { loginSchema } from "@/lib/validation";
import { useLoginMutation } from "./loginHandleMethods";

import type { LoginFormData } from "@/lib/validation";

// ---------- constants ----------
export type UserRole = "Seafarer" | "Recruiter";
const ROLES: UserRole[] = ["Seafarer", "Recruiter"];
const ALLOWED_FROM_VALUES = ["Website", "Register", "Resume"] as const;

// Dynamic imports
const JobAnimation = dynamic(
  () => import("@/components/common/Login/LoginAnimationLottie/joblottie"),
  {
    ssr: false,
    loading: () => (
      <div className="text-white h-full flex items-center justify-center">
        <LoadingSpinner />
      </div>
    ),
  }
);
const ShipJobsAd = dynamic(() => import("./ads/loginAd"), {
  ssr: false,
  loading: () => <LoadingSpinner />,
});
const CompactResumeUpload = dynamic(
  () => import("../register/ResumeParsing&Saving/resumeUploader"),
  { ssr: false, loading: () => <LoadingSpinner /> }
);
const SeafarerRegistration = dynamic(() => import("../register/page"), {
  ssr: false,
  loading: () => <LoadingSpinner />,
});

// ---------- helpers ----------
function getCookieOptions() {
  const isHttps =
    typeof window !== "undefined" && window.location.protocol === "https:";
  return { expires: 7, path: "/", sameSite: "lax" as const, secure: isHttps };
}

function setCookieJSON(
  name: string,
  value: unknown,
  opts: Parameters<typeof Cookies.set>[2]
) {
  try {
    Cookies.set(name, JSON.stringify(value ?? {}), opts);
  } catch {
    Cookies.set(name, "{}", opts);
  }
}

function useIsIdle() {
  const [idle, setIdle] = React.useState(false);
  React.useEffect(() => {
    const cb = () => setIdle(true);
    const id = (window as Window & typeof globalThis).requestIdleCallback?.(cb);
    if (!id) {
      const t = setTimeout(cb, 1);
      return () => clearTimeout(t);
    }
    return () =>
      (window as Window & typeof globalThis).cancelIdleCallback?.(id);
  }, []);
  return idle;
}

function usePrefersReducedMotion() {
  const [reduce, setReduce] = React.useState(false);
  React.useEffect(() => {
    const m = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduce(m.matches);
    const handler = () => setReduce(m.matches);
    m.addEventListener?.("change", handler);
    return () => m.removeEventListener?.("change", handler);
  }, []);
  return reduce;
}

// ---------- types ----------
interface Module {
  moduleName: string;
  modulePath: string;
  hide: number;
  roleName?: UserRole | string;
}

// ---------- RoleSelector ----------
const RoleSelector = React.memo(
  ({
    value,
    onChange,
    error,
  }: {
    value: UserRole;
    onChange: (role: UserRole) => void;
    error?: string;
  }) => (
    <div className="mb-2">
      <p className="text-sm font-medium text-gray-700 mb-2 text-center">
        Select Your Role
      </p>
      <div className="grid grid-cols-2 gap-2 p-1 bg-gray-100 rounded-md">
        {ROLES.map((role) => (
          <button
            key={role}
            type="button"
            onClick={() => onChange(role)}
            aria-pressed={value === role}
            className={`px-4 py-1 cursor-pointer rounded-md font-medium transition-all capitalize ${
              value === role
                ? "bg-white text-blue-600 shadow-md ring-2 ring-blue-500 ring-opacity-50"
                : "text-gray-600 hover:text-gray-900 hover:bg-gray-300"
            }`}
          >
            {role}
          </button>
        ))}
      </div>
      {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
    </div>
  )
);
RoleSelector.displayName = "RoleSelector";

// ---------- page ----------
const LoginPage = () => {
  const router = useRouter();
  const { getParam } = useSafeSearchParams();
  const loginMutation = useLoginMutation();
  const cookieOpts = getCookieOptions();
  const isIdle = useIsIdle();
  const reduceMotion = usePrefersReducedMotion();
  const [routePending, startTransition] = React.useTransition();

  // sanitize NextRoute
  const rawFromParam = getParam("NextRoute");
  const fromParam = useMemo(
    () =>
      ALLOWED_FROM_VALUES.includes(
        rawFromParam as (typeof ALLOWED_FROM_VALUES)[number]
      )
        ? (rawFromParam as (typeof ALLOWED_FROM_VALUES)[number])
        : null,
    [rawFromParam]
  );

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
    setValue,
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      password: "",
      userRole: "Seafarer",
      loginType: "portal",
      oauthToken: "",
    },
    mode: "onSubmit",
  });

  const userRole = watch("userRole");

  const handleSignUp = useCallback(() => {
    startTransition(() => router.push("/login?NextRoute=Register"));
  }, [router]);

  const handleRoleChange = useCallback(
    (role: UserRole) => {
      setValue("userRole", role, {
        shouldDirty: true,
        shouldValidate: false,
        shouldTouch: false,
      });
      Cookies.set("user", role, cookieOpts);
    },
    [setValue, cookieOpts]
  );

  const onSubmit = handleSubmit(async (data: LoginFormData) => {
    loginMutation.mutate(
      {
        firstName: "",
        lastName: "",
        email: data.email,
        password: data.password,
        role: data.userRole,
        loginType: "portal",
        oauthToken: "",
      },
      {
        onSuccess: async (response) => {
          try {
            const payload = response?.data ?? {};
            const userId = String(payload.userId ?? "");
            const resumeStatus = String(payload.resumeStatus ?? "");
            const modules: Module[] = Array.isArray(
              payload.roleModulePrevilleages
            )
              ? payload.roleModulePrevilleages
              : [];

            const roleFromApi = (payload.role ??
              modules[0]?.roleName ??
              "Seafarer") as UserRole;
            const emailFromApi = String(payload.email ?? "");

            // Build allowed routes + navigation
            const allowedRoutes = Array.from(
              new Set(
                modules
                  .map((m) => (m.modulePath || "").slice(0, 256))
                  .filter(Boolean)
              )
            );
            const navigation = modules
              .filter((m) => m.hide === 0)
              .map((m) => ({
                name: (m.moduleName || "").slice(0, 64),
                path: (m.modulePath || "").slice(0, 256),
              }))
              .filter((n) => n.path);

            Cookies.set("userId", userId, cookieOpts);
            Cookies.set("user", roleFromApi, cookieOpts);
            Cookies.set("userEmail", emailFromApi, cookieOpts);
            Cookies.set("resumeStatus", resumeStatus, cookieOpts);
            Cookies.set("SjpJwtToken", response.token, cookieOpts); // For development use only

            setCookieJSON("allowedRoutes", allowedRoutes, cookieOpts);
            setCookieJSON("navigation", navigation, cookieOpts);

            toast.success("Login successful!");
            startTransition(() =>
              router.replace(
                roleFromApi === "Seafarer" ? "/candidates" : "/recruiters"
              )
            );
          } catch {
            toast.error("Something went wrong after login. Please try again.");
          }
        },
        onError: (error: Error) => {
          toast.error(error.message || "Login failed. Please try again.");
        },
      }
    );
  });

  return (
    <div className="h-screen w-full bg-gradient-to-br from-blue-900 to-slate-800 flex items-center justify-center p-4">
      <div className="relative w-full max-w-5xl">
        <div className="bg-white/5 rounded-md shadow-md overflow-hidden">
          {fromParam === "Website" ? (
            isIdle ? (
              <Suspense fallback={<LoadingSpinner />}>
                <ShipJobsAd />
              </Suspense>
            ) : (
              <div className="p-6 text-white">
                <LoadingSpinner />
              </div>
            )
          ) : fromParam === "Register" ? (
            <Suspense fallback={<LoadingSpinner />}>
              <SeafarerRegistration />
            </Suspense>
          ) : fromParam === "Resume" ? (
            <Suspense fallback={<LoadingSpinner />}>
              <CompactResumeUpload />
            </Suspense>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 min-h-[400px]">
              <div>{!reduceMotion && isIdle && <JobAnimation />}</div>

              <div className="bg-white flex flex-col justify-between shadow-md p-3 h-full space-y-3">
                <h1 className="text-lg md:text-2xl font-bold text-gray-900 text-center">
                  Welcome Back
                </h1>

                <form
                  onSubmit={onSubmit}
                  className="space-y-3 h-full flex flex-col justify-between flex-grow"
                  aria-labelledby="login-form"
                >
                  <RoleSelector
                    value={userRole}
                    onChange={handleRoleChange}
                    error={errors.userRole?.message}
                  />

                  <div>
                    <label
                      htmlFor="email"
                      className="block text-sm font-medium text-gray-700 mb-2"
                    >
                      Email Address
                    </label>
                    <input
                      type="email"
                      id="email"
                      aria-label="Email Address"
                      autoComplete="email"
                      inputMode="email"
                      {...register("email")}
                      className={`w-full text-black p-1 border rounded-md focus:ring-2 focus:ring-blue-500 bg-white placeholder-gray-400 ${
                        errors.email
                          ? "border-red-300 focus:ring-red-500"
                          : "border-gray-300"
                      }`}
                      placeholder="you@example.com"
                    />
                    {errors.email && (
                      <p className="text-red-500 text-xs mt-1">
                        {errors.email.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="password"
                      className="block text-sm font-medium text-gray-700 mb-2"
                    >
                      Password
                    </label>
                    <input
                      type="password"
                      id="password"
                      aria-label="Password"
                      autoComplete="current-password"
                      {...register("password")}
                      className={`w-full p-1 text-black border rounded-md focus:ring-2 focus:ring-blue-500 bg-white placeholder-gray-400 ${
                        errors.password
                          ? "border-red-300 focus:ring-red-500"
                          : "border-gray-300"
                      }`}
                      placeholder="••••••••"
                    />
                    {errors.password && (
                      <p className="text-red-500 text-xs mt-1">
                        {errors.password.message}
                      </p>
                    )}
                  </div>

                  <button
                    type="submit"
                    className="w-full cursor-pointer bg-gradient-to-r from-blue-900 to-indigo-600 text-white py-2 rounded-md font-semibold hover:from-blue-700 hover:to-indigo-700 focus:ring-2 focus:ring-blue-500 transition-all duration-200 disabled:opacity-50 shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
                    disabled={loginMutation.isPending || routePending}
                  >
                    {loginMutation.isPending ? (
                      <div className="flex items-center justify-center gap-2">
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        Logging in...
                      </div>
                    ) : (
                      `Login as ${
                        userRole.charAt(0).toUpperCase() + userRole.slice(1)
                      }`
                    )}
                  </button>
                </form>

                <p className="flex justify-between text-center text-[10px] md:text-sm text-gray-600">
                  <span>
                    Don&apos;t have an {userRole} account?{" "}
                    <button
                      onClick={handleSignUp}
                      type="button"
                      className="cursor-pointer text-blue-600 hover:text-blue-700 font-medium hover:underline transition"
                    >
                      Sign up
                    </button>
                  </span>

                  <Link
                    href="/forgot-password"
                    className=" text-[10px] md:text-sm text-right text-red-600 hover:text-red-700 font-medium hover:underline transition"
                  >
                    Forgot password?
                  </Link>
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
