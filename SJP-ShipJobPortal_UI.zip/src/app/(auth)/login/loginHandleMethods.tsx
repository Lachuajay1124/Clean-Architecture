import { useMutation } from "@tanstack/react-query";
import { createUser, createUserForAuth } from "@/app/api/UserApi/UserCrud";

export interface UserRegistrationPayload {
  firstName: string;
  lastName: string;
  email: string;
  role: "recruiter" | "seafarer" | string;
  loginType: "portal" | string;
  password?: string;
  oauthToken?: string;
}

export const useLoginMutation = () => {
  return useMutation({
    mutationFn: async (data: UserRegistrationPayload) => {
      const userPayload = { ...data };
      const response = await createUser(userPayload);
      return response;
    },
  });
};

export const useLoginMutationForAuth = () => {
  return useMutation({
    mutationFn: async (data: UserRegistrationPayload) => {
      const userPayload = { ...data };
      const response = await createUserForAuth(userPayload);
      return response;
    },
  });
};
