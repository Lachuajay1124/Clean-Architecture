// stores/useTabStore.ts
import { create } from "zustand";

interface TabStore {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const useTabStore = create<TabStore>((set) => ({
  activeTab:
    typeof window !== "undefined"
      ? localStorage.getItem("maritimeActiveTab") || "personal"
      : "personal",
  setActiveTab: (tab) => {
    localStorage.setItem("maritimeActiveTab", tab);
    set({ activeTab: tab });
  },
}));
