"use client";

import React, { useEffect, useMemo, useState } from "react";
import dynamic from "next/dynamic";
import { usePathname, useRouter } from "next/navigation";
import { LazyMotion, MotionConfig, domAnimation, m } from "framer-motion";
import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";
import { useAuth } from "@/hooks/useAuth";
import HeaderComponent from "@/components/common/Layout/header/page";

type Props = { children: React.ReactNode };
type UserRole = "Seafarer" | "Recruiter" | null | undefined;

const CandidateSidebar = dynamic(
  () => import("@/components/common/Layout/sidebar/candidate/CandidateSideBar"),
  { loading: () => null, ssr: false }
);
const RecruiterSidebar = dynamic(
  () => import("@/components/common/Layout/sidebar/recruiter/dashboardSidebar"),
  { loading: () => null, ssr: false }
);

const PUBLIC_PATHS = new Set(["/login", "/register", "/unauthorized"]);
const HIDE_SIDEBAR_PATHS = new Set([
  "/recruiters/companyProfile",
  "/candidates/profilePage",
]);

function SidebarShell({ children }: { children?: React.ReactNode }) {
  return (
    <aside
      className="hidden md:block w-56 shrink-0 h-full py-2"
      aria-label="Sidebar"
      role="complementary"
    >
      {children ?? (
        <div className="animate-pulse space-y-3 p-2">
          <div className="h-8 rounded bg-muted/50" />
          <div className="h-8 rounded bg-muted/50" />
          <div className="h-8 rounded bg-muted/50" />
        </div>
      )}
    </aside>
  );
}

export default function AnimatedLayout({ children }: Props) {
  const pathname = usePathname();
  const router = useRouter();
  const { user, loading, isAuthenticated } = useAuth() ?? {};
  const [redirecting, setRedirecting] = useState(false);

  const role = user as UserRole;

  const isPublic = useMemo(() => {
    for (const p of PUBLIC_PATHS) if (pathname.startsWith(p)) return true;
    return false;
  }, [pathname]);

  const visibleFrame = useMemo(() => !isPublic, [isPublic]);
  const shouldShowSidebar = useMemo(
    () => visibleFrame && !HIDE_SIDEBAR_PATHS.has(pathname),
    [visibleFrame, pathname]
  );

  useEffect(() => {
    if (!loading && !isAuthenticated && !isPublic) {
      setRedirecting(true);
      router.replace("/login");
    } else {
      setRedirecting(false);
    }
  }, [loading, isAuthenticated, isPublic, router]);

  if (loading || redirecting) {
    return (
      <div className="h-screen w-full flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <>
      <div className="h-screen w-full flex flex-col text-[var(--color-primary-text)] overflow-hidden">
        {visibleFrame && (
          <header className="shrink-0">
            <HeaderComponent />
          </header>
        )}

        <div className="flex flex-1 min-h-0 overflow-hidden">
          {shouldShowSidebar ? (
            <SidebarShell>
              {(role === "Seafarer" || role === "Recruiter") &&
                (role === "Seafarer" ? (
                  <CandidateSidebar />
                ) : (
                  <RecruiterSidebar />
                ))}
            </SidebarShell>
          ) : null}

          <main className="relative flex-1 h-full overflow-hidden">
            <LazyMotion features={domAnimation}>
              <MotionConfig
                transition={{ duration: 0.2, ease: "easeOut" }}
                reducedMotion="user"
              >
                <m.div
                  key={pathname}
                  className="absolute inset-0 transform-gpu"
                  initial={{ y: 12, opacity: 0.96 }}
                  animate={{ y: 0, opacity: 1 }}
                >
                  <div
                    className={`h-full w-full ${
                      visibleFrame ? "p-1 md:p-2" : "p-0 m-0"
                    } overflow-y-auto scrollbar-thin`}
                  >
                    {children}
                  </div>
                </m.div>
              </MotionConfig>
            </LazyMotion>
          </main>
        </div>
      </div>
    </>
  );
}
