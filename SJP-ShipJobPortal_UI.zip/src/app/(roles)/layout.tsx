import AnimatedLayout from "./Wrapper/page";
import { Suspense } from "react";
import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <Suspense fallback={<LoadingSpinner />}>
      <AnimatedLayout>{children}</AnimatedLayout>
    </Suspense>
  );
}
