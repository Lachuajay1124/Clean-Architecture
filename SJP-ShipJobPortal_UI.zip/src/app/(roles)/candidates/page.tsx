// React core
import React, { Suspense } from "react";

// External libraries
import { BaggageClaim } from "lucide-react";

import { SearchInputData } from "@/components/common/Search/SearchWithZustand";
import { AllJobs } from "@/components/Tables&Cards/Candidate/allJobs";
import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";

export default function ModernJobDashboard() {
  return (
    <>
      <div className="h-full flex flex-col bg-white/50 space-y-2 rounded-md shadow-md p-2">
        {/* Header row: title + search */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-2 flex-shrink-0">
          <div className="flex justify-start gap-2 w-full">
            <div className="w-6 h-6 md:w-9 md:h-9 btn-primary rounded-md flex items-center justify-center">
              <BaggageClaim size={16} className="text-white" />
            </div>
            <div>
              <h1 className="text-sm font-bold primary-text bg-clip-text text-transparent">
                Available Jobs
              </h1>
              <p className="text-xs text-gray-600 hidden md:block">
                View your job opportunities.
              </p>
            </div>
          </div>

          <SearchInputData placeholder="Search job title, companies" />
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col min-h-0">
          <Suspense fallback={<LoadingSpinner />}>
            {" "}
            <AllJobs />
          </Suspense>
        </div>
      </div>
    </>
  );
}
