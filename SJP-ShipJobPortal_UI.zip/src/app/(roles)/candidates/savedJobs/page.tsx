// React core
import { Suspense } from "react";

// External libraries
import { Save } from "lucide-react";

// Types (type-only)
import AllSavedJobs from "@/components/Tables&Cards/Candidate/allSavedJobs";
import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";
import { SearchInputData } from "@/components/common/Search/SearchWithZustand";

export default function ApplicationHistoryPage() {
  return (
    <div className="h-full flex flex-col bg-white/50 space-y-2 justify-between rounded-md shadow-md p-2">
      {/* Header Section */}
      <div className="flex flex-col lg:flex-row lg:justify-between gap-2">
        <div className="flex justify-start gap-2 w-full">
          <div className="w-9 h-9 btn-primary rounded-md flex items-center justify-center">
            <Save size={16} className="text-white" />
          </div>{" "}
          <div>
            <h1 className="text-sm font-bold primary-text bg-clip-text text-transparent">
              Saved Jobs
            </h1>
            <p className="text-xs text-gray-600 ">
              View your saved applications
            </p>
          </div>
        </div>

        {/* Search Section */}
        <SearchInputData placeholder="Search job title, companies" />
      </div>

      <Suspense fallback={<LoadingSpinner />}>
        <AllSavedJobs />
      </Suspense>
    </div>
  );
}
