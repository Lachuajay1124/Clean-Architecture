"use client";

// React core
import React, { useCallback, useEffect, useRef, useState } from "react";

// External libraries
import Cookies from "js-cookie";
import { toast } from "react-toastify";
import Webcam from "react-webcam";

// Internal modules (@ alias)
import { createUserResumeVideo } from "@/app/api/UserApi/UserCrud";
import { useVideoResume } from "@/hooks/listingHooks/useListingHooks";

type Status = "ready" | "countdown" | "recording" | "completed";

export function dataUrlToBlobUrl(dataUrl: string) {
  // strip whitespace/newlines that some APIs add
  const clean = dataUrl.replace(/\s/g, "");
  const [header, base64] = clean.split(",");
  const mime =
    header.match(/data:(.*?);base64/)?.[1] ?? "application/octet-stream";
  const byteStr = atob(base64);
  const len = byteStr.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) bytes[i] = byteStr.charCodeAt(i);
  const blob = new Blob([bytes], { type: mime });
  return URL.createObjectURL(blob);
}
export const VideoCapture = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null); // local (new) recording preview
  const [serverVideoUrl, setServerVideoUrl] = useState<string | null>(null); // API video
  const [countdown, setCountdown] = useState(4);
  const [recordingTime, setRecordingTime] = useState(0);
  const [status, setStatus] = useState<Status>("ready");
  const [isModalOpen, setIsModalOpen] = useState(false);

  const webcamRef = useRef<Webcam | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const userId = Cookies.get("userId") ?? "";

  const {
    data: videoData,
    isLoading: isVideoLoading,
    isError: videoError,
  } = useVideoResume(Number(userId), isModalOpen);

  // Pull the existing video URL from API result (adjust path to your API shape)
  useEffect(() => {
    const data = videoData?.data; // your API field
    if (!data) return;

    // If it’s already a full data URL
    if (data.startsWith("data:video/")) {
      setServerVideoUrl(dataUrlToBlobUrl(data)); // or set directly if you prefer
    } else {
      // If API sometimes returns only the base64 payload:
      const full = `data:video/webm;base64,${data}`;
      setServerVideoUrl(dataUrlToBlobUrl(full));
    }

    return () => {
      // Revoke old blob URLs to avoid leaks
      if (serverVideoUrl) URL.revokeObjectURL(serverVideoUrl);
    };
  }, [videoData, serverVideoUrl]);

  // Prefer newly recorded preview; else fall back to server video
  const previewUrl =
    status === "completed" && videoUrl ? videoUrl : serverVideoUrl;

  // Revoke previous object URLs when local preview changes to avoid leaks
  useEffect(() => {
    return () => {
      if (videoUrl) URL.revokeObjectURL(videoUrl);
    };
  }, [videoUrl]);

  type WebcamWithStream = Webcam & { stream?: MediaStream };

  // ---- helpers ----
  const getStream = () => {
    // react-webcam exposes MediaStream at `webcamRef.current.stream`
    return (webcamRef.current as WebcamWithStream)?.stream as
      | MediaStream
      | undefined;
  };

  const stopTracks = useCallback(() => {
    const stream = getStream();
    stream?.getTracks().forEach((t) => {
      try {
        t.stop();
      } catch {}
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const hardReset = useCallback(() => {
    setIsRecording(false);
    setStatus("ready");
    setVideoUrl(null);
    chunksRef.current = [];
    setCountdown(4);
    setRecordingTime(0);
  }, []);

  const closeModal = useCallback(() => {
    // Stop recorder if active
    if (
      mediaRecorderRef.current &&
      mediaRecorderRef.current.state !== "inactive"
    ) {
      try {
        mediaRecorderRef.current.stop();
      } catch {}
    }
    stopTracks();
    hardReset();
    setIsModalOpen(false);
  }, [hardReset, stopTracks]);

  // ---- start/stop logic ----
  const startRecording = () => {
    const stream = getStream();
    if (!stream) return;

    chunksRef.current = [];
    try {
      mediaRecorderRef.current = new MediaRecorder(stream, {
        mimeType: "video/webm",
      });
    } catch {
      // Fallback for browsers that reject explicit mimeType
      mediaRecorderRef.current = new MediaRecorder(stream);
    }

    mediaRecorderRef.current.ondataavailable = (evt) => {
      if (evt.data.size > 0) chunksRef.current.push(evt.data);
    };

    mediaRecorderRef.current.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: "video/webm" });
      const url = URL.createObjectURL(blob);
      setVideoUrl(url);
      setStatus("completed");
      setIsRecording(false);
    };

    mediaRecorderRef.current.start();
    setIsRecording(true);
    setStatus("recording");
  };

  // ---- auto-stop after 20s ----
  useEffect(() => {
    if (status === "recording") {
      const timeout = setTimeout(() => stopRecording(), 20_000);
      return () => clearTimeout(timeout);
    }
  }, [status]);

  // ---- countdown ----
  useEffect(() => {
    if (status === "countdown" && countdown > 0) {
      const id = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(id);
            startRecording();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(id);
    } else if (status !== "countdown" && countdown !== 4) {
      setCountdown(4);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, countdown]);

  // ---- recording timer ----
  useEffect(() => {
    let timer: ReturnType<typeof setInterval> | undefined;
    if (status === "recording") {
      timer = setInterval(() => setRecordingTime((t) => t + 1), 1000);
    } else {
      setRecordingTime(0);
    }
    return () => timer && clearInterval(timer);
  }, [status]);

  const stopRecording = () => {
    if (
      mediaRecorderRef.current &&
      mediaRecorderRef.current.state !== "inactive"
    ) {
      try {
        mediaRecorderRef.current.stop();
      } catch {}
    }
    setIsRecording(false);
  };

  const startCountdown = () => {
    setStatus("countdown");
    setCountdown(4);
  };

  // Discard new preview and use the existing server video
  const useExisting = useCallback(() => {
    setVideoUrl(null);
    chunksRef.current = [];
    setStatus("ready");
  }, []);

  const handleSave = async () => {
    if (!videoUrl || chunksRef.current.length === 0) return;

    try {
      const videoBlob = new Blob(chunksRef.current, { type: "video/webm" });
      const file = new File([videoBlob], "video_resume.webm", {
        type: "video/webm",
      });

      const res = await createUserResumeVideo({ userId, file });

      if (res?.success) {
        toast.success("Video uploaded successfully!");
        // If API returns a new persisted URL, set it so it persists next time.
        // Example: setServerVideoUrl(res.data.videoUrl ?? serverVideoUrl);
        closeModal();
      } else {
        toast.error(res?.message || "Failed to upload video.");
      }
    } catch {
      toast.error("Failed to upload video.");
    }
  };

  return (
    <div>
      {/* Launch modal */}
      <button
        onClick={() => setIsModalOpen(true)}
        className="p-1 btn-primary text-white text-sm cursor-pointer rounded-md shadow hover:bg-blue-700 transition-colors w-fit"
      >
        Video Resume
      </button>

      {/* Modal */}
      {isModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60"
          role="dialog"
          aria-modal="true"
          aria-label="Video resume recorder"
        >
          <div className="bg-white rounded-md shadow-md w-full max-w-3xl mx-4">
            {/* Modal header */}
            <div className="flex items-center justify-between p-2">
              <h2 className="text-base font-semibold">Record Video Resume</h2>
              <button
                onClick={closeModal}
                className="px-2 py-1 rounded cursor-pointer hover:bg-gray-100 transition"
                aria-label="Close"
              >
                ✕
              </button>
            </div>

            {/* Modal body */}
            <div className="p-2">
              <div className="flex flex-col md:flex-row gap-3">
                {/* Left: Webcam & controls */}
                <div className="flex-1">
                  {/* Countdown / timer */}
                  {status === "countdown" && (
                    <div className="mb-2 text-center font-semibold text-lg text-red-600">
                      Starting in {countdown}…
                    </div>
                  )}
                  {status === "recording" && (
                    <div className="mb-2 text-center font-semibold text-lg text-red-600">
                      {recordingTime}s
                    </div>
                  )}

                  {/* Webcam */}
                  <div className="overflow-hidden rounded-md bg-black">
                    <Webcam
                      audio
                      ref={webcamRef}
                      videoConstraints={{
                        facingMode: "user",
                        frameRate: { ideal: 30 },
                      }}
                      imageSmoothing
                      mirrored
                      className="w-full h-auto"
                      onUserMediaError={() => {
                        toast.error("Cannot access camera/microphone.");
                      }}
                    />
                  </div>

                  {/* Controls */}
                  <div className="mt-4 flex justify-between flex-wrap gap-2">
                    {status === "ready" && !isRecording && (
                      <button
                        className="p-2 bg-green-600 cursor-pointer text-white rounded-md shadow hover:bg-green-700 transition"
                        onClick={startCountdown}
                      >
                        Start Recording
                      </button>
                    )}

                    {status === "countdown" && (
                      <div className="p-2 rounded-md bg-yellow-100 text-yellow-800 font-medium">
                        Starting in {countdown}…
                      </div>
                    )}

                    {status === "recording" && (
                      <button
                        className="p-2 bg-red-600 cursor-pointer text-white rounded-md shadow hover:bg-red-700 transition"
                        onClick={stopRecording}
                      >
                        Stop Recording
                      </button>
                    )}

                    {(status === "recording" ||
                      status === "countdown" ||
                      status === "ready") && (
                      <button
                        className="p-2 bg-gray-200 cursor-pointer text-gray-800 rounded-md hover:bg-gray-300 transition"
                        onClick={hardReset}
                      >
                        Reset
                      </button>
                    )}
                  </div>
                </div>

                {/* Right: Preview */}
                <div className="flex-1">
                  {previewUrl ? (
                    <div className="space-y-2">
                      <video
                        src={previewUrl}
                        controls
                        className="w-full rounded-md"
                      />
                      {/* Show revert only if there is a new local preview and a server video to fall back to */}
                      {serverVideoUrl && status === "completed" && videoUrl && (
                        <button
                          onClick={useExisting}
                          className="px-3 py-1 text-sm rounded-md cursor-pointer bg-gray-100 hover:bg-gray-200 transition"
                        >
                          Use existing video
                        </button>
                      )}
                      {isVideoLoading && (
                        <div className="text-xs text-gray-500">
                          Loading existing video…
                        </div>
                      )}
                      {videoError && (
                        <div className="text-xs text-red-600">
                          Couldn’t load existing video.
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="h-full grid place-items-center text-sm text-gray-500 border border-dashed rounded-md p-2">
                      {isVideoLoading
                        ? "Loading existing video…"
                        : "Recording preview will appear here"}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Modal footer */}
            <div className="flex items-center justify-between p-2">
              <span className="text-xs text-gray-500">
                Max recording time: 20s • Format: WebM
              </span>
              <div className="flex gap-2">
                <button
                  onClick={closeModal}
                  className="p-2 rounded-md cursor-pointer bg-gray-100 hover:bg-gray-200 transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  disabled={status !== "completed" || !videoUrl}
                  className="p-2 rounded-md cursor-pointer bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 transition"
                >
                  Save
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
