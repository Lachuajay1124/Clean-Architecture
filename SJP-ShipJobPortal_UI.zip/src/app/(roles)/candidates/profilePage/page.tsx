"use client";

// React core
import React, { useState } from "react";

// External libraries
import Cookies from "js-cookie";
import Image from "next/image";
import {
  Award,
  Calendar,
  Clock,
  Download,
  Edit3,
  Eye,
  FileText,
  Mail,
  MapPin,
  Pencil,
  Phone,
  Plus,
  Ship,
  Star,
  User,
} from "lucide-react";

// Internal components (@ alias)
import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";
import { CertificateUpsertModal } from "@/components/common/Layout/Modal/CandidateModal/Profile/certificateEdit";
import { ExperienceUpsertModal } from "@/components/common/Layout/Modal/CandidateModal/Profile/experienceEdit";

// Hooks / data
import { useAllJobAppliedCandidatesProfile } from "@/hooks/listingHooks/useListingHooks";

// Relative modules
import { VideoCapture } from "./videoResume";
import {
  CertificateFormData,
  ExperienceFormData,
} from "@/app/api/UserApi/UserCrud";

// Types (type-only)

export default function ModernSeafarerProfile() {
  const userId = Number(Cookies.get("userId"));

  // Separate modal states
  const [openExp, setOpenExp] = useState(false);
  const [openCert, setOpenCert] = useState(false);

  const [expRows, setExpRows] = useState<ExperienceFormData[]>([]);

  const [certRows, setCertRows] = useState<CertificateFormData[]>([]);

  const {
    data: profileData,
    isLoading: isProfileLoading,
    isError: profileError,
    refetch,
  } = useAllJobAppliedCandidatesProfile({ userId });

  const experiences = profileData?.experiances ?? [];

  // ---- Experience mappers & open handlers ----
  const mapToExpFormRow = (x: ExperienceFormData): ExperienceFormData => ({
    experianceId: x?.experianceId ?? "0",
    vesselName: x?.vesselName ?? "",
    vesselType: x?.vesselType ?? "",
    rank: x?.rank ?? "",
    companyName: x?.companyName ?? "",
    duration: x?.duration ?? "",
    dwt: x?.dwt ?? "",
    period: x?.period ?? "",
    position: x?.position ?? "",
    route: x?.route ?? "",
    gt: x?.gt ?? "",
    fromDate: x?.fromDate ?? "",
    engineType: x?.engineType ?? "",
    ias: x?.ias ?? "",
    kw: x?.kw ?? "",
    toDate: x?.toDate ?? "",
  });

  const handleAddService = () => {
    setExpRows([]);
    setOpenExp(true);
  };

  const handleEditService = (service: ExperienceFormData) => {
    setExpRows([mapToExpFormRow(service)]);
    setOpenExp(true);
  };

  // ---- Certificate mappers & open handlers ----
  const mapToCertFormRow = (c: CertificateFormData): CertificateFormData => ({
    certificateId: c?.certificateId ?? "0",
    certificateName: c?.certificateName ?? "",
    issuedDate: c?.issuedDate ?? "",
    issuedCountry: c?.issuedCountry ?? "",
    expiryDate: c?.expiryDate ?? "",
    status: c?.status ?? "",
    documentNumber: c?.documentNumber ?? "",
  });

  const handleAddCertificate = () => {
    setCertRows([]);
    setOpenCert(true);
  };

  const handleEditCertificate = (cert: CertificateFormData) => {
    setCertRows([mapToCertFormRow(cert)]);
    setOpenCert(true);
  };

  if (isProfileLoading) return <LoadingSpinner />;

  if (profileError) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-red-600">Error loading profile</div>
      </div>
    );
  }

  return (
    <div className="h-full min-h-0 flex flex-col overflow-hidden space-y-3">
      {/* Header Card */}
      <div className="bg-white rounded-md shadow-md">
        <div className="btn-primary p-2">
          <div className="flex items-start gap-3">
            <div className="w-16 h-16 rounded-md bg-white/20 flex items-center justify-center overflow-hidden border-2 border-white/30">
              {profileData?.avatar && profileData.avatar !== "string" ? (
                <Image
                  src={profileData.avatar}
                  alt={profileData?.name ?? ""}
                  className="w-full h-full object-cover"
                  width={80}
                  height={80}
                />
              ) : (
                <User size={24} className="text-white" />
              )}
            </div>

            <div className="flex-1 text-white">
              <div className="flex items-start justify-between">
                <div>
                  <h1 className="text-sm font-bold">{profileData?.name}</h1>
                  <p className="text-blue-100 text-sm font-medium">
                    {profileData?.rank}
                  </p>
                </div>
                <button className="p-3 bg-white/10 hover:bg-white/20 rounded-md transition-colors">
                  <Edit3 size={20} className="text-white" />
                </button>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <Ship size={16} className="text-blue-200" />
                  <span className="text-blue-100">
                    {profileData?.lastVessel}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock size={16} className="text-blue-200" />
                  <span className="text-blue-100">
                    {profileData?.totalSeaTime} experience
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin size={16} className="text-blue-200" />
                  <span className="text-blue-100">
                    {profileData?.nationality}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Star size={16} className="text-yellow-400" />
                  <span className="text-blue-100">{profileData?.rating}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Info */}
        <div className="p-2 bg-gray-50 border-t">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 md:gap-4 text-sm">
            <div className="flex items-center gap-3">
              <div className="p-1  bg-blue-100 rounded-md">
                <Mail size={14} className="text-blue-600" />
              </div>
              <span className="text-gray-700 text-[10px] md:text-sm">
                {profileData?.email}
              </span>
            </div>
            <div className="flex items-center justify-start md:justify-center gap-3">
              <div className="p-1  bg-green-100 rounded-md">
                <Phone size={14} className="text-green-600" />
              </div>
              <span className="text-gray-700 text-[10px] md:text-sm">
                {profileData?.phoneNumber}
              </span>
            </div>
            <div className="flex items-center justify-start md:justify-end gap-3">
              <div className="p-1 bg-purple-100 rounded-md">
                <Calendar size={14} className="text-purple-600" />
              </div>
              <span className="text-gray-700 text-[10px] md:text-sm">
                {profileData?.age}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Content grid fills remaining height */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 flex-1 min-h-0">
        {/* Left Column */}
        <div className="flex flex-col gap-3 min-h-0">
          {/* Resume + Video */}
          <div className="bg-white rounded-md shadow-md p-2">
            <div className="flex flex-col justify-between">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-md font-semibold text-gray-800">Resume</h3>
                <button className="p-1 bg-blue-50 hover:bg-blue-100 rounded-md transition-colors">
                  <Download size={14} className="text-blue-600" />
                </button>
              </div>
              <div className="flex justify-between gap-2">
                <div className="flex items-center gap-4 p-1 bg-gradient-to-r from-red-50 to-orange-50 rounded-md border border-red-100">
                  <div className="p-1 bg-red-100 rounded-md">
                    <FileText size={14} className="text-red-600" />
                  </div>

                  <p className="font-medium text-xs text-gray-900">
                    Maritime_Resume.pdf
                  </p>

                  <button className="p-1 hover:bg-red-100 rounded-md transition-colors">
                    <Eye size={14} className="text-gray-600" />
                  </button>
                </div>
                <VideoCapture />
              </div>
            </div>
          </div>

          {/* Certificates */}
          <div className="bg-white rounded-md shadow-md flex flex-col min-h-0">
            <div className="p-1 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <h3 className="text-md font-semibold text-gray-800">
                  Certificates & Licenses
                </h3>

                <button
                  className="flex items-center gap-2 px-4 py-2 bg-green-50 hover:bg-green-100 text-green-600 rounded-md transition-colors text-sm font-medium"
                  onClick={handleAddCertificate}
                >
                  <Plus size={16} />
                  Add Certificate
                </button>
              </div>
            </div>

            {profileData?.certificates && (
              <div className="p-2 flex-1 min-h-0 overflow-y-auto scrollbar-thin">
                <div className="space-y-4">
                  {profileData?.certificates?.map(
                    (cert: CertificateFormData, index: number) => (
                      <div
                        key={index}
                        className="group p-2 bg-gray-50 hover:bg-green-50 rounded-md transition-all duration-200 hover:shadow-md"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className="p-1 bg-emerald-100 rounded-md">
                              <Award size={16} className="text-emerald-600" />
                            </div>
                            <div>
                              <h4 className="font-semibold text-xs text-gray-900 mb-1">
                                {cert.certificateName}
                              </h4>
                              <div className="flex items-center gap-2 text-sm text-gray-500">
                                <span>{cert.issuedCountry}</span>
                                <span>•</span>
                                <span>Expires: {cert.expiryDate}</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">
                              {cert.status}
                            </span>
                            <button
                              className="opacity-0 group-hover:opacity-100 p-1 bg-white hover:bg-green-50 rounded-md transition-all"
                              onClick={() => handleEditCertificate(cert)}
                              title="Edit certificate"
                            >
                              <Pencil size={16} className="text-green-600" />
                            </button>
                          </div>
                        </div>
                      </div>
                    )
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column */}
        <div className="lg:col-span-1 flex flex-col gap-3 min-h-0">
          {/* Experience */}
          <div className="bg-white rounded-md shadow-md flex flex-col flex-1 min-h-0">
            <div className="p-1 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <h3 className="text-md font-semibold text-gray-800">
                  Sea Service History
                </h3>

                <button
                  className="flex items-center gap-2 px-4 py-2 bg-orange-50 hover:bg-orange-100 text-orange-600 rounded-md transition-colors text-sm font-medium"
                  onClick={handleAddService}
                >
                  <Plus size={16} />
                  Add Service
                </button>
              </div>
            </div>

            {!!experiences.length && (
              <div className="p-2 flex-1 min-h-0 overflow-y-auto scrollbar-thin">
                <div className="space-y-3">
                  {experiences.map(
                    (service: ExperienceFormData, index: number) => (
                      <div
                        key={index}
                        className="group p-2 bg-gray-50 hover:bg-blue-50 rounded-md transition-all duration-200 hover:shadow-md"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h4 className="font-semibold text-xs text-gray-900">
                                {service.vesselName}
                              </h4>
                              <span className="px-3 py-1 text-xs bg-blue-100 text-blue-700 rounded-full font-medium">
                                {service.route}
                              </span>
                            </div>
                            <p className="text-gray-600 mb-1">
                              {service.position} • {service.vesselType} •
                              {service.duration}
                            </p>
                            <p className="text-xs text-gray-500">
                              {service.companyName}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium text-gray-700 mb-2">
                              {service.period}
                            </p>

                            <button
                              className="opacity-0 group-hover:opacity-100 p-1 bg-white hover:bg-blue-50 rounded-md transition-all"
                              onClick={() => handleEditService(service)}
                              title="Edit"
                            >
                              <Pencil size={16} className="text-blue-600" />
                            </button>
                          </div>
                        </div>
                      </div>
                    )
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Experience Modal */}
      <ExperienceUpsertModal
        open={openExp}
        onClose={() => setOpenExp(false)}
        initialExperiences={expRows}
        onAfterSave={async () => {
          await refetch();
        }}
      />

      {/* Certificate Modal */}
      <CertificateUpsertModal
        open={openCert}
        onClose={() => setOpenCert(false)}
        initialCertificates={certRows}
        onAfterSave={async () => {
          await refetch();
        }}
      />
    </div>
  );
}
