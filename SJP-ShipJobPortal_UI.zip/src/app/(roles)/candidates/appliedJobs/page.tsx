// React core
import React, { Suspense } from "react";

// External libraries
import { Briefcase } from "lucide-react";

import { SearchInputData } from "@/components/common/Search/SearchWithZustand";
import { AllAppliedJobs } from "@/components/Tables&Cards/Candidate/allappliedJobs";
import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";

export default function ApplicationHistoryPage() {
  return (
    <div className="h-full flex flex-col bg-white/50 space-y-2 justify-between rounded-md p-2">
      <div className="flex flex-col lg:flex-row  lg:justify-between gap-2">
        <div className="flex justify-start gap-2 w-full">
          <div className="w-6 h-6 md:w-9 md:h-9 btn-primary rounded-md flex items-center justify-center">
            <Briefcase size={16} className="text-white" />
          </div>
          <div>
            <h1 className="text-sm font-bold primary-text bg-clip-text text-transparent">
              Applied Jobs
            </h1>
            <p className="text-xs text-gray-600 hidden md:block">
              View your active applications
            </p>
          </div>
        </div>

        <SearchInputData placeholder="Search job title, companies" />
      </div>
      <Suspense fallback={<LoadingSpinner />}>
        <AllAppliedJobs />
      </Suspense>
    </div>
  );
}
