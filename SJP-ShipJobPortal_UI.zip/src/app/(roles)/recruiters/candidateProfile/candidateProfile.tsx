"use client";

// React core
import React, { useMemo, useState } from "react";

// External libraries
import Image from "next/image";
import Modal from "react-modal";
import {
  AlertCircle,
  Anchor,
  Annoyed,
  Award,
  Calendar,
  CheckCircle,
  ChevronRight,
  Clock,
  Globe,
  Heart,
  Mail,
  MapPin,
  Phone,
  Shield,
  Ship,
  Star,
  User,
  User2,
  X,
} from "lucide-react";

// Internal modules (@ alias)
import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";
import { useAllJobAppliedCandidatesProfile } from "@/hooks/listingHooks/useListingHooks";
import { CertificateFormData } from "@/app/api/UserApi/UserCrud";
import { ExperienceFormData } from "@/types/getApiTypes";

interface Props {
  userId: number | null | undefined;
  onClose: () => void;
  isOpen: boolean;
}

const SeafarerProfile: React.FC<Props> = ({ userId, onClose, isOpen }) => {
  const [activeTab, setActiveTab] = useState<
    "overview" | "experience" | "certifications"
  >("overview");
  const [isBookmarked, setIsBookmarked] = useState(false);

  // Commenting state
  const [comment, setComment] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const isCommentValid = comment.trim().length > 0;

  const {
    data: candidatesData,
    isLoading: isCandidateLoading,
    isError: candidateError,
  } = useAllJobAppliedCandidatesProfile({
    userId: userId,
  });

  const certificatesCount = useMemo(
    () => candidatesData?.certificates?.length ?? 0,
    [candidatesData?.certificates]
  );

  const experiencesCount = useMemo(
    () => candidatesData?.experiances?.length ?? 0,
    [candidatesData?.experiances]
  );

  const getStatusColor = (status: string | null) => {
    switch (status) {
      case "valid":
        return "text-emerald-600 bg-emerald-50 border-emerald-200";
      case "expiring":
        return "text-amber-600 bg-amber-50 border-amber-200";
      case "expired":
        return "text-red-600 bg-red-50 border-red-200";
      default:
        return "text-gray-600 bg-gray-50 border-gray-200";
    }
  };

  const getStatusIcon = (status: string | null) => {
    return status === "valid" ? (
      <CheckCircle className="w-3 h-3" />
    ) : (
      <AlertCircle className="w-3 h-3" />
    );
  };

  // TODO: Replace with your actual API endpoint & payload
  const handleSendMessage = async () => {
    if (!isCommentValid || !userId) return;
    try {
      setIsSubmitting(true);

      // Example payload — adjust keys to match your backend
      const payload = {
        aboutUserId: userId, // candidate user id
        comment: comment.trim(),
      };

      // Replace with your real endpoint (axios or fetch)
      const res = await fetch("/api/recruiter/comments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        throw new Error(`Failed to submit comment (${res.status})`);
      }

      // Reset after successful submit
      setComment("");
      onClose();
    } catch {
      // You can show a toast/error UI here
      // toast.error("Failed to submit comment");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <Modal
      isOpen={isOpen}
      ariaHideApp={false}
      onRequestClose={onClose}
      shouldCloseOnEsc={true}
      shouldCloseOnOverlayClick={true}
      style={{
        overlay: {
          backgroundColor: "rgba(0, 0, 0, 0.8)",
          zIndex: 50,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: "8px",
        },
        content: {
          position: "relative",
          inset: "auto",
          width: "100%",
          maxWidth: "900px",
          height: "85vh",
          padding: "0",
          border: "none",
          borderRadius: "8px",
          overflow: "hidden",
        },
      }}
      aria-labelledby="seafarer-profile-modal"
      aria-describedby="seafarer-profile-modal-description"
    >
      {isCandidateLoading ? (
        <LoadingSpinner />
      ) : candidateError ? (
        <div className="flex items-center justify-center h-full">
          <div className="text-center bg-red-50 border border-red-200 rounded-md p-4 text-red-700">
            Failed to load profile: {String(candidateError) || "Unknown error"}
          </div>
        </div>
      ) : (
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="relative btn-primary p-2">
            <div className="flex items-start gap-2">
              <div className="w-15 h-15 bg-white/10 rounded-md p-1 flex justify-center items-center">
                {candidatesData?.avatar &&
                candidatesData.avatar !== "string" ? (
                  <Image
                    width={100}
                    height={100}
                    src={candidatesData.avatar}
                    alt="seafarer"
                    className="w-full h-full object-cover rounded-md blur-xs"
                  />
                ) : (
                  <User2 size={20} className="text-white" />
                )}
              </div>

              <div className="flex-1 text-white">
                <div className="flex items-center gap-2">
                  {/* Name (placeholder skeleton unless you have candidatesData?.fullName) */}
                  <div className="h-3 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 rounded w-40 animate-pulse"></div>

                  <div className="flex items-center gap-2">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm text-yellow-400 font-medium">
                      {candidatesData?.rating}
                    </span>
                  </div>
                </div>
                <p className="text-blue-200 font-medium">
                  {candidatesData?.rank || "N/A"}
                </p>
                <div className="flex flex-wrap gap-2 text-xs text-slate-300">
                  <span className="flex items-center gap-2">
                    <MapPin className="w-3 h-3" />
                    <div className="h-3 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 rounded w-40 animate-pulse"></div>
                  </span>
                  <span className="flex items-center gap-2">
                    <Clock className="w-3 h-3" />
                    {candidatesData?.totalSeaTime || "N/A"}
                  </span>
                  <span className="flex items-center gap-2">
                    <Ship className="w-3 h-3" />
                    {candidatesData?.lastVessel || "N/A"}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={onClose}
                  className="p-2 rounded-md cursor-pointer bg-white/10 text-white hover:bg-white/20 transition-all"
                  aria-label="Close profile modal"
                >
                  <Annoyed className="w-5 h-5 hover:text-amber-400" />
                </button>
                <button
                  onClick={() => setIsBookmarked(!isBookmarked)}
                  className={`p-2 rounded-md transition-all cursor-pointer ${
                    isBookmarked
                      ? "bg-red-500 text-white"
                      : "bg-white/10 text-white hover:bg-white/20"
                  }`}
                  aria-label="Bookmark candidate"
                >
                  <Heart
                    className={`w-5 h-5 ${
                      isBookmarked ? "fill-current" : ""
                    } hover:text-red-400`}
                  />
                </button>
                <button
                  onClick={onClose}
                  className="p-2 rounded-md cursor-pointer bg-white/10 text-white hover:bg-white/20 transition-all"
                  aria-label="Close profile modal"
                >
                  <X className="w-5 h-5 hover:text-red-400" />
                </button>
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-4 gap-2 p-3">
            <div
              className="flex justify-between bg-white/50 shadow-md p-2 rounded-md"
              role="status"
              aria-live="polite"
            >
              <div className="w-8 h-8 bg-blue-600 rounded-md flex items-center justify-center">
                <Calendar className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-xs text-slate-600">Status</p>
                <p className="text-xs font-semibold text-emerald-600">
                  {candidatesData?.dateofAvailability ? "Available" : "Unknown"}
                </p>
              </div>
            </div>

            <div className="flex justify-between bg-white/50 shadow-md p-2 rounded-md">
              <div className="w-8 h-8 bg-purple-600 rounded-md flex items-center justify-center">
                <Shield className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-xs text-slate-600">Certificates</p>
                <p className="text-xs font-semibold text-slate-900">
                  {certificatesCount}
                </p>
              </div>
            </div>

            <div className="flex justify-between bg-white/50 shadow-md p-2 rounded-md">
              <div className="w-8 h-8 bg-amber-600 rounded-md flex items-center justify-center">
                <Globe className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-xs text-slate-600">Nationality</p>
                <p className="text-xs font-semibold text-slate-900">
                  {candidatesData?.nationality || "N/A"}
                </p>
              </div>
            </div>

            <div className="flex justify-between bg-white/50 shadow-md p-2 rounded-md">
              <div className="w-8 h-8 bg-green-600 rounded-md flex items-center justify-center mx-auto">
                <Anchor className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-xs text-slate-600">Experience</p>
                <p className="text-xs font-semibold text-slate-900">
                  {experiencesCount} vessels
                </p>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="border-b border-gray-200 my-3 px-3">
            <nav className="flex justify-between gap-2">
              {[
                { id: "overview", label: "Overview", icon: User },
                { id: "experience", label: "Experience", icon: Anchor },
                { id: "certifications", label: "Certificates", icon: Award },
              ].map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() =>
                      setActiveTab(
                        tab.id as "overview" | "experience" | "certifications"
                      )
                    }
                    className={`flex cursor-pointer items-center rounded-t-md justify-center gap-2 py-2 text-sm font-medium border-b-2 transition-all ${
                      activeTab === tab.id
                        ? "border-blue-500 text-blue-600 bg-blue-50"
                        : "border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-50"
                    }`}
                    aria-selected={activeTab === tab.id ? "true" : "false"}
                    role="tab"
                    id={`tab-${tab.id}`}
                    aria-controls={`panel-${tab.id}`}
                  >
                    <Icon className="w-4 h-4" />
                    <span className="hidden sm:inline">{tab.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Tab Content */}
          <div
            className="p-3 flex-1 overflow-y-auto"
            role="tabpanel"
            id={`panel-${activeTab}`}
          >
            {activeTab === "overview" && (
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-2">
                  <div className="flex items-center gap-2 p-2 bg-white/50 border border-gray-200 shadow-md rounded-md">
                    <Phone className="w-4 h-4 text-slate-400" />
                    <div className="h-3 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 rounded flex-1 animate-pulse"></div>
                    {/* <span className="text-sm font-medium blur-[3px]">
                      {candidatesData?.phoneNumber || "Not provided"}
                    </span> */}
                  </div>
                  <div className="flex items-center gap-2 p-2 bg-white/50 border border-gray-200 shadow-md rounded-md">
                    <Mail className="w-4 h-4 text-slate-400" />
                    <div className="h-3 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 rounded flex-1 animate-pulse"></div>
                    {/* <span className="text-sm font-medium blur-[3px]">
                      {candidatesData?.email || "Not provided"}
                    </span> */}
                  </div>

                  <div className="flex items-center gap-2 p-2 bg-white/50 border border-gray-200 shadow-md rounded-md">
                    <Calendar className="w-4 h-4 text-slate-400" />
                    <span className="text-sm font-medium">
                      Age · {candidatesData?.age || "Not provided"}
                    </span>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-slate-900 mb-2">
                    Professional Summary
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    Experienced Master Mariner with over 18 years of sea service
                    across various vessel types. Proven track record in safe
                    navigation, crew management, and regulatory compliance.
                  </p>
                </div>
              </div>
            )}

            {activeTab === "experience" && (
              <div className="space-y-3">
                {experiencesCount === 0 ? (
                  <p className="text-sm text-slate-500">No experience added.</p>
                ) : (
                  candidatesData?.experiances?.map(
                    (exp: ExperienceFormData, index: number) => (
                      <div
                        key={index}
                        className="p-2 border border-gray-200 rounded-md bg-slate-50/50"
                      >
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h4 className="font-semibold text-slate-900">
                              {exp.vesselName}
                            </h4>

                            <p className="text-blue-600 text-sm font-medium">
                              {exp.vesselType}
                            </p>
                            <p className="text-blue-600 text-sm font-medium">
                              {exp.position}
                            </p>
                            <p className="text-blue-600 text-sm font-medium">
                              {exp.duration}
                            </p>
                          </div>
                          <span className="text-xs text-slate-500 bg-white px-2 py-1 rounded-full">
                            {exp.period}
                          </span>
                        </div>
                        <div className="text-sm text-slate-600">
                          <span className="font-medium">{exp.gt}</span> •{" "}
                          {exp.companyName}
                        </div>
                      </div>
                    )
                  )
                )}
              </div>
            )}

            {activeTab === "certifications" && (
              <div className="space-y-3">
                {certificatesCount === 0 ? (
                  <p className="text-sm text-slate-500">
                    No certificates added.
                  </p>
                ) : (
                  candidatesData?.certificates?.map(
                    (cert: CertificateFormData, index: number) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-2 border border-gray-200 rounded-md bg-slate-50/50"
                      >
                        <div className="flex items-center gap-2">
                          <div
                            className={`p-1 rounded-md ${getStatusColor(
                              cert?.status
                            )}`}
                          >
                            {getStatusIcon(cert?.status)}
                          </div>
                          <div>
                            <h4 className="font-medium text-slate-900 text-sm">
                              {cert.certificateName}
                            </h4>
                            <p className="text-xs text-slate-500">
                              {cert.issuedCountry} • {cert.expiryDate}
                            </p>
                            <p className="text-xs text-slate-500">
                              {cert.documentNumber}
                            </p>
                          </div>
                        </div>
                        <span
                          className={`px-2 py-1 rounded-full text-xs font-medium capitalize border ${getStatusColor(
                            cert.status
                          )}`}
                        >
                          {cert.status}
                        </span>
                      </div>
                    )
                  )
                )}
              </div>
            )}
          </div>

          {/* Footer with commenting */}
          <div className="p-2 border-t border-gray-200 flex flex-col gap-2">
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Write a comment about the seafarer..."
              className="w-full p-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring focus:ring-blue-300 resize-none"
              rows={2}
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={onClose}
                className="px-4 py-2 text-sm font-medium cursor-pointer text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-50"
                aria-label="Close profile modal"
              >
                Close
              </button>
              <button
                onClick={handleSendMessage}
                disabled={!isCommentValid || isSubmitting}
                className={`px-4 py-2 text-sm font-medium text-white rounded-md flex items-center gap-2 ${
                  !isCommentValid || isSubmitting
                    ? "bg-gray-400 cursor-not-allowed"
                    : "btn-primary hover:bg-blue-700"
                }`}
                aria-disabled={!isCommentValid || isSubmitting}
              >
                {isSubmitting ? "Sending..." : "Submit"}
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </Modal>
  );
};

export default SeafarerProfile;
