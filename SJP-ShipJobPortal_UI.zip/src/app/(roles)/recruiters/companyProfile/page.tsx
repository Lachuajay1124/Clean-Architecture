"use client";
// React core
import React from "react";

import {
  Building2,
  Edit3,
  ExternalLink,
  Globe,
  Mail,
  MapPin,
  Phone,
} from "lucide-react";

// Internal modules (@ alias)
import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";
import { useCompanyProfile } from "@/hooks/listingHooks/useListingHooks";

export default function CompanyProfilePage() {
  const {
    data: companyData,
    isLoading: isCompanyLoading,
    isError: companyError,
  } = useCompanyProfile({});

  if (isCompanyLoading) {
    return <LoadingSpinner />;
  }

  if (companyError) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-red-600">Error loading company profile</div>
      </div>
    );
  }

  return (
    <div className="flex flex-col justify-between h-full overflow-y-auto text-black  space-y-3">
      {/* Company Header */}
      <div className="bg-white rounded-md p-2 shadow-md border border-gray-200">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-4">
            <div className="p-2 bg-blue-100 rounded-md">
              <Building2 className="w-8 h-8 text-blue-600" />
            </div>
            <div>
              <h1 className="text-md font-semibold text-gray-900">
                {companyData?.companyname || "Company Name"}
              </h1>
              <p className="text-gray-600">Maritime Company</p>
            </div>
          </div>
          <button className="cursor-pointer flex items-center gap-2 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-md px-4 py-2 transition-colors">
            <Edit3 size={16} />
            Edit Profile
          </button>
        </div>
      </div>

      {/* Contact Information */}
      <div className="bg-white h-full rounded-md p-2 shadow-md border border-gray-200">
        <h2 className="text-md font-semibold text-gray-900">
          Contact Information
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-full">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-100 rounded-md">
              <Mail className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Email</p>
              <p className="font-medium text-gray-900">
                {companyData?.email || "Not provided"}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 rounded-md">
              <Phone className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Phone</p>
              <p className="font-medium text-gray-900">
                {companyData?.contactnumber || "Not provided"}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="p-2 bg-purple-100 rounded-md">
              <Globe className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Website</p>
              {companyData?.website ? (
                <a
                  href={companyData.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-medium text-blue-600 hover:text-blue-800 flex items-center gap-1"
                >
                  {companyData.website}
                  <ExternalLink size={14} />
                </a>
              ) : (
                <p className="font-medium text-gray-900">Not provided</p>
              )}
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="p-2 bg-red-100 rounded-md">
              <MapPin className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Address</p>
              <p className="font-medium text-gray-900">
                {companyData?.companyaddress && (
                  <>
                    {companyData.companyaddress}
                    <br />
                    {companyData.city}, {companyData.state}{" "}
                    {companyData.postalcode}
                    <br />
                    {companyData.country}
                  </>
                )}
                {!companyData?.companyaddress && "Not provided"}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Company Overview */}
      <div className="bg-white h-full rounded-md p-2 shadow-md border border-gray-200">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-md font-semibold text-gray-900">
            Company Overview
          </h2>
        </div>
        <p className="text-gray-700 text-sm leading-relaxed">
          <strong className="text-blue-700">{companyData?.companyname}</strong>{" "}
          is a leading global maritime company specializing in the management of
          bulk carriers and tankers. With over 20 years of industry experience,
          we focus on operational excellence, compliance, and crew safety.
        </p>
      </div>
    </div>
  );
}
