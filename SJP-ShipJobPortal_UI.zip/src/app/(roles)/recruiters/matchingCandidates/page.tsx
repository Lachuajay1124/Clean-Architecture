// React core

import { Users } from "lucide-react";

// Types (type-only)
import { JobSelect } from "@/components/common/Select/jobSelect";
import { SearchInputData } from "@/components/common/Search/SearchWithZustand";
import { AllMatchingCandidates } from "@/components/Tables&Cards/Recruiter/allMatchingCandidates";
import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";
import { Suspense } from "react";

export type ProfileStatus = "Working" | "NotWorking";

export default function RecruiterMatchingProfiles() {
  return (
    <div className="h-full flex flex-col bg-white/50 p-2 rounded-md shadow-md space-y-2">
      {/* Header Controls */}
      <div className="flex flex-col lg:flex-row lg:justify-between gap-2">
        <div className="flex justify-start gap-2 w-full">
          <div className="w-6 h-6 md:w-9 md:h-9 btn-primary rounded-md flex items-center justify-center">
            <Users size={16} className="text-white" />
          </div>{" "}
          <div>
            <h1 className="text-sm font-bold primary-text bg-clip-text text-transparent">
              Matching Candidates
            </h1>
            <p className="text-xs text-gray-600 hidden md:block">
              Showing selected job matching applications
            </p>
          </div>
        </div>

        {/* Job Filter */}
        <JobSelect />

        <SearchInputData placeholder="Search job title, companies" />
      </div>
      <Suspense fallback={<LoadingSpinner />}>
        <AllMatchingCandidates />
      </Suspense>
    </div>
  );
}
