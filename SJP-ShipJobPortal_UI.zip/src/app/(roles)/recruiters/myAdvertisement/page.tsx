"use client";

import React, { useState } from "react";

import {
  Building,
  Calendar,
  Clock,
  Edit,
  Eye,
  MapPin,
  Plus,
  Trash2,
  Users,
} from "lucide-react";

import { SearchInput } from "@/components/common/Search/search";

// Mock data types
interface CreateAdFormData {
  companyCode: string;
  companyName: string;
  postedBy: string;
  jobTitle: string;
  jobLocation: string;
  duration: string;
  description: string;
}

interface JobAd extends CreateAdFormData {
  id: string;
  datePosted: string;
  status: "active" | "draft" | "expired";
  applicants: number;
}

// Mock data
const mockJobAds: JobAd[] = [
  {
    id: "1",
    companyCode: "NYK",
    companyName: "NYK Line Pvt Ltd",
    postedBy: "Sarah Johnson",
    jobTitle: "Chief Engineer – LNG Carrier",
    jobLocation: "Singapore",
    duration: "6 Months",
    description:
      "We are seeking an experienced Chief Engineer for our state-of-the-art LNG carrier. The successful candidate will be responsible for the overall management of the engine room, ensuring safe and efficient operations while maintaining the highest standards of safety and environmental compliance.",
    datePosted: "2024-01-15",
    status: "active",
    applicants: 12,
  },
  {
    id: "2",
    companyCode: "MSK",
    companyName: "Maersk Line",
    postedBy: "Michael Chen",
    jobTitle: "Second Officer – Container Vessel",
    jobLocation: "Dubai",
    duration: "4 Months",
    description:
      "Join our team as a Second Officer on modern container vessels. Excellent opportunity for career growth with competitive benefits package and comprehensive training programs.",
    datePosted: "2024-01-12",
    status: "active",
    applicants: 8,
  },
  {
    id: "3",
    companyCode: "COSCO",
    companyName: "COSCO Shipping",
    postedBy: "Emma Rodriguez",
    jobTitle: "Third Engineer – Bulk Carrier",
    jobLocation: "Hong Kong",
    duration: "5 Months",
    description:
      "We are looking for a qualified Third Engineer to join our bulk carrier fleet. This position offers excellent learning opportunities and career advancement potential.",
    datePosted: "2024-01-10",
    status: "draft",
    applicants: 0,
  },
];

export default function SimpleRecruiterDashboard() {
  const [activeTab, setActiveTab] = useState<"listings" | "create">("listings");
  const [jobAds, setJobAds] = useState<JobAd[]>(mockJobAds);
  const [searchJob, setSearchJob] = useState("");
  const [debouncedSearchJob, setDebouncedSearchJob] = useState("");

  const [formData, setFormData] = useState<CreateAdFormData>({
    companyCode: "",
    companyName: "",
    postedBy: "",
    jobTitle: "",
    jobLocation: "",
    duration: "",
    description: "",
  });
  const [errors, setErrors] = useState<Partial<CreateAdFormData>>({});

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    if (errors[name as keyof CreateAdFormData]) {
      setErrors((prev) => ({
        ...prev,
        [name]: undefined,
      }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Partial<CreateAdFormData> = {};

    if (!formData.companyCode.trim())
      newErrors.companyCode = "Company code is required";
    if (!formData.companyName.trim())
      newErrors.companyName = "Company name is required";
    if (!formData.postedBy.trim())
      newErrors.postedBy = "Posted by field is required";
    if (!formData.jobTitle.trim()) newErrors.jobTitle = "Job title is required";
    if (!formData.jobLocation.trim())
      newErrors.jobLocation = "Job location is required";
    if (!formData.duration.trim()) newErrors.duration = "Duration is required";
    if (!formData.description.trim())
      newErrors.description = "Description is required";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validateForm()) return;

    const newAd: JobAd = {
      id: Date.now().toString(),
      ...formData,
      datePosted: new Date().toISOString().split("T")[0],
      status: "active",
      applicants: 0,
    };

    setJobAds((prev) => [newAd, ...prev]);
    setFormData({
      companyCode: "",
      companyName: "",
      postedBy: "",
      jobTitle: "",
      jobLocation: "",
      duration: "",
      description: "",
    });
    setActiveTab("listings");
  };

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this job advertisement?")) {
      setJobAds((prev) => prev.filter((ad) => ad.id !== id));
    }
  };

  const getStatusColor = (status: JobAd["status"]) => {
    switch (status) {
      case "active":
        return "text-green-600 bg-green-50";
      case "draft":
        return "text-amber-600 bg-amber-50";
      case "expired":
        return "text-red-600 bg-red-50";
      default:
        return "text-gray-600 bg-gray-50";
    }
  };

  const filteredAds = jobAds.filter((ad) => {
    const matchesSearch =
      ad.jobTitle.toLowerCase().includes(searchJob.toLowerCase()) ||
      ad.companyName.toLowerCase().includes(searchJob.toLowerCase());
    return matchesSearch;
  });

  return (
    <div className="h-full bg-white/50 rounded-md shadow-md p-2 overflow-hidden space-y-2">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex justify-start gap-2">
          <div className="w-6 h-6 md:w-9 md:h-9 btn-primary rounded-md flex items-center justify-center">
            <Users size={16} className="text-white" />
          </div>{" "}
          <div>
            <h1 className="text-sm font-bold primary-text bg-clip-text text-transparent">
              My advertisements
            </h1>
            <p className="text-xs text-gray-600 hidden md:block">
              Showing your Ads
            </p>
          </div>
        </div>

        <SearchInput
          value={searchJob}
          onDebouncedChange={(val) => {
            if (val !== debouncedSearchJob) {
              setDebouncedSearchJob(val);
              setSearchJob(val);
            }
          }}
          placeholder="Search Ads"
        />

        <div className="flex items-center justify-between  space-x-4 border border-slate-300 rounded-md">
          <button
            onClick={() => setActiveTab("listings")}
            className={`px-4 py-1 rounded-md font-medium cursor-pointer transition-colors text-sm ${
              activeTab === "listings"
                ? "btn-primary text-white"
                : "text-gray-600 hover:text-blue-600"
            }`}
          >
            Ads Listings
          </button>
          <button
            onClick={() => setActiveTab("create")}
            className={`px-4 py-1 rounded-md text-sm font-medium cursor-pointer flex items-center space-x-2 transition-colors ${
              activeTab === "create"
                ? "btn-primary text-white"
                : "text-gray-600 hover:text-blue-600"
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>Create Ad</span>
          </button>
        </div>
      </div>

      {activeTab === "listings" ? (
        <div className="space-y-4 h-full overflow-auto text-xs">
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="group bg-white  rounded-md p-1 border border-gray-100 hover:shadow-lg hover:shadow-blue-500/10 transition-all duration-300 hover:-translate-y-1">
              <div className="flex items-center justify-between">
                {" "}
                <div className="w-8 h-8 p-1 bg-blue-600 flex justify-center items-center rounded-md">
                  <Building
                    size={16}
                    className="text-white group-hover:scale-110 transition-transform duration-300"
                  />
                </div>
                <p className=" font-bold text-lg text-gray-900">
                  {jobAds.length}
                </p>
                <p className="text-sm text-gray-600">Total Jobs</p>
              </div>
            </div>

            <div className="group bg-white  rounded-md p-1 border border-gray-100 hover:shadow-lg hover:shadow-blue-500/10 transition-all duration-300 hover:-translate-y-1">
              <div className="flex items-center justify-between">
                <div className="w-8 h-8 p-1 bg-green-600 flex justify-center items-center rounded-md group-hover:scale-110 transition-transform duration-300">
                  <div className="w-3 h-3 bg-white rounded-full"></div>
                </div>{" "}
                <p className="font-bold text-lg text-gray-900">
                  {jobAds.filter((ad) => ad.status === "active").length}
                </p>
                <p className="text-sm text-gray-600">Active Jobs</p>
              </div>
            </div>

            <div className="group bg-white  rounded-md p-1 border border-gray-100 hover:shadow-lg hover:shadow-blue-500/10 transition-all duration-300 hover:-translate-y-1">
              <div className="flex items-center justify-between">
                <div className="w-8 h-8 p-1 bg-amber-600 flex justify-center items-center rounded-md group-hover:scale-110 transition-transform duration-300">
                  <Users className=" text-white" size={16} />
                </div>
                <p className="text-lg font-bold text-gray-900">
                  {jobAds.reduce((sum, ad) => sum + ad.applicants, 0)}
                </p>
                <p className="text-sm text-gray-600">Total Applicants</p>
              </div>
            </div>
          </div>

          {/* Job Listings */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3  gap-4 overflow-auto">
            {filteredAds.length > 0 ? (
              filteredAds.map((ad) => (
                <div
                  key={ad.id}
                  className="bg-white rounded-md shadow-md hover:shadow-md border border-gray-100 hover:border-blue-100 transition-all duration-200 overflow-hidden flex flex-col h-full"
                >
                  {/* Card Header */}
                  <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-3 border-b border-blue-100">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-sm font-semibold text-gray-900 line-clamp-1 flex-1">
                        {ad.jobTitle}
                      </h3>
                      <span
                        className={`px-2 py-1 rounded-full text-[10px] font-semibold uppercase tracking-wide ${getStatusColor(
                          ad.status
                        )} whitespace-nowrap`}
                      >
                        {ad.status}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-sm">
                      <Building className="w-4 h-4 text-blue-600 flex-shrink-0" />
                      <p className="text-gray-700 font-medium truncate">
                        {ad.companyName}
                      </p>
                      <span className="text-gray-400 mx-1">•</span>
                      <span className="text-gray-500 text-xs bg-gray-100 px-1.5 py-0.5 rounded">
                        {ad.companyCode}
                      </span>
                    </div>

                    {/* Action Buttons - Now more subtle */}
                    <div className="flex justify-end gap-1 mt-3">
                      <button
                        className="p-1 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                        title="View details"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      <button
                        className="p-1 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded transition-colors"
                        title="Edit job"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(ad.id)}
                        className="p-1 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                        title="Delete job"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Card Body */}
                  <div className="p-3 flex-grow">
                    {/* Job Info Grid */}
                    <div className="grid grid-cols-2 gap-2">
                      <div className="flex items-start gap-2">
                        <div className="p-1 bg-blue-50 rounded-md mt-0.5">
                          <MapPin className="w-3.5 h-3.5 text-blue-600" />
                        </div>
                        <div>
                          <p className="text-[11px] text-gray-500 uppercase tracking-wide">
                            Location
                          </p>
                          <p className="text-xs font-medium text-gray-900 line-clamp-1">
                            {ad.jobLocation}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-start gap-2">
                        <div className="p-1 bg-green-50 rounded-md mt-0.5">
                          <Clock className="w-3.5 h-3.5 text-green-600" />
                        </div>
                        <div>
                          <p className="text-[11px] text-gray-500 uppercase tracking-wide">
                            Duration
                          </p>
                          <p className="text-xs font-medium text-gray-900">
                            {ad.duration}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-start gap-2">
                        <div className="p-1 bg-purple-50 rounded-md mt-0.5">
                          <Calendar className="w-3.5 h-3.5 text-purple-600" />
                        </div>
                        <div>
                          <p className="text-[11px] text-gray-500 uppercase tracking-wide">
                            Posted
                          </p>
                          <p className="text-xs font-medium text-gray-900">
                            {new Date(ad.datePosted).toLocaleDateString()}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-start gap-2">
                        <div className="p-1 bg-orange-50 rounded-md mt-0.5">
                          <Users className="w-3.5 h-3.5 text-orange-600" />
                        </div>
                        <div>
                          <p className="text-[11px] text-gray-500 uppercase tracking-wide">
                            Applicants
                          </p>
                          <p className="text-xs font-medium text-gray-900">
                            {ad.applicants}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Subtle footer */}
                  <div className="border-t border-gray-100 px-3 py-2 bg-gray-50">
                    <p className="text-xs text-gray-500 text-right">
                      Updated N/A
                    </p>
                  </div>
                </div>
              ))
            ) : (
              /* Empty State Card - More polished */
              <div className="col-span-full bg-white rounded-md shadow-sm border border-gray-200 overflow-hidden">
                <div className="text-center py-12 px-6">
                  <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-5">
                    <Building className="w-7 h-7 text-blue-500" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">
                    No ad listings found
                  </h3>
                  <p className="text-gray-600 mb-6 max-w-md mx-auto text-sm">
                    {searchJob
                      ? "No matches found. Try different search terms or filters."
                      : "Create your first ad listing to start attracting talent."}
                  </p>
                  <button
                    onClick={() => setActiveTab("create")}
                    className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white font-medium text-sm rounded-md hover:bg-blue-700 transition-colors shadow-sm hover:shadow-md"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Create Ad</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="max-w-2xl mx-auto h-full overflow-y-auto">
          <div className="bg-white rounded-md border border-gray-200">
            <div className="p-2 ">
              <h2 className="text-xl font-semibold text-gray-900">
                Create New Ad
              </h2>
            </div>

            <div className="p-2">
              <div className="space-y-2">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Company Code *
                    </label>
                    <input
                      name="companyCode"
                      value={formData.companyCode}
                      onChange={handleInputChange}
                      placeholder="e.g. NYK"
                      className={`w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                        errors.companyCode
                          ? "border-red-300"
                          : "border-gray-300"
                      }`}
                    />
                    {errors.companyCode && (
                      <p className="text-sm text-red-600 mt-1">
                        {errors.companyCode}
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Company Name *
                    </label>
                    <input
                      name="companyName"
                      value={formData.companyName}
                      onChange={handleInputChange}
                      placeholder="e.g. NYK Line Pvt Ltd"
                      className={`w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                        errors.companyName
                          ? "border-red-300"
                          : "border-gray-300"
                      }`}
                    />
                    {errors.companyName && (
                      <p className="text-sm text-red-600 mt-1">
                        {errors.companyName}
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Posted By *
                    </label>
                    <input
                      name="postedBy"
                      value={formData.postedBy}
                      onChange={handleInputChange}
                      placeholder="e.g. HR Manager"
                      className={`w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                        errors.postedBy ? "border-red-300" : "border-gray-300"
                      }`}
                    />
                    {errors.postedBy && (
                      <p className="text-sm text-red-600 mt-1">
                        {errors.postedBy}
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Job Title *
                    </label>
                    <input
                      name="jobTitle"
                      value={formData.jobTitle}
                      onChange={handleInputChange}
                      placeholder="e.g. Chief Engineer – LNG Carrier"
                      className={`w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                        errors.jobTitle ? "border-red-300" : "border-gray-300"
                      }`}
                    />
                    {errors.jobTitle && (
                      <p className="text-sm text-red-600 mt-1">
                        {errors.jobTitle}
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Location *
                    </label>
                    <input
                      name="jobLocation"
                      value={formData.jobLocation}
                      onChange={handleInputChange}
                      placeholder="e.g. Singapore"
                      className={`w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                        errors.jobLocation
                          ? "border-red-300"
                          : "border-gray-300"
                      }`}
                    />
                    {errors.jobLocation && (
                      <p className="text-sm text-red-600 mt-1">
                        {errors.jobLocation}
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Duration *
                    </label>
                    <input
                      name="duration"
                      value={formData.duration}
                      onChange={handleInputChange}
                      placeholder="e.g. 6 Months"
                      className={`w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                        errors.duration ? "border-red-300" : "border-gray-300"
                      }`}
                    />
                    {errors.duration && (
                      <p className="text-sm text-red-600 mt-1">
                        {errors.duration}
                      </p>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Job Description *
                  </label>
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    rows={2}
                    placeholder="Provide a detailed description of the job role, responsibilities, and requirements..."
                    className={`w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none ${
                      errors.description ? "border-red-300" : "border-gray-300"
                    }`}
                  />
                  {errors.description && (
                    <p className="text-sm text-red-600 mt-1">
                      {errors.description}
                    </p>
                  )}
                </div>

                <div className="flex items-center space-x-4">
                  <button
                    type="button"
                    onClick={handleSubmit}
                    className="px-6 py-1 btn-primary text-white rounded-md hover:bg-blue-700 font-medium"
                    aria-label="Create new job listing"
                  >
                    Create Job
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab("listings")}
                    className="px-6 py-1 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 font-medium"
                    aria-label="Cancel creating job"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
