export type JobAd = {
  id: string;
  companyCode: string;
  companyName: string;
  postedBy: string;
  jobTitle: string;
  jobLocation: string;
  duration: string;
  description: string;
  datePosted: string;
  status: "active" | "draft" | "expired";
  applicants: number;
};

export type CreateAdFormData = {
  companyCode: string;
  companyName: string;
  postedBy: string;
  jobTitle: string;
  jobLocation: string;
  duration: string;
  description: string;
};

export const mockJobAds: JobAd[] = [
  {
    id: "1",
    companyCode: "NYK",
    companyName: "NYK Line Pvt Ltd",
    postedBy: "HR Manager",
    jobTitle: "Chief Engineer – LNG Carrier",
    jobLocation: "Singapore",
    duration: "6 Months",
    description:
      "Experienced Chief Engineer required for LNG Carrier operations. Minimum 5 years experience on gas carriers required. Competitive salary and benefits package.",
    datePosted: "2024-07-05",
    status: "active",
    applicants: 12,
  },
  {
    id: "2",
    companyCode: "MSC",
    companyName: "Mediterranean Shipping Company",
    postedBy: "Fleet Manager",
    jobTitle: "Second Officer – Container Vessel",
    jobLocation: "Dubai",
    duration: "4 Months",
    description:
      "Second Officer position available on large container vessels. STCW II/1 certification required. Good English communication skills essential.",
    datePosted: "2024-07-08",
    status: "active",
    applicants: 8,
  },
  {
    id: "3",
    companyCode: "MAERSK",
    companyName: "Maersk Line",
    postedBy: "Crew Manager",
    jobTitle: "Bosun – Offshore Supply Vessel",
    jobLocation: "Aberdeen",
    duration: "3 Months",
    description:
      "Experienced Bosun required for offshore supply vessel operations in North Sea. Valid STCW and offshore certificates mandatory.",
    datePosted: "2024-07-02",
    status: "draft",
    applicants: 3,
  },
  {
    id: "4",
    companyCode: "MAERSK",
    companyName: "Maersk Line",
    postedBy: "Crew Manager",
    jobTitle: "Bosun – Offshore Supply Vessel",
    jobLocation: "Aberdeen",
    duration: "3 Months",
    description:
      "Experienced Bosun required for offshore supply vessel operations in North Sea. Valid STCW and offshore certificates mandatory.",
    datePosted: "2024-07-02",
    status: "draft",
    applicants: 3,
  },
];
