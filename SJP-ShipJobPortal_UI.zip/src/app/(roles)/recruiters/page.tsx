import React, { Suspense } from "react";

import { Briefcase, TrendingUp } from "lucide-react";

import AllJobsRecruiter from "@/components/Tables&Cards/Recruiter/allJobsRecruiter";
import { SearchInputData } from "@/components/common/Search/SearchWithZustand";
import { LoadingSpinner } from "@/components/common/Layout/Loader/loader";

const mockStats = [
  { label: "Viewed Candidates", value: "12", color: "blue" },
  { label: "Applied Candidates", value: "84", color: "green" },
  { label: "Shortlisted Candidates", value: "6", color: "purple" },
  { label: "Credit", value: "97", color: "emerald" },
];

const RecruiterHomePage = () => {
  return (
    <div
      className="h-full flex flex-col space-y-2 p-2 bg-white/50 rounded-md shadow-md"
      role="main"
    >
      {/* Modern Header */}
      <div className="flex flex-col lg:flex-row lg:justify-between gap-2">
        <div className="flex justify-start gap-2 w-full">
          <div className="w-6 h-6 md:w-9 md:h-9 btn-primary rounded-md flex items-center justify-center">
            <Briefcase size={16} className="text-white" />
          </div>
          <div>
            <h1
              className="text-sm font-bold primary-text bg-clip-text text-transparent"
              id="job-dashboard-heading"
            >
              Job Dashboard
            </h1>
            <p className="text-xs text-gray-600 hidden md:block">
              Manage and track your job postings.
            </p>
          </div>
        </div>

        {/* Enhanced Search */}

        <SearchInputData placeholder="Search job title, companies" />
      </div>

      {/* Modern Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
        {mockStats.map((stat, index) => (
          <div
            key={`${stat.label}-${index}`}
            className="group bg-white rounded-md p-1 border border-gray-100 hover:shadow-lg hover:shadow-blue-500/10 transition-all duration-300 hover:-translate-y-1"
            aria-label={`${stat.label}: ${stat.value}`}
          >
            <div className="flex items-center justify-between">
              <div
                className={`w-5 h-5 md:w-8 md:h-8 bg-gradient-to-br ${
                  stat.color === "blue"
                    ? "from-blue-500 to-blue-600"
                    : stat.color === "green"
                    ? "from-green-500 to-green-600"
                    : stat.color === "purple"
                    ? "from-purple-500 to-purple-600"
                    : "from-emerald-500 to-emerald-600"
                } rounded-md flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}
              >
                <TrendingUp size={16} className="text-white" />
              </div>

              <p className="text-[10px] md:text-sm md:font-bold text-black">
                {stat.value}
              </p>
              <p className="text-[10px] md:text-sm  text-black">{stat.label}</p>
            </div>
          </div>
        ))}
      </div>
      <Suspense fallback={<LoadingSpinner />}>
        <AllJobsRecruiter />
      </Suspense>
    </div>
  );
};

export default RecruiterHomePage;
