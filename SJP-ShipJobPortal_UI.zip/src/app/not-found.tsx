import Link from "next/link";

export default function NotFound() {
  return (
    <div className="h-screen flex flex-col justify-center items-center bg-gray-100 text-center p-4">
      <h1 className="text-6xl font-bold text-red-600 mb-2">404</h1>
      <p className="text-2xl text-gray-700 mb-6">Page Not Found</p>
      <Link
        href="/login"
        className="text-white btn-primary hover:bg-blue-700 px-6 py-2 rounded"
      >
        Go Home
      </Link>
    </div>
  );
}
