// /store/useSearchStore.ts
import { create } from "zustand";

type SearchState = {
  searchValue: string;
  setSearchValue: (v: string) => void;
};

export const useSearchStore = create<SearchState>((set) => ({
  searchValue: "",
  setSearchValue: (v) => set({ searchValue: v }),
}));
