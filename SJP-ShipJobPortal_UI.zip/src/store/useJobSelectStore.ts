// /store/useJobSelectStore.ts
import { create } from "zustand";

type JobSelectState = {
  selectedJobId: number | null;
  selectedJobTitle: string | null;
  setSelectedJob: (jobId: number, jobTitle: string) => void;
  clearSelectedJob: () => void;
};

export const useJobSelectStore = create<JobSelectState>((set) => ({
  selectedJobId: null,
  selectedJobTitle: null,
  setSelectedJob: (jobId, jobTitle) =>
    set({ selectedJobId: jobId, selectedJobTitle: jobTitle }),
  clearSelectedJob: () => set({ selectedJobId: null, selectedJobTitle: null }),
}));
