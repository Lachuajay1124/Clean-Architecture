// stores/useJobFilterStore.ts
import { create } from "zustand";

export interface JobFilterState {
  positionId: number | null;
  vesselTypeId: number | null;
  locationId: number | null;
  durationId: number | null;
  setFilter: (
    key: keyof Omit<JobFilterState, "setFilter" | "clearFilters">,
    value: number | null
  ) => void;
  clearFilters: () => void;
}

export const useJobFilterStore = create<JobFilterState>((set) => ({
  positionId: null,
  vesselTypeId: null,
  locationId: null,
  durationId: null,
  setFilter: (key, value) =>
    set((state) => ({
      ...state,
      [key]: value,
    })),
  clearFilters: () =>
    set({
      positionId: null,
      vesselTypeId: null,
      locationId: null,
      durationId: null,
    }),
}));
